"use client";

import { createContext, useContext, useState, useEffect, ReactNode } from 'react';

type Language = 'en' | 'ar' | 'zh';

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string, params?: Record<string, string>) => string;
  isRTL: boolean;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

interface TranslationKey {
  en: string;
  ar: string;
  zh: string;
}

const translations: Record<string, TranslationKey> = {
  // Navigation
  'nav.home': {
    en: 'Home',
    ar: 'الرئيسية',
    zh: '首页'
  },
  'nav.about': {
    en: 'About',
    ar: 'عنا',
    zh: '关于我们'
  },
  'nav.services': {
    en: 'Services',
    ar: 'الخدمات',
    zh: '服务'
  },
  'nav.team': {
    en: 'Team',
    ar: 'الفريق',
    zh: '团队'
  },
  'nav.contact': {
    en: 'Contact',
    ar: 'اتصل بنا',
    zh: '联系我们'
  },
  'nav.language': {
    en: 'Language',
    ar: 'اللغة',
    zh: '语言'
  },

  // Hero Section
  'hero.title': {
    en: 'Professional Opinion',
    ar: 'الرأي المهني',
    zh: '专业意见'
  },
  'hero.subtitle': {
    en: 'Expert Consultancy & Strategic Advisory',
    ar: 'الاستشارات المتخصصة والاستشارة الاستراتيجية',
    zh: '专业咨询与战略顾问'
  },
  'hero.description': {
    en: 'Transforming businesses through strategic insights, innovative solutions, and professional expertise across diverse industries.',
    ar: 'تحويل الشركات من خلال الرؤى الاستراتيجية والحلول المبتكرة والخبرة المهنية عبر الصناعات المتنوعة.',
    zh: '通过战略洞察、创新解决方案和跨行业专业知识转型企业。'
  },
  'hero.cta.primary': {
    en: 'Get Started',
    ar: 'ابدأ الآن',
    zh: '开始使用'
  },
  'hero.cta.secondary': {
    en: 'Learn More',
    ar: 'اعرف المزيد',
    zh: '了解更多'
  },

  // About Section
  'about.title': {
    en: 'About Professional Opinion',
    ar: 'عن الرأي المهني',
    zh: '关于专业意见'
  },
  'about.subtitle': {
    en: 'Excellence in Strategic Consulting',
    ar: 'التميز في الاستشارات الاستراتيجية',
    zh: '战略咨询的卓越表现'
  },
  'about.description': {
    en: 'With over two decades of experience, Professional Opinion has been at the forefront of strategic consultancy, helping organizations navigate complex challenges and achieve sustainable growth.',
    ar: 'مع أكثر من عقدين من الخبرة، كان الرأي المهني في طليعة الاستشارات الاستراتيجية، مساعدة المنظمات على التنقل في التحديات المعقدة وتحقيق النمو المستدام.',
    zh: '凭借二十多年的经验，专业意见一直处于战略咨询的前沿，帮助组织应对复杂挑战并实现可持续增长。'
  },
  'about.mission.title': {
    en: 'Our Mission',
    ar: 'مهمتنا',
    zh: '我们的使命'
  },
  'about.mission.description': {
    en: 'To deliver exceptional strategic insights and innovative solutions that drive meaningful transformation and sustainable success for our clients.',
    ar: 'تقديم رؤى استراتيجية استثنائية وحلول مبتكرة تدفع التحول الهادف والنجاح المستدام لعملائنا.',
    zh: '为客户提供卓越的战略洞察和创新解决方案，推动有意义的转型和可持续成功。'
  },
  'about.vision.title': {
    en: 'Our Vision',
    ar: 'رؤيتنا',
    zh: '我们的愿景'
  },
  'about.vision.description': {
    en: 'To be the globally recognized leader in strategic consultancy, setting new standards for excellence and innovation in professional advisory services.',
    ar: 'أن نكون الرائد المعترف به عالمياً في الاستشارات الاستراتيجية، ووضع معايير جديدة للتميز والابتكار في خدمات الاستشارة المهنية.',
    zh: '成为全球公认的战略咨询领导者，在专业顾问服务中树立卓越和创新的新标准。'
  },

  // Services Section
  'services.title': {
    en: 'Our Services',
    ar: 'خدماتنا',
    zh: '我们的服务'
  },
  'services.subtitle': {
    en: 'Comprehensive Solutions for Every Business Need',
    ar: 'حلول شاملة لكل احتياج تجاري',
    zh: '满足各种业务需求的综合解决方案'
  },
  'services.strategic.title': {
    en: 'Strategic Planning',
    ar: 'التخطيط الاستراتيجي',
    zh: '战略规划'
  },
  'services.strategic.description': {
    en: 'Comprehensive strategic planning services to align your organization with market opportunities and long-term objectives.',
    ar: 'خدمات التخطيط الاستراتيجي الشاملة لمواءمة منظمتك مع الفرص السوقية والأهداف طويلة المدى.',
    zh: '全面的战略规划服务，让您的组织与市场机会和长期目标保持一致。'
  },
  'services.business.title': {
    en: 'Business Transformation',
    ar: 'تحول الأعمال',
    zh: '业务转型'
  },
  'services.business.description': {
    en: 'Guide your organization through digital transformation and operational excellence initiatives.',
    ar: 'توجيه منظمتك من خلال التحول الرقمي ومبادرات التميز التشغيلي.',
    zh: '指导您的组织进行数字化转型和运营卓越倡议。'
  },
  'services.management.title': {
    en: 'Management Consulting',
    ar: 'الاستشارات الإدارية',
    zh: '管理咨询'
  },
  'services.management.description': {
    en: 'Expert management consulting to optimize operations, improve efficiency, and drive organizational growth.',
    ar: 'الاستشارات الإدارية المتخصصة لتحسين العمليات وتحسين الكفاءة ودفع النمو التنظيمي.',
    zh: '专业管理咨询，优化运营，提高效率，推动组织增长。'
  },
  'services.financial.title': {
    en: 'Financial Advisory',
    ar: 'الاستشارات المالية',
    zh: '财务咨询'
  },
  'services.financial.description': {
    en: 'Strategic financial planning and advisory services to enhance profitability and ensure sustainable growth.',
    ar: 'خدمات التخطيط والاستشارات المالية الاستراتيجية لتعزيز الربحية وضمان النمو المستدام.',
    zh: '战略财务规划和咨询服务，提高盈利能力并确保可持续增长。'
  },
  'services.market.title': {
    en: 'Market Analysis',
    ar: 'تحليل السوق',
    zh: '市场分析'
  },
  'services.market.description': {
    en: 'In-depth market research and analysis to identify opportunities and competitive advantages.',
    ar: 'أبحاث وتحليل السوق المتعمق لتحديد الفرص والمزايا التنافسية.',
    zh: '深入的市场研究和分析，识别机会和竞争优势。'
  },
  'services.risk.title': {
    en: 'Risk Management',
    ar: 'إدارة المخاطر',
    zh: '风险管理'
  },
  'services.risk.description': {
    en: 'Comprehensive risk assessment and management strategies to protect and strengthen your business.',
    ar: 'تقييم المخاطر الشامل واستراتيجيات الإدارة لحماية وتقوية أعمالك.',
    zh: '全面的风险评估和管理策略，保护和加强您的业务。'
  },

  // Team Section
  'team.title': {
    en: 'Our Expert Team',
    ar: 'فريقنا المتخصص',
    zh: '我们的专家团队'
  },
  'team.subtitle': {
    en: 'Meet the Professionals Behind Our Success',
    ar: 'تعرف على المحترفين وراء نجاحنا',
    zh: '了解我们成功背后的专业人士'
  },
  'team.ceo.name': {
    en: 'Dr. Sarah Johnson',
    ar: 'د. سارة جونسون',
    zh: '萨拉·约翰逊博士'
  },
  'team.ceo.title': {
    en: 'Chief Executive Officer',
    ar: 'الرئيس التنفيذي',
    zh: '首席执行官'
  },
  'team.ceo.description': {
    en: 'Strategic leader with 20+ years of experience in business transformation and organizational development.',
    ar: 'قائد استراتيجي مع أكثر من 20 عامًا من الخبرة في تحول الأعمال والتطوير التنظيمي.',
    zh: '战略领导者，拥有20多年的业务转型和组织发展经验。'
  },
  'team.cto.name': {
    en: 'Michael Chen',
    ar: 'مايكل تشين',
    zh: '迈克尔·陈'
  },
  'team.cto.title': {
    en: 'Chief Technology Officer',
    ar: 'مدير التقنية',
    zh: '首席技术官'
  },
  'team.cto.description': {
    en: 'Technology visionary specializing in digital transformation and innovative technology solutions.',
    ar: 'رؤيوي تقني متخصص في التحول الرقمي والحلول التكنولوجية المبتكرة.',
    zh: '技术远见者，专门从事数字化转型和创新技术解决方案。'
  },
  'team.cfo.name': {
    en: 'Ahmed Al-Rashid',
    ar: 'أحمد الراشد',
    zh: '艾哈迈德·拉希德'
  },
  'team.cfo.title': {
    en: 'Chief Financial Officer',
    ar: 'المدير المالي',
    zh: '首席财务官'
  },
  'team.cfo.description': {
    en: 'Financial expert with extensive experience in strategic planning and investment management.',
    ar: 'خبير مالي مع خبرة واسعة في التخطيط الاستراتيجي وإدارة الاستثمار.',
    zh: '财务专家，在战略规划和投资管理方面拥有丰富经验。'
  },
  'team.head.name': {
    en: 'Dr. Lisa Zhang',
    ar: 'د. ليزا زانغ',
    zh: '张丽莎博士'
  },
  'team.head.title': {
    en: 'Head of Strategy',
    ar: 'رئيس الاستراتيجية',
    zh: '战略主管'
  },
  'team.head.description': {
    en: 'Strategic planning specialist with expertise in market analysis and competitive intelligence.',
    ar: 'متخصص في التخطيط الاستراتيجي مع خبرة في تحليل السوق والذكاء التنافسي.',
    zh: '战略规划专家，在市场分析和竞争情报方面拥有专业知识。'
  },

  // Contact Section
  'contact.title': {
    en: 'Get in Touch',
    ar: 'تواصل معنا',
    zh: '联系我们'
  },
  'contact.subtitle': {
    en: 'Ready to Transform Your Business?',
    ar: 'مستعد لتحويل أعمالك؟',
    zh: '准备好转型您的业务了吗？'
  },
  'contact.description': {
    en: 'Contact our team of experts to discuss how we can help elevate your business to the next level.',
    ar: 'اتصل بفريق خبرائنا لمناقشة كيف يمكننا مساعدتك في رفع أعمالك إلى المستوى التالي.',
    zh: '联系我们的专家团队，讨论我们如何帮助您将业务提升到新的水平。'
  },
  'contact.info.title': {
    en: 'Contact Information',
    ar: 'معلومات الاتصال',
    zh: '联系信息'
  },
  'contact.info.address': {
    en: 'Address',
    ar: 'العنوان',
    zh: '地址'
  },
  'contact.info.phone': {
    en: 'Phone',
    ar: 'الهاتف',
    zh: '电话'
  },
  'contact.info.email': {
    en: 'Email',
    ar: 'البريد الإلكتروني',
    zh: '邮箱'
  },
  'contact.info.hours': {
    en: 'Business Hours',
    ar: 'ساعات العمل',
    zh: '营业时间'
  },
  'contact.form.title': {
    en: 'Send us a Message',
    ar: 'أرسل لنا رسالة',
    zh: '发送消息'
  },
  'contact.form.name': {
    en: 'Full Name',
    ar: 'الاسم الكامل',
    zh: '全名'
  },
  'contact.form.email': {
    en: 'Email Address',
    ar: 'عنوان البريد الإلكتروني',
    zh: '邮箱地址'
  },
  'contact.form.company': {
    en: 'Company',
    ar: 'الشركة',
    zh: '公司'
  },
  'contact.form.subject': {
    en: 'Subject',
    ar: 'الموضوع',
    zh: '主题'
  },
  'contact.form.message': {
    en: 'Message',
    ar: 'الرسالة',
    zh: '消息'
  },
  'contact.form.submit': {
    en: 'Send Message',
    ar: 'إرسال الرسالة',
    zh: '发送消息'
  },

  // Footer
  'footer.company.title': {
    en: 'Professional Opinion',
    ar: 'الرأي المهني',
    zh: '专业意见'
  },
  'footer.company.description': {
    en: 'Transforming businesses through strategic insights and professional expertise.',
    ar: 'تحويل الشركات من خلال الرؤى الاستراتيجية والخبرة المهنية.',
    zh: '通过战略洞察和专业知识转型企业。'
  },
  'footer.quicklinks.title': {
    en: 'Quick Links',
    ar: 'روابط سريعة',
    zh: '快速链接'
  },
  'footer.services.title': {
    en: 'Services',
    ar: 'الخدمات',
    zh: '服务'
  },
  'footer.contact.title': {
    en: 'Contact Info',
    ar: 'معلومات الاتصال',
    zh: '联系信息'
  },
  'footer.follow.title': {
    en: 'Follow Us',
    ar: 'تابعنا',
    zh: '关注我们'
  },
  'footer.rights': {
    en: 'All rights reserved.',
    ar: 'جميع الحقوق محفوظة.',
    zh: '保留所有权利。'
  },
  'footer.privacy': {
    en: 'Privacy Policy',
    ar: 'سياسة الخصوصية',
    zh: '隐私政策'
  },
  'footer.terms': {
    en: 'Terms of Service',
    ar: 'شروط الخدمة',
    zh: '服务条款'
  },

  // Professional Opinion Specific Content
  'company.tagline': {
    en: 'Your Partner in Strategic Excellence',
    ar: 'شريكك في التميز الاستراتيجي',
    zh: '您的战略卓越合作伙伴'
  },
  'company.established': {
    en: 'Established {{year}}',
    ar: 'تأسست {{year}}',
    zh: '成立于{{year}}年'
  },
  'company.clients': {
    en: '{{count}}+ Satisfied Clients',
    ar: '{{count}}+ عميل راض',
    zh: '{{count}}+满意客户'
  },
  'company.projects': {
    en: '{{count}}+ Successful Projects',
    ar: '{{count}}+ مشروع ناجح',
    zh: '{{count}}+成功项目'
  },
  'company.industries': {
    en: '{{count}}+ Industries Served',
    ar: '{{count}}+ صناعة خدمناها',
    zh: '{{count}}+服务行业'
  },

  // Call to Action
  'cta.consultation': {
    en: 'Schedule Free Consultation',
    ar: 'حدد موعد استشارة مجانية',
    zh: '安排免费咨询'
  },
  'cta.proposal': {
    en: 'Request Proposal',
    ar: 'طلب اقتراح',
    zh: '请求提案'
  },
  'cta.download': {
    en: 'Download Brochure',
    ar: 'تحميل الكتيب',
    zh: '下载手册'
  },

  // Status Messages
  'status.loading': {
    en: 'Loading...',
    ar: 'جاري التحميل...',
    zh: '加载中...'
  },
  'status.success': {
    en: 'Success!',
    ar: 'نجح!',
    zh: '成功！'
  },
  'status.error': {
    en: 'Error occurred',
    ar: 'حدث خطأ',
    zh: '发生错误'
  },
  'status.sent': {
    en: 'Message sent successfully',
    ar: 'تم إرسال الرسالة بنجاح',
    zh: '消息发送成功'
  },

  // Common Actions
  'action.read_more': {
    en: 'Read More',
    ar: 'اقرأ المزيد',
    zh: '阅读更多'
  },
  'action.view_all': {
    en: 'View All',
    ar: 'عرض الكل',
    zh: '查看全部'
  },
  'action.back': {
    en: 'Back',
    ar: 'رجوع',
    zh: '返回'
  },
  'action.next': {
    en: 'Next',
    ar: 'التالي',
    zh: '下一个'
  },
  'action.close': {
    en: 'Close',
    ar: 'إغلاق',
    zh: '关闭'
  },
  'action.save': {
    en: 'Save',
    ar: 'حفظ',
    zh: '保存'
  },
  'action.cancel': {
    en: 'Cancel',
    ar: 'إلغاء',
    zh: '取消'
  },

  // Testimonials
  'testimonials.title': {
    en: 'What Our Clients Say',
    ar: 'ما يقوله عملاؤنا',
    zh: '客户评价'
  },
  'testimonials.subtitle': {
    en: 'Trusted by Industry Leaders',
    ar: 'موثوق به من قبل قادة الصناعة',
    zh: '受到行业领袖信任'
  },

  // Expertise Areas
  'expertise.title': {
    en: 'Our Expertise',
    ar: 'خبرتنا',
    zh: '我们的专业领域'
  },
  'expertise.years': {
    en: '{{count}} Years of Experience',
    ar: '{{count}} سنوات من الخبرة',
    zh: '{{count}}年经验'
  },
  'expertise.international': {
    en: 'International Reach',
    ar: 'انتشار دولي',
    zh: '国际影响力'
  },
  'expertise.certified': {
    en: 'Certified Professionals',
    ar: 'محترفون معتمدون',
    zh: '认证专业人士'
  },

  // Industries
  'industries.title': {
    en: 'Industries We Serve',
    ar: 'الصناعات التي نخدمها',
    zh: '我们服务的行业'
  },
  'industries.healthcare': {
    en: 'Healthcare',
    ar: 'الرعاية الصحية',
    zh: '医疗保健'
  },
  'industries.finance': {
    en: 'Finance',
    ar: 'المالية',
    zh: '金融'
  },
  'industries.technology': {
    en: 'Technology',
    ar: 'التكنولوجيا',
    zh: '技术'
  },
  'industries.manufacturing': {
    en: 'Manufacturing',
    ar: 'التصنيع',
    zh: '制造业'
  },
  'industries.retail': {
    en: 'Retail',
    ar: 'التجارة',
    zh: '零售'
  },
  'industries.energy': {
    en: 'Energy',
    ar: 'الطاقة',
    zh: '能源'
  }
};

interface LanguageProviderProps {
  children: ReactNode;
}

export const LanguageProvider = ({ children }: LanguageProviderProps) => {
  const [language, setLanguageState] = useState<Language>('en');

  useEffect(() => {
    // Load language preference from localStorage
    const savedLanguage = localStorage.getItem('preferred-language') as Language;
    if (savedLanguage && ['en', 'ar', 'zh'].includes(savedLanguage)) {
      setLanguageState(savedLanguage);
    }
  }, []);

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
    localStorage.setItem('preferred-language', lang);
    
    // Update document direction for RTL
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
    document.documentElement.lang = lang;
  };

  const t = (key: string, params?: Record<string, string>): string => {
    const translation = translations[key];
    if (!translation) {
      console.warn(`Translation key "${key}" not found`);
      return key;
    }

    let text = translation[language];
    
    // Handle interpolation
    if (params) {
      Object.entries(params).forEach(([paramKey, paramValue]) => {
        text = text.replace(`{{${paramKey}}}`, paramValue);
      });
    }

    return text;
  };

  const isRTL = language === 'ar';

  const value: LanguageContextType = {
    language,
    setLanguage,
    t,
    isRTL
  };

  return (
    <LanguageContext.Provider value={value}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};

export default LanguageProvider;