"use client";

import { createContext, useContext, useEffect, useRef, useState } from "react";
import AOS from "aos";
import "aos/dist/aos.css";

interface AOSConfig {
  duration: number;
  easing: string;
  offset: number;
  delay: number;
  once: boolean;
  disable: boolean | string;
  startEvent: string;
  throttleDelay: number;
  debounceDelay: number;
  disableMutationObserver: boolean;
}

interface AOSContextType {
  refresh: () => void;
  refreshHard: () => void;
  init: (config?: Partial<AOSConfig>) => void;
  isInitialized: boolean;
  animateElement: (element: HTMLElement, animation: string) => void;
  removeAnimation: (element: HTMLElement) => void;
  config: AOSConfig;
}

const defaultConfig: AOSConfig = {
  duration: 800,
  easing: "ease-out",
  offset: 100,
  delay: 0,
  once: true,
  disable: false,
  startEvent: "DOMContentLoaded",
  throttleDelay: 99,
  debounceDelay: 50,
  disableMutationObserver: false,
};

const AOSContext = createContext<AOSContextType | undefined>(undefined);

interface AOSProviderProps {
  children: React.ReactNode;
  config?: Partial<AOSConfig>;
  disableOnMobile?: boolean;
}

export const AOSProvider = ({ 
  children, 
  config = {}, 
  disableOnMobile = true 
}: AOSProviderProps) => {
  const [isInitialized, setIsInitialized] = useState(false);
  const configRef = useRef<AOSConfig>({ ...defaultConfig, ...config });
  const initTimeoutRef = useRef<NodeJS.Timeout>();

  // Update config with mobile detection
  useEffect(() => {
    if (disableOnMobile) {
      const isMobile = window.innerWidth <= 768;
      configRef.current = {
        ...configRef.current,
        disable: isMobile ? true : configRef.current.disable,
        duration: isMobile ? 400 : configRef.current.duration,
      };
    }
  }, [disableOnMobile]);

  // Initialize AOS
  const initAOS = (newConfig?: Partial<AOSConfig>) => {
    if (typeof window === "undefined") return;

    if (newConfig) {
      configRef.current = { ...configRef.current, ...newConfig };
    }

    try {
      AOS.init(configRef.current);
      setIsInitialized(true);
    } catch (error) {
      console.error("Failed to initialize AOS:", error);
    }
  };

  // Refresh AOS
  const refreshAOS = () => {
    if (isInitialized) {
      AOS.refresh();
    }
  };

  // Hard refresh (reinitialize)
  const refreshHardAOS = () => {
    if (typeof window === "undefined") return;
    
    try {
      AOS.refreshHard();
    } catch (error) {
      console.error("Failed to hard refresh AOS:", error);
    }
  };

  // Manually animate element
  const animateElement = (element: HTMLElement, animation: string) => {
    if (!element) return;

    element.setAttribute("data-aos", animation);
    element.setAttribute("data-aos-duration", configRef.current.duration.toString());
    element.setAttribute("data-aos-easing", configRef.current.easing);
    element.setAttribute("data-aos-offset", configRef.current.offset.toString());
    
    if (isInitialized) {
      AOS.refresh();
    }
  };

  // Remove animation from element
  const removeAnimation = (element: HTMLElement) => {
    if (!element) return;

    element.removeAttribute("data-aos");
    element.removeAttribute("data-aos-duration");
    element.removeAttribute("data-aos-easing");
    element.removeAttribute("data-aos-offset");
    element.removeAttribute("data-aos-delay");
    element.removeAttribute("data-aos-once");
    element.removeAttribute("data-aos-anchor");
    element.removeAttribute("data-aos-anchor-placement");
    
    if (isInitialized) {
      AOS.refresh();
    }
  };

  // Initialize on mount
  useEffect(() => {
    // Small delay to ensure DOM is ready
    initTimeoutRef.current = setTimeout(() => {
      initAOS();
    }, 100);

    return () => {
      if (initTimeoutRef.current) {
        clearTimeout(initTimeoutRef.current);
      }
    };
  }, []);

  // Handle window resize for mobile detection
  useEffect(() => {
    if (!disableOnMobile) return;

    const handleResize = () => {
      const isMobile = window.innerWidth <= 768;
      const shouldDisable = isMobile;
      
      if (shouldDisable !== (configRef.current.disable === true)) {
        configRef.current = {
          ...configRef.current,
          disable: shouldDisable,
          duration: isMobile ? 400 : defaultConfig.duration,
        };
        
        if (isInitialized) {
          refreshHardAOS();
        }
      }
    };

    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, [disableOnMobile, isInitialized]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (initTimeoutRef.current) {
        clearTimeout(initTimeoutRef.current);
      }
    };
  }, []);

  const contextValue: AOSContextType = {
    refresh: refreshAOS,
    refreshHard: refreshHardAOS,
    init: initAOS,
    isInitialized,
    animateElement,
    removeAnimation,
    config: configRef.current,
  };

  return (
    <AOSContext.Provider value={contextValue}>
      {children}
    </AOSContext.Provider>
  );
};

// Hook to use AOS context
export const useAOS = (): AOSContextType => {
  const context = useContext(AOSContext);
  if (!context) {
    throw new Error("useAOS must be used within an AOSProvider");
  }
  return context;
};

// Hook for element animations
export const useAOSAnimation = (
  animation: string = "fade-up",
  options: {
    duration?: number;
    delay?: number;
    easing?: string;
    offset?: number;
    once?: boolean;
    anchor?: string;
    anchorPlacement?: string;
  } = {}
) => {
  const { config, isInitialized, refresh } = useAOS();
  const elementRef = useRef<HTMLElement>(null);

  useEffect(() => {
    if (!elementRef.current || !isInitialized) return;

    const element = elementRef.current;
    
    // Set animation attributes
    element.setAttribute("data-aos", animation);
    element.setAttribute("data-aos-duration", (options.duration || config.duration).toString());
    element.setAttribute("data-aos-easing", options.easing || config.easing);
    element.setAttribute("data-aos-offset", (options.offset || config.offset).toString());
    
    if (options.delay !== undefined) {
      element.setAttribute("data-aos-delay", options.delay.toString());
    }
    
    if (options.once !== undefined) {
      element.setAttribute("data-aos-once", options.once.toString());
    }
    
    if (options.anchor) {
      element.setAttribute("data-aos-anchor", options.anchor);
    }
    
    if (options.anchorPlacement) {
      element.setAttribute("data-aos-anchor-placement", options.anchorPlacement);
    }

    // Refresh AOS to apply changes
    refresh();
  }, [animation, options, config, isInitialized, refresh]);

  return elementRef;
};

// Utility hook for manual animation control
export const useAOSControl = () => {
  const { animateElement, removeAnimation, refresh } = useAOS();

  const triggerAnimation = (element: HTMLElement, animation: string, options?: {
    duration?: number;
    delay?: number;
    easing?: string;
    offset?: number;
  }) => {
    if (!element) return;

    animateElement(element, animation);
    
    if (options) {
      if (options.duration !== undefined) {
        element.setAttribute("data-aos-duration", options.duration.toString());
      }
      if (options.delay !== undefined) {
        element.setAttribute("data-aos-delay", options.delay.toString());
      }
      if (options.easing) {
        element.setAttribute("data-aos-easing", options.easing);
      }
      if (options.offset !== undefined) {
        element.setAttribute("data-aos-offset", options.offset.toString());
      }
    }
    
    refresh();
  };

  const clearAnimation = (element: HTMLElement) => {
    removeAnimation(element);
    refresh();
  };

  return {
    triggerAnimation,
    clearAnimation,
    refresh,
  };
};

// Common animation presets
export const AOSAnimations = {
  // Fade animations
  fadeIn: "fade",
  fadeUp: "fade-up",
  fadeDown: "fade-down",
  fadeLeft: "fade-left",
  fadeRight: "fade-right",
  fadeUpRight: "fade-up-right",
  fadeUpLeft: "fade-up-left",
  fadeDownRight: "fade-down-right",
  fadeDownLeft: "fade-down-left",
  
  // Slide animations
  slideUp: "slide-up",
  slideDown: "slide-down",
  slideLeft: "slide-left",
  slideRight: "slide-right",
  
  // Zoom animations
  zoomIn: "zoom-in",
  zoomOut: "zoom-out",
  zoomInUp: "zoom-in-up",
  zoomInDown: "zoom-in-down",
  zoomInLeft: "zoom-in-left",
  zoomInRight: "zoom-in-right",
  zoomOutUp: "zoom-out-up",
  zoomOutDown: "zoom-out-down",
  zoomOutLeft: "zoom-out-left",
  zoomOutRight: "zoom-out-right",
  
  // Flip animations
  flipLeft: "flip-left",
  flipRight: "flip-right",
  flipUp: "flip-up",
  flipDown: "flip-down",
} as const;

export type AOSAnimation = typeof AOSAnimations[keyof typeof AOSAnimations];