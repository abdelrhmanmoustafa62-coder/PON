"use client";

import React, { createContext, useContext, useEffect, useState, useCallback } from 'react';

type Theme = 'light' | 'dark' | 'system';

interface ThemeContextType {
  theme: Theme;
  resolvedTheme: 'light' | 'dark';
  setTheme: (theme: Theme) => void;
  toggleTheme: () => void;
  systemTheme: 'light' | 'dark';
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

const THEME_STORAGE_KEY = 'theme-preference';

interface ThemeProviderProps {
  children: React.ReactNode;
  defaultTheme?: Theme;
  storageKey?: string;
  enableSystem?: boolean;
}

export const ThemeProvider: React.FC<ThemeProviderProps> = ({
  children,
  defaultTheme = 'system',
  storageKey = THEME_STORAGE_KEY,
  enableSystem = true,
}) => {
  const [theme, setThemeState] = useState<Theme>(defaultTheme);
  const [systemTheme, setSystemTheme] = useState<'light' | 'dark'>('light');
  const [isHydrated, setIsHydrated] = useState(false);

  // Get system theme preference
  const getSystemTheme = useCallback((): 'light' | 'dark' => {
    if (typeof window === 'undefined') return 'light';
    return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
  }, []);

  // Resolve the actual theme to apply
  const resolvedTheme = theme === 'system' ? systemTheme : theme;

  // Apply theme to document
  const applyTheme = useCallback((newTheme: 'light' | 'dark') => {
    if (typeof document === 'undefined') return;

    const root = document.documentElement;
    
    // Add smooth transition
    root.style.transition = 'background-color 0.3s ease, color 0.3s ease';
    
    // Remove existing theme classes
    root.classList.remove('light', 'dark');
    
    // Add new theme class
    root.classList.add(newTheme);
    
    // Set data attribute for additional styling
    root.setAttribute('data-theme', newTheme);
    
    // Update meta theme-color for mobile browsers
    const metaThemeColor = document.querySelector('meta[name="theme-color"]');
    if (metaThemeColor) {
      metaThemeColor.setAttribute(
        'content',
        newTheme === 'dark' ? '#0f172a' : '#ffffff'
      );
    }
    
    // Remove transition after animation completes
    setTimeout(() => {
      root.style.transition = '';
    }, 300);
  }, []);

  // Set theme with persistence
  const setTheme = useCallback((newTheme: Theme) => {
    setThemeState(newTheme);
    
    if (typeof window !== 'undefined') {
      if (newTheme === 'system') {
        localStorage.removeItem(storageKey);
      } else {
        localStorage.setItem(storageKey, newTheme);
      }
    }
  }, [storageKey]);

  // Toggle between light and dark (skip system)
  const toggleTheme = useCallback(() => {
    const newTheme = resolvedTheme === 'light' ? 'dark' : 'light';
    setTheme(newTheme);
  }, [resolvedTheme, setTheme]);

  // Initialize theme from localStorage and system preference
  useEffect(() => {
    if (typeof window === 'undefined') return;

    const savedTheme = localStorage.getItem(storageKey) as Theme;
    const currentSystemTheme = getSystemTheme();
    
    setSystemTheme(currentSystemTheme);
    
    if (savedTheme && (savedTheme === 'light' || savedTheme === 'dark')) {
      setThemeState(savedTheme);
    } else if (enableSystem) {
      setThemeState('system');
    }
    
    setIsHydrated(true);
  }, [storageKey, enableSystem, getSystemTheme]);

  // Listen for system theme changes
  useEffect(() => {
    if (typeof window === 'undefined' || !enableSystem) return;

    const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
    
    const handleChange = (e: MediaQueryListEvent) => {
      setSystemTheme(e.matches ? 'dark' : 'light');
    };

    mediaQuery.addEventListener('change', handleChange);
    return () => mediaQuery.removeEventListener('change', handleChange);
  }, [enableSystem]);

  // Apply theme when resolved theme changes
  useEffect(() => {
    if (!isHydrated) return;
    applyTheme(resolvedTheme);
  }, [resolvedTheme, applyTheme, isHydrated]);

  // Prevent hydration mismatch
  if (!isHydrated) {
    return <div style={{ visibility: 'hidden' }}>{children}</div>;
  }

  const value: ThemeContextType = {
    theme,
    resolvedTheme,
    setTheme,
    toggleTheme,
    systemTheme,
  };

  return (
    <ThemeContext.Provider value={value}>
      {children}
    </ThemeContext.Provider>
  );
};

// Custom hook to use theme context
export const useTheme = (): ThemeContextType => {
  const context = useContext(ThemeContext);
  if (!context) {
    throw new Error('useTheme must be used within a ThemeProvider');
  }
  return context;
};

// Theme-aware styling utilities
export const themeClasses = {
  // Background variants
  bg: {
    primary: 'bg-background',
    secondary: 'bg-secondary',
    muted: 'bg-muted',
    accent: 'bg-accent',
    card: 'bg-card',
    navy: 'bg-navy dark:bg-slate-800',
    gold: 'bg-gold dark:bg-amber-600',
    lightGray: 'bg-light-gray dark:bg-slate-700',
  },
  
  // Text variants
  text: {
    primary: 'text-foreground',
    secondary: 'text-secondary-foreground',
    muted: 'text-muted-foreground',
    accent: 'text-accent-foreground',
    navy: 'text-navy dark:text-slate-200',
    gold: 'text-gold dark:text-amber-400',
    inverse: 'text-background dark:text-foreground',
  },
  
  // Border variants
  border: {
    default: 'border-border',
    muted: 'border-muted',
    accent: 'border-accent',
    navy: 'border-navy dark:border-slate-600',
    gold: 'border-gold dark:border-amber-600',
  },
  
  // Interactive states
  hover: {
    bg: 'hover:bg-accent/10 dark:hover:bg-accent/20',
    text: 'hover:text-accent dark:hover:text-accent',
    border: 'hover:border-accent dark:hover:border-accent',
  },
  
  // Transitions
  transitions: {
    colors: 'transition-colors duration-300 ease-in-out',
    all: 'transition-all duration-300 ease-in-out',
    theme: 'transition-[background-color,color,border-color] duration-300 ease-in-out',
  },
  
  // Shadows with theme awareness
  shadow: {
    sm: 'shadow-sm dark:shadow-slate-900/20',
    md: 'shadow-md dark:shadow-slate-900/30',
    lg: 'shadow-lg dark:shadow-slate-900/40',
    xl: 'shadow-xl dark:shadow-slate-900/50',
  },
};

// Utility function to combine theme classes
export const cn = (...classes: (string | undefined | false)[]): string => {
  return classes.filter(Boolean).join(' ');
};

// Theme-aware component wrapper
export const ThemeAware: React.FC<{
  children: React.ReactNode;
  className?: string;
}> = ({ children, className = '' }) => {
  const { resolvedTheme } = useTheme();
  
  return (
    <div 
      className={cn(
        themeClasses.transitions.theme,
        className
      )}
      data-theme={resolvedTheme}
    >
      {children}
    </div>
  );
};

// Custom hook for theme-aware styles
export const useThemeStyles = () => {
  const { resolvedTheme } = useTheme();
  
  return {
    isDark: resolvedTheme === 'dark',
    isLight: resolvedTheme === 'light',
    themeClasses,
    cn,
  };
};