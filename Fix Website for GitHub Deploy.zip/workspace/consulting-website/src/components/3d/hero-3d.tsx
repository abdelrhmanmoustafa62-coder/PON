"use client";

import { useRef, useEffect, useState } from 'react';

// Simple animated logo background component
export const Hero3D = () => {
  const [isLoaded, setIsLoaded] = useState(false);
  const circleRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    setIsLoaded(true);
    
    // Simple mouse movement animation
    const handleMouseMove = (e: MouseEvent) => {
      if (circleRef.current) {
        const { clientX, clientY } = e;
        const { innerWidth, innerHeight } = window;
        
        const x = (clientX / innerWidth) * 20 - 10;
        const y = (clientY / innerHeight) * 20 - 10;
        
        circleRef.current.style.transform = `translate(${x}px, ${y}px) rotate(${Date.now() * 0.001}rad)`;
      }
    };

    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  if (!isLoaded) {
    return (
      <div className="torus-knot">
        <div className="w-full h-full flex items-center justify-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-[#FBBA00]"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="torus-knot overflow-hidden">
      <div className="w-full h-full flex items-center justify-center relative">
        {/* Animated Background Elements */}
        <div className="absolute inset-0 opacity-20">
          <div className="absolute top-1/4 left-1/4 w-4 h-4 bg-[#FBBA00] rounded-full animate-pulse"></div>
          <div className="absolute top-3/4 right-1/4 w-6 h-6 bg-[#0093A7] rounded-full animate-pulse" style={{ animationDelay: '500ms' }}></div>
          <div className="absolute bottom-1/4 left-3/4 w-3 h-3 bg-white rounded-full animate-pulse" style={{ animationDelay: '1000ms' }}></div>
        </div>
        
        {/* Main Interactive Element */}
        <div 
          ref={circleRef}
          className="relative transition-transform duration-75 ease-out"
          style={{
            animation: 'float 6s ease-in-out infinite'
          }}
        >
          {/* Outer Ring */}
          <div className="w-64 h-64 border-4 border-[#FBBA00] rounded-full absolute opacity-30 animate-spin" style={{ animationDuration: '20s' }}></div>
          
          {/* Middle Ring */}
          <div className="w-48 h-48 border-2 border-[#0093A7] rounded-full absolute top-8 left-8 opacity-50 animate-spin" style={{ animationDuration: '15s', animationDirection: 'reverse' }}></div>
          
          {/* Inner Content */}
          <div className="w-32 h-32 bg-gradient-to-br from-[#FBBA00] to-[#005A77] rounded-full absolute top-16 left-16 flex items-center justify-center shadow-2xl">
            <span className="text-white text-4xl font-bold">PO</span>
          </div>
          
          {/* Floating Particles */}
          <div className="absolute -top-4 -left-4 w-2 h-2 bg-[#FBBA00] rounded-full animate-bounce"></div>
          <div className="absolute -bottom-4 -right-4 w-2 h-2 bg-[#0093A7] rounded-full animate-bounce" style={{ animationDelay: '700ms' }}></div>
        </div>
        
        {/* Subtitle */}
        <div className="absolute bottom-24 text-center text-white/80">
          <p className="text-lg font-semibold">Professional Opinion</p>
          <p className="text-sm">Strategic Solutions</p>
        </div>
      </div>
    </div>
  );
};