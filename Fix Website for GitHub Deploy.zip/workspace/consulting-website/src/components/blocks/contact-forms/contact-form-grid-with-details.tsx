"use client";
import React, { useState } from "react";
import { Mail, Globe, Phone, MapPin, ChevronDown } from "lucide-react";
import { useId } from "react";
import { cn } from "@/lib/utils";
import { motion } from "motion/react";

const translations = {
  en: {
    contactUs: "Contact Us",
    description: "We're here to help you transform your business with our comprehensive consulting services. Get in touch with us today.",
    name: "Full Name",
    email: "Email Address", 
    company: "Company",
    serviceInterest: "Service Interest",
    message: "Message",
    submit: "Send Message",
    namePlaceholder: "John Doe",
    emailPlaceholder: "john@company.com",
    companyPlaceholder: "Your Company Name",
    messagePlaceholder: "Tell us about your project...",
    address: "Business Address",
    phone: "Phone Number",
    emailContact: "Email",
    services: {
      strategy: "Business Strategy",
      digital: "Digital Transformation",
      operations: "Operations Optimization", 
      finance: "Financial Advisory",
      technology: "Technology Implementation",
      other: "Other Services"
    }
  },
  ar: {
    contactUs: "تواصل معنا",
    description: "نحن هنا لمساعدتك في تحويل عملك من خلال خدماتنا الاستشارية الشاملة. تواصل معنا اليوم.",
    name: "الاسم الكامل",
    email: "عنوان البريد الإلكتروني",
    company: "الشركة",
    serviceInterest: "الخدمة المطلوبة",
    message: "الرسالة",
    submit: "إرسال الرسالة",
    namePlaceholder: "أحمد محمد",
    emailPlaceholder: "ahmed@company.com",
    companyPlaceholder: "اسم شركتك",
    messagePlaceholder: "أخبرنا عن مشروعك...",
    address: "عنوان العمل",
    phone: "رقم الهاتف",
    emailContact: "البريد الإلكتروني",
    services: {
      strategy: "الاستراتيجية التجارية",
      digital: "التحول الرقمي",
      operations: "تحسين العمليات",
      finance: "الاستشارات المالية",
      technology: "تنفيذ التكنولوجيا",
      other: "خدمات أخرى"
    }
  },
  zh: {
    contactUs: "联系我们",
    description: "我们致力于通过全面的咨询服务帮助您转型业务。立即联系我们。",
    name: "姓名",
    email: "邮箱地址",
    company: "公司",
    serviceInterest: "服务需求",
    message: "留言",
    submit: "发送消息",
    namePlaceholder: "张三",
    emailPlaceholder: "zhang@company.com",
    companyPlaceholder: "您的公司名称",
    messagePlaceholder: "告诉我们您的项目...",
    address: "业务地址",
    phone: "电话号码",
    emailContact: "邮箱",
    services: {
      strategy: "商业策略",
      digital: "数字化转型",
      operations: "运营优化",
      finance: "财务咨询",
      technology: "技术实施",
      other: "其他服务"
    }
  }
};

export function ContactFormGridWithDetails() {
  const [selectedLanguage, setSelectedLanguage] = useState<'en' | 'ar' | 'zh'>('en');
  const [selectedService, setSelectedService] = useState('');
  const [isServiceDropdownOpen, setIsServiceDropdownOpen] = useState(false);
  const [isLanguageDropdownOpen, setIsLanguageDropdownOpen] = useState(false);

  const t = translations[selectedLanguage];

  return (
    <div className="bg-white dark:bg-slate-900">
      <div className="mx-auto grid w-full max-w-7xl grid-cols-1 gap-10 px-4 py-10 md:px-6 md:py-20 lg:grid-cols-2">
        {/* Left Column - Maps and Contact Info */}
        <div className="relative flex flex-col items-center overflow-hidden lg:items-start">
          <div className="flex items-start justify-start">
            <FeatureIconContainer className="flex items-center justify-center overflow-hidden">
              <Mail className="h-6 w-6 text-gold" />
            </FeatureIconContainer>
          </div>
          <h2 className="mt-9 bg-gradient-to-b from-navy to-slate-800 bg-clip-text text-left text-xl font-bold text-transparent md:text-3xl lg:text-5xl dark:from-white dark:to-slate-200">
            {t.contactUs}
          </h2>
          <p className="mt-8 max-w-lg text-center text-base text-slate-600 md:text-left dark:text-slate-300">
            {t.description}
          </p>

          {/* Language Selector */}
          <div className="mt-6 relative">
            <button
              onClick={() => setIsLanguageDropdownOpen(!isLanguageDropdownOpen)}
              className="flex items-center gap-2 px-4 py-2 rounded-lg bg-light-gray border border-slate-300 text-navy hover:bg-slate-100 transition-colors dark:bg-slate-800 dark:border-slate-600 dark:text-white"
            >
              <Globe className="h-4 w-4" />
              <span className="text-sm font-medium">
                {selectedLanguage === 'en' ? 'English' : selectedLanguage === 'ar' ? 'العربية' : '中文'}
              </span>
              <ChevronDown className="h-4 w-4" />
            </button>
            {isLanguageDropdownOpen && (
              <div className="absolute top-full left-0 mt-2 w-40 bg-white rounded-lg shadow-lg border border-slate-200 z-50 dark:bg-slate-800 dark:border-slate-600">
                <button
                  onClick={() => { setSelectedLanguage('en'); setIsLanguageDropdownOpen(false); }}
                  className="w-full px-4 py-2 text-left hover:bg-light-gray rounded-t-lg text-navy dark:text-white dark:hover:bg-slate-700"
                >
                  English
                </button>
                <button
                  onClick={() => { setSelectedLanguage('ar'); setIsLanguageDropdownOpen(false); }}
                  className="w-full px-4 py-2 text-left hover:bg-light-gray text-navy dark:text-white dark:hover:bg-slate-700"
                >
                  العربية
                </button>
                <button
                  onClick={() => { setSelectedLanguage('zh'); setIsLanguageDropdownOpen(false); }}
                  className="w-full px-4 py-2 text-left hover:bg-light-gray rounded-b-lg text-navy dark:text-white dark:hover:bg-slate-700"
                >
                  中文
                </button>
              </div>
            )}
          </div>

          {/* Google Maps Integration - Riyadh Office */}
          <div className="mt-10 w-full max-w-lg">
            <div className="aspect-video rounded-lg overflow-hidden border-2 border-slate-200 dark:border-slate-700">
              <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3624.9463829823643!2d46.6756!3d24.7136!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3e2f03890d489399%3A0xba974d1c98e79fd5!2sTulip%20Tower%2C%20Riyadh%20Saudi%20Arabia!5e0!3m2!1sen!2sus!4v1623456789012!5m2!1sen!2sus"
                width="100%"
                height="100%"
                style={{ border: 0 }}
                allowFullScreen
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                className="rounded-lg"
                title="Professional Opinion Office Location - Riyadh"
              />
            </div>
          </div>

          {/* Contact Details - Professional Opinion */}
          <div className="mt-8 w-full max-w-lg space-y-4">
            <div className="flex items-center gap-3">
              <div className="flex items-center justify-center w-10 h-10 rounded-full bg-gold/10">
                <MapPin className="h-5 w-5 text-gold" />
              </div>
              <div>
                <p className="text-sm font-medium text-navy dark:text-white">{t.address}</p>
                <p className="text-sm text-slate-600 dark:text-slate-300">6th Floor - Tulip Tower</p>
                <p className="text-sm text-slate-600 dark:text-slate-300">PO Box 18025, Riyadh 11415 – KSA</p>
              </div>
            </div>
            
            <div className="flex items-center gap-3">
              <div className="flex items-center justify-center w-10 h-10 rounded-full bg-gold/10">
                <Phone className="h-5 w-5 text-gold" />
              </div>
              <div>
                <p className="text-sm font-medium text-navy dark:text-white">{t.phone}</p>
                <p className="text-sm text-slate-600 dark:text-slate-300">920005122</p>
                <p className="text-sm text-slate-600 dark:text-slate-300">+966 11 200 2111</p>
              </div>
            </div>
            
            <div className="flex items-center gap-3">
              <div className="flex items-center justify-center w-10 h-10 rounded-full bg-gold/10">
                <Mail className="h-5 w-5 text-gold" />
              </div>
              <div>
                <p className="text-sm font-medium text-navy dark:text-white">{t.emailContact}</p>
                <p className="text-sm text-slate-600 dark:text-slate-300">info@po.sa</p>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column - Form */}
        <div className="relative mx-auto flex w-full max-w-2xl flex-col items-start gap-4 overflow-hidden rounded-3xl bg-gradient-to-b from-light-gray to-slate-100 p-4 sm:p-10 dark:from-slate-800 dark:to-slate-900">
          <Grid size={20} />
          
          <div className="relative z-20 mb-4 w-full">
            <label
              className="mb-2 inline-block text-sm font-medium text-navy dark:text-white"
              htmlFor="name"
            >
              {t.name}
            </label>
            <input
              id="name"
              type="text"
              placeholder={t.namePlaceholder}
              className="shadow-input h-10 w-full rounded-md border border-slate-200 bg-white pl-4 text-sm text-navy placeholder-slate-500 outline-none focus:ring-2 focus:ring-gold focus:border-gold transition-colors dark:border-slate-600 dark:bg-slate-700 dark:text-white"
            />
          </div>
          
          <div className="relative z-20 mb-4 w-full">
            <label
              className="mb-2 inline-block text-sm font-medium text-navy dark:text-white"
              htmlFor="email"
            >
              {t.email}
            </label>
            <input
              id="email"
              type="email"
              placeholder={t.emailPlaceholder}
              className="shadow-input h-10 w-full rounded-md border border-slate-200 bg-white pl-4 text-sm text-navy placeholder-slate-500 outline-none focus:ring-2 focus:ring-gold focus:border-gold transition-colors dark:border-slate-600 dark:bg-slate-700 dark:text-white"
            />
          </div>
          
          <div className="relative z-20 mb-4 w-full">
            <label
              className="mb-2 inline-block text-sm font-medium text-navy dark:text-white"
              htmlFor="company"
            >
              {t.company}
            </label>
            <input
              id="company"
              type="text"
              placeholder={t.companyPlaceholder}
              className="shadow-input h-10 w-full rounded-md border border-slate-200 bg-white pl-4 text-sm text-navy placeholder-slate-500 outline-none focus:ring-2 focus:ring-gold focus:border-gold transition-colors dark:border-slate-600 dark:bg-slate-700 dark:text-white"
            />
          </div>
          
          <div className="relative z-20 mb-4 w-full">
            <label
              className="mb-2 inline-block text-sm font-medium text-navy dark:text-white"
              htmlFor="service"
            >
              {t.serviceInterest}
            </label>
            <div className="relative">
              <button
                onClick={() => setIsServiceDropdownOpen(!isServiceDropdownOpen)}
                className="shadow-input h-10 w-full rounded-md border border-slate-200 bg-white pl-4 pr-10 text-sm text-navy text-left outline-none focus:ring-2 focus:ring-gold focus:border-gold transition-colors dark:border-slate-600 dark:bg-slate-700 dark:text-white"
              >
                {selectedService || "Select a service..."}
              </button>
              <ChevronDown className="absolute right-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-slate-500 pointer-events-none" />
              {isServiceDropdownOpen && (
                <div className="absolute top-full left-0 right-0 mt-1 bg-white rounded-md shadow-lg border border-slate-200 z-50 dark:bg-slate-700 dark:border-slate-600">
                  {Object.entries(t.services).map(([key, value]) => (
                    <button
                      key={key}
                      onClick={() => { setSelectedService(value); setIsServiceDropdownOpen(false); }}
                      className="w-full px-4 py-2 text-left hover:bg-light-gray text-navy dark:text-white dark:hover:bg-slate-600"
                    >
                      {value}
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>
          
          <div className="relative z-20 mb-4 w-full">
            <label
              className="mb-2 inline-block text-sm font-medium text-navy dark:text-white"
              htmlFor="message"
            >
              {t.message}
            </label>
            <textarea
              id="message"
              rows={5}
              placeholder={t.messagePlaceholder}
              className="shadow-input w-full rounded-md border border-slate-200 bg-white pt-4 pl-4 text-sm text-navy placeholder-slate-500 outline-none focus:ring-2 focus:ring-gold focus:border-gold transition-colors dark:border-slate-600 dark:bg-slate-700 dark:text-white"
            />
          </div>
          
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            className="relative z-10 flex items-center justify-center rounded-md border border-transparent bg-gold px-6 py-3 text-sm font-medium text-white shadow-lg transition-all duration-200 hover:bg-yellow-600 hover:shadow-xl"
          >
            {t.submit}
          </motion.button>
        </div>
      </div>
    </div>
  );
}

const Pin = ({ className }: { className?: string }) => {
  return (
    <motion.div
      style={{ transform: "translateZ(1px)" }}
      className={cn(
        "pointer-events-none absolute z-[60] flex h-40 w-96 items-center justify-center opacity-100 transition duration-500",
        className
      )}
    >
      <div className="h-full w-full">
        <div className="absolute inset-x-0 top-0 z-20 mx-auto inline-block w-fit rounded-lg bg-neutral-200 px-2 py-1 text-xs font-normal text-neutral-700 dark:bg-neutral-800 dark:text-white">
          We are here
          <span className="absolute -bottom-0 left-[1.125rem] h-px w-[calc(100%-2.25rem)] bg-gradient-to-r from-blue-400/0 via-blue-400/90 to-blue-400/0 transition-opacity duration-500"></span>
        </div>

        <div
          style={{
            perspective: "800px",
            transform: "rotateX(70deg) translateZ(0px)",
          }}
          className="absolute top-1/2 left-1/2 mt-4 ml-[0.09375rem] -translate-x-1/2 -translate-y-1/2"
        >
          <>
            <motion.div
              initial={{ opacity: 0, scale: 0 }}
              animate={{
                opacity: [0, 1, 0.5, 0],
                scale: 1,
              }}
              transition={{ duration: 6, repeat: Infinity, delay: 0 }}
              className="absolute top-1/2 left-1/2 h-20 w-20 -translate-x-1/2 -translate-y-1/2 rounded-[50%] bg-sky-500/[0.08] shadow-[0_8px_16px_rgb(0_0_0/0.4)] dark:bg-sky-500/[0.2]"
            ></motion.div>
            <motion.div
              initial={{ opacity: 0, scale: 0 }}
              animate={{
                opacity: [0, 1, 0.5, 0],
                scale: 1,
              }}
              transition={{ duration: 6, repeat: Infinity, delay: 2 }}
              className="absolute top-1/2 left-1/2 h-20 w-20 -translate-x-1/2 -translate-y-1/2 rounded-[50%] bg-sky-500/[0.08] shadow-[0_8px_16px_rgb(0_0_0/0.4)] dark:bg-sky-500/[0.2]"
            ></motion.div>
            <motion.div
              initial={{ opacity: 0, scale: 0 }}
              animate={{
                opacity: [0, 1, 0.5, 0],
                scale: 1,
              }}
              transition={{ duration: 6, repeat: Infinity, delay: 4 }}
              className="absolute top-1/2 left-1/2 h-20 w-20 -translate-x-1/2 -translate-y-1/2 rounded-[50%] bg-sky-500/[0.08] shadow-[0_8px_16px_rgb(0_0_0/0.4)] dark:bg-sky-500/[0.2]"
            ></motion.div>
          </>
        </div>

        <>
          <motion.div className="absolute right-1/2 bottom-1/2 h-20 w-px translate-y-[14px] bg-gradient-to-b from-transparent to-blue-500 blur-[2px]" />
          <motion.div className="absolute right-1/2 bottom-1/2 h-20 w-px translate-y-[14px] bg-gradient-to-b from-transparent to-blue-500" />
          <motion.div className="absolute right-1/2 bottom-1/2 z-40 h-[4px] w-[4px] translate-x-[1.5px] translate-y-[14px] rounded-full bg-blue-600 blur-[3px]" />
          <motion.div className="absolute right-1/2 bottom-1/2 z-40 h-[2px] w-[2px] translate-x-[0.5px] translate-y-[14px] rounded-full bg-blue-300" />
        </>
      </div>
    </motion.div>
  );
};

export const FeatureIconContainer = ({
  children,
  className,
}: {
  children: React.ReactNode;
  className?: string;
}) => {
  return (
    <div
      className={cn(
        "relative h-14 w-14 rounded-md bg-gradient-to-b from-light-gray to-slate-200 p-[4px] dark:from-slate-700 dark:to-slate-800",
        className
      )}
    >
      <div
        className={cn(
          "relative z-20 h-full w-full rounded-[5px] bg-light-gray dark:bg-slate-700",
          className
        )}
      >
        {children}
      </div>
      <div className="absolute inset-x-0 bottom-0 z-30 mx-auto h-4 w-full rounded-full bg-slate-600 opacity-50 blur-lg"></div>
      <div className="absolute inset-x-0 bottom-0 mx-auto h-px w-[60%] bg-gradient-to-r from-transparent via-gold to-transparent"></div>
      <div className="absolute inset-x-0 bottom-0 mx-auto h-px w-[60%] bg-gradient-to-r from-transparent via-yellow-600 to-transparent dark:h-[8px] dark:blur-sm"></div>
    </div>
  );
};

export const Grid = ({
  pattern,
  size,
}: {
  pattern?: number[][];
  size?: number;
}) => {
  const p = pattern ?? [
    [Math.floor(Math.random() * 4) + 7, Math.floor(Math.random() * 6) + 1],
    [Math.floor(Math.random() * 4) + 7, Math.floor(Math.random() * 6) + 1],
    [Math.floor(Math.random() * 4) + 7, Math.floor(Math.random() * 6) + 1],
    [Math.floor(Math.random() * 4) + 7, Math.floor(Math.random() * 6) + 1],
    [Math.floor(Math.random() * 4) + 7, Math.floor(Math.random() * 6) + 1],
  ];
  return (
    <div className="pointer-events-none absolute top-0 left-1/2 -mt-2 -ml-20 h-full w-full [mask-image:linear-gradient(white,transparent)]">
      <div className="absolute inset-0 bg-gradient-to-r from-zinc-900/30 to-zinc-900/30 opacity-10 [mask-image:radial-gradient(farthest-side_at_top,white,transparent)] dark:from-zinc-900/30 dark:to-zinc-900/30">
        <GridPattern
          width={size ?? 20}
          height={size ?? 20}
          x="-12"
          y="4"
          squares={p}
          className="absolute inset-0 h-full w-full fill-black/100 stroke-black/100 mix-blend-overlay dark:fill-white/100 dark:stroke-white/100"
        />
      </div>
    </div>
  );
};

export function GridPattern({ width, height, x, y, squares, ...props }: any) {
  const patternId = useId();

  return (
    <svg aria-hidden="true" {...props}>
      <defs>
        <pattern
          id={patternId}
          width={width}
          height={height}
          patternUnits="userSpaceOnUse"
          x={x}
          y={y}
        >
          <path d={`M.5 ${height}V.5H${width}`} fill="none" />
        </pattern>
      </defs>
      <rect
        width="100%"
        height="100%"
        strokeWidth={0}
        fill={`url(#${patternId})`}
      />
      {squares && (
        <svg x={x} y={y} className="overflow-visible">
          {squares.map(([x, y]: any, idx: number) => (
            <rect
              strokeWidth="0"
              key={`${x}-${y}-${idx}`}
              width={width + 1}
              height={height + 1}
              x={x * width}
              y={y * height}
            />
          ))}
        </svg>
      )}
    </svg>
  );
}