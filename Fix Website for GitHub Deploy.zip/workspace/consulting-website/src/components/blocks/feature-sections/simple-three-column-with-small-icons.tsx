"use client"

import { Linkedin, Mail } from 'lucide-react'

const teamMembers = [
  {
    name: 'Sarah Johnson',
    title: 'Chief Executive Officer',
    bio: 'Strategic leader with 15+ years in business transformation and digital innovation.',
    expertise: ['Strategic Planning', 'Digital Transformation', 'Leadership Development'],
    email: 'sarah.johnson@company.com',
    linkedin: 'https://linkedin.com/in/sarahjohnson',
    image: '/api/placeholder/300/300'
  },
  {
    name: 'Michael Chen',
    title: 'Head of Operations',
    bio: 'Operations expert specializing in process optimization and organizational efficiency.',
    expertise: ['Process Optimization', 'Project Management', 'Team Leadership'],
    email: 'michael.chen@company.com',
    linkedin: 'https://linkedin.com/in/michaelchen',
    image: '/api/placeholder/300/300'
  },
  {
    name: 'Emily Rodriguez',
    title: 'Senior Consultant',
    bio: 'Management consultant with expertise in change management and business strategy.',
    expertise: ['Change Management', 'Business Strategy', 'Data Analytics'],
    email: 'emily.rodriguez@company.com',
    linkedin: 'https://linkedin.com/in/emilyrodriguez',
    image: '/api/placeholder/300/300'
  },
]

export default function SimpleThreeColumnWithSmallIcons() {
  return (
    <div className="bg-secondary py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <div className="mx-auto max-w-2xl lg:text-center">
          <h2 className="text-base/7 font-semibold text-accent">Our Expert Team</h2>
          <p className="mt-2 text-4xl font-semibold tracking-tight text-pretty text-primary sm:text-5xl lg:text-balance">
            Industry leaders dedicated to your success
          </p>
          <p className="mt-6 text-lg/8 text-muted-foreground">
            Meet our experienced professionals who bring decades of expertise and proven results to help your business thrive.
          </p>
        </div>
        <div className="mx-auto mt-16 max-w-2xl sm:mt-20 lg:mt-24 lg:max-w-none">
          <dl className="grid max-w-xl grid-cols-1 gap-x-8 gap-y-16 lg:max-w-none lg:grid-cols-3">
            {teamMembers.map((member) => (
              <div key={member.name} className="flex flex-col items-center text-center group">
                <div className="relative mb-6">
                  <div className="relative overflow-hidden rounded-full w-32 h-32 border-4 border-primary shadow-lg transition-all duration-300 group-hover:scale-105">
                    <img 
                      src={member.image} 
                      alt={member.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                </div>
                
                <dt className="text-xl font-semibold text-primary mb-2">
                  {member.name}
                </dt>
                
                <div className="text-accent font-medium mb-4">
                  {member.title}
                </div>
                
                <dd className="flex flex-auto flex-col text-base/7 text-muted-foreground">
                  <p className="flex-auto mb-4">{member.bio}</p>
                  
                  <div className="mb-6">
                    <h4 className="font-semibold text-primary mb-2">Expertise:</h4>
                    <div className="flex flex-wrap justify-center gap-2">
                      {member.expertise.map((skill, index) => (
                        <span 
                          key={index}
                          className="px-3 py-1 bg-primary/10 text-primary text-sm rounded-full"
                        >
                          {skill}
                        </span>
                      ))}
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-center gap-4 mt-auto">
                    <a 
                      href={`mailto:${member.email}`}
                      className="flex items-center gap-2 text-accent hover:text-accent/80 transition-colors"
                    >
                      <Mail className="w-4 h-4" />
                      <span className="text-sm font-medium">Email</span>
                    </a>
                    <a 
                      href={member.linkedin}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-2 text-accent hover:text-accent/80 transition-colors"
                    >
                      <Linkedin className="w-4 h-4" />
                      <span className="text-sm font-medium">LinkedIn</span>
                    </a>
                  </div>
                </dd>
              </div>
            ))}
          </dl>
        </div>
      </div>
    </div>
  )
}