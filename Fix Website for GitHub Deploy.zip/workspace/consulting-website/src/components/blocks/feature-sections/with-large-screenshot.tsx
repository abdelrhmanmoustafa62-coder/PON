"use client"

import { ExternalLink, TrendingUp } from 'lucide-react'

const portfolioItems = [
  {
    id: 1,
    title: "Digital Transformation Strategy",
    client: "TechCorp Solutions",
    service: "Strategic Consulting",
    thumbnail: "https://images.unsplash.com/photo-1551434678-e076c223a692?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80",
    results: {
      metric: "40%",
      description: "Increase in operational efficiency"
    },
    details: {
      duration: "6 months",
      industry: "Technology",
      scope: "Enterprise-wide digital transformation including process optimization and technology integration"
    }
  },
  {
    id: 2,
    title: "Market Entry Analysis",
    client: "GlobalTech Industries",
    service: "Market Research",
    thumbnail: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80",
    results: {
      metric: "25%",
      description: "Revenue growth in new markets"
    },
    details: {
      duration: "4 months",
      industry: "Manufacturing",
      scope: "Comprehensive market analysis and entry strategy for Asian markets"
    }
  },
  {
    id: 3,
    title: "Organizational Restructuring",
    client: "InnovateNow Corp",
    service: "Change Management",
    thumbnail: "https://images.unsplash.com/photo-1552664730-d307ca884978?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80",
    results: {
      metric: "30%",
      description: "Reduction in operational costs"
    },
    details: {
      duration: "8 months",
      industry: "Financial Services",
      scope: "Complete organizational restructuring with focus on efficiency and employee satisfaction"
    }
  },
  {
    id: 4,
    title: "Performance Optimization",
    client: "NextGen Enterprises",
    service: "Process Improvement",
    thumbnail: "https://images.unsplash.com/photo-1460472178825-e5240623afd5?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2069&q=80",
    results: {
      metric: "50%",
      description: "Improvement in process efficiency"
    },
    details: {
      duration: "5 months",
      industry: "Healthcare",
      scope: "End-to-end process optimization and workflow management implementation"
    }
  }
]

export default function PortfolioShowcase() {
  return (
    <div className="bg-white py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <div className="mx-auto max-w-2xl sm:text-center">
          <h2 className="text-base/7 font-semibold text-gold">Our Portfolio</h2>
          <p className="mt-2 text-4xl font-semibold tracking-tight text-pretty text-navy sm:text-5xl sm:text-balance">
            Delivering measurable results across diverse industries
          </p>
          <p className="mt-6 text-lg/8 text-gray-600">
            Explore our successful partnerships and the tangible impact we've delivered for clients across various sectors.
          </p>
        </div>
      </div>
      
      <div className="relative overflow-hidden pt-16">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-2 xl:grid-cols-2">
            {portfolioItems.map((item) => (
              <div 
                key={item.id} 
                className="group relative overflow-hidden rounded-xl bg-white shadow-lg ring-1 ring-gray-900/10 transition-all duration-300 hover:shadow-2xl hover:ring-gold/20"
              >
                <div className="aspect-[16/9] overflow-hidden">
                  <img
                    src={item.thumbnail}
                    alt={item.title}
                    className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/20 to-transparent" />
                  
                  {/* Hover overlay with additional details */}
                  <div className="absolute inset-0 bg-navy/90 opacity-0 transition-opacity duration-300 group-hover:opacity-100">
                    <div className="flex h-full flex-col justify-center p-6 text-white">
                      <h4 className="text-lg font-semibold text-white mb-2">{item.title}</h4>
                      <p className="text-sm text-gray-300 mb-4">{item.details.scope}</p>
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-gray-400">Duration:</span>
                          <span className="text-white">{item.details.duration}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-400">Industry:</span>
                          <span className="text-white">{item.details.industry}</span>
                        </div>
                      </div>
                      <div className="mt-4 flex items-center text-gold">
                        <ExternalLink className="h-4 w-4 mr-2" />
                        <span className="text-sm font-medium">View Case Study</span>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div className="p-6">
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="text-lg font-semibold text-navy">{item.title}</h3>
                    <span className="text-sm text-gray-500">{item.service}</span>
                  </div>
                  
                  <p className="text-sm text-gray-600 mb-4">{item.client}</p>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <TrendingUp className="h-4 w-4 text-gold" />
                      <span className="text-2xl font-bold text-gold">{item.results.metric}</span>
                    </div>
                    <p className="text-sm text-gray-600">{item.results.description}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
      
      <div className="mx-auto mt-16 max-w-7xl px-6 sm:mt-20 md:mt-24 lg:px-8">
        <div className="text-center">
          <button className="inline-flex items-center rounded-lg bg-gold px-6 py-3 text-sm font-semibold text-white shadow-lg transition-all duration-200 hover:bg-gold/90 hover:shadow-xl">
            View All Projects
            <ExternalLink className="ml-2 h-4 w-4" />
          </button>
        </div>
      </div>
    </div>
  )
}