"use client"

import { ArrowRight, Calendar, Clock } from 'lucide-react'

const blogPosts = [
  {
    id: 1,
    title: "Digital Transformation in the Modern Enterprise",
    excerpt: "Explore how leading organizations are leveraging technology to drive innovation and competitive advantage in today's rapidly evolving business landscape.",
    date: "2024-01-15",
    readTime: "5 min read",
    category: "Strategy"
  },
  {
    id: 2,
    title: "Sustainable Business Practices for Long-term Growth",
    excerpt: "Discover actionable strategies for implementing sustainable practices that not only benefit the environment but also drive profitability and stakeholder value.",
    date: "2024-01-12",
    readTime: "7 min read",
    category: "Sustainability"
  },
  {
    id: 3,
    title: "The Future of Leadership in Remote Work Environments",
    excerpt: "Navigate the complexities of modern leadership with insights on building trust, maintaining culture, and driving performance in distributed teams.",
    date: "2024-01-10",
    readTime: "6 min read",
    category: "Leadership"
  }
]

export default function Simple() {
  return (
    <div className="bg-white py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <div className="mx-auto max-w-2xl lg:mx-0">
          <h2 className="text-4xl font-semibold tracking-tight text-pretty text-[var(--color-navy)] sm:text-5xl">
            Latest Insights
          </h2>
          <p className="mt-6 text-lg/8 text-gray-700">
            Industry expertise and strategic thinking.
          </p>
        </div>
        
        <div className="mx-auto mt-16 grid max-w-2xl grid-cols-1 gap-x-8 gap-y-16 lg:mx-0 lg:max-w-none lg:grid-cols-3">
          {blogPosts.map((post) => (
            <article key={post.id} className="group relative bg-white border border-gray-200 rounded-lg overflow-hidden hover:shadow-lg transition-all duration-300 hover:-translate-y-1">
              {/* Featured Image Placeholder */}
              <div className="aspect-[16/9] bg-gradient-to-br from-[var(--color-light-gray)] to-[var(--color-navy)]/10 relative overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-t from-[var(--color-navy)]/20 to-transparent" />
                <div className="absolute bottom-4 left-4">
                  <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-[var(--color-gold)] text-white">
                    {post.category}
                  </span>
                </div>
              </div>
              
              {/* Content */}
              <div className="p-6">
                <div className="flex items-center gap-4 text-sm text-gray-500 mb-3">
                  <div className="flex items-center gap-1">
                    <Calendar className="w-4 h-4" />
                    <time dateTime={post.date}>
                      {new Date(post.date).toLocaleDateString('en-US', {
                        year: 'numeric',
                        month: 'long',
                        day: 'numeric'
                      })}
                    </time>
                  </div>
                  <div className="flex items-center gap-1">
                    <Clock className="w-4 h-4" />
                    <span>{post.readTime}</span>
                  </div>
                </div>
                
                <h3 className="text-xl font-semibold text-[var(--color-navy)] mb-3 group-hover:text-[var(--color-gold)] transition-colors duration-200">
                  {post.title}
                </h3>
                
                <p className="text-gray-600 text-base leading-relaxed mb-4">
                  {post.excerpt}
                </p>
                
                <div className="flex items-center text-[var(--color-gold)] font-medium text-sm group-hover:text-[var(--color-navy)] transition-colors duration-200">
                  Read More
                  <ArrowRight className="w-4 h-4 ml-1 transform group-hover:translate-x-1 transition-transform duration-200" />
                </div>
              </div>
            </article>
          ))}
        </div>
        
        {/* View All Articles Button */}
        <div className="mt-16 text-center">
          <button className="inline-flex items-center px-8 py-3 bg-[var(--color-gold)] text-white font-medium rounded-lg hover:bg-[var(--color-gold)]/90 transition-all duration-200 hover:shadow-lg hover:-translate-y-0.5">
            View All Articles
            <ArrowRight className="w-5 h-5 ml-2" />
          </button>
        </div>
      </div>
    </div>
  )
}