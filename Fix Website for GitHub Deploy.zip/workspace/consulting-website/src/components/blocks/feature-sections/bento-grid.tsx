"use client";
import React from "react";
import { cn } from "@/lib/utils";
import { motion } from "motion/react";
import { 
  Target, 
  Smartphone, 
  Users, 
  Calculator, 
  Settings, 
  TrendingUp,
  ArrowRight
} from "lucide-react";
import Link from "next/link";

export function FeaturesSectionBentoGrid() {
  const features = [
    {
      title: "Strategic Planning",
      description: "Develop comprehensive business strategies that align with your vision and drive sustainable growth.",
      icon: <Target className="h-8 w-8" />,
      skeleton: <SkeletonOne />,
      className: "col-span-1 lg:col-span-2 border-b lg:border-r border-border",
    },
    {
      title: "Digital Transformation",
      description: "Navigate the digital landscape with confidence through our expert guidance and implementation support.",
      icon: <Smartphone className="h-8 w-8" />,
      skeleton: <SkeletonTwo />,
      className: "col-span-1 lg:col-span-2 border-b border-border",
    },
    {
      title: "Change Management",
      description: "Successfully implement organizational changes with minimal disruption and maximum adoption.",
      icon: <Users className="h-8 w-8" />,
      skeleton: <SkeletonThree />,
      className: "col-span-1 lg:col-span-2 border-b lg:border-r border-border",
    },
    {
      title: "Financial Advisory",
      description: "Optimize your financial performance with strategic insights and data-driven recommendations.",
      icon: <Calculator className="h-8 w-8" />,
      skeleton: <SkeletonFour />,
      className: "col-span-1 lg:col-span-2 border-b border-border",
    },
    {
      title: "Operations Optimization",
      description: "Streamline processes and improve efficiency across all aspects of your business operations.",
      icon: <Settings className="h-8 w-8" />,
      skeleton: <SkeletonFive />,
      className: "col-span-1 lg:col-span-2 border-b lg:border-r border-border lg:border-b-0",
    },
    {
      title: "Market Analysis",
      description: "Gain competitive intelligence and market insights to make informed strategic decisions.",
      icon: <TrendingUp className="h-8 w-8" />,
      skeleton: <SkeletonSix />,
      className: "col-span-1 lg:col-span-2 border-border lg:border-b-0",
    },
  ];

  return (
    <div className="relative z-20 mx-auto max-w-7xl py-10 lg:py-40 bg-light-gray">
      <div className="px-8">
        <motion.h4 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="mx-auto max-w-5xl text-center text-3xl font-bold tracking-tight text-navy lg:text-5xl lg:leading-tight"
        >
          Our Services
        </motion.h4>

        <motion.p 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="mx-auto my-4 max-w-2xl text-center text-sm font-normal text-muted-foreground lg:text-base"
        >
          Comprehensive consulting solutions tailored to your business needs
        </motion.p>
      </div>

      <div className="relative">
        <div className="mt-12 grid grid-cols-1 rounded-md lg:grid-cols-6 xl:border border-border bg-white">
          {features.map((feature, index) => (
            <motion.div
              key={feature.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
            >
              <FeatureCard className={feature.className}>
                <div className="flex items-center gap-3 mb-4">
                  <div className="text-gold">{feature.icon}</div>
                  <FeatureTitle>{feature.title}</FeatureTitle>
                </div>
                <FeatureDescription>{feature.description}</FeatureDescription>
                <div className="h-full w-full">{feature.skeleton}</div>
                <Link 
                  href="#"
                  className="inline-flex items-center gap-2 text-sm font-medium text-gold hover:text-navy transition-colors duration-200 mt-4"
                >
                  Learn More
                  <ArrowRight className="h-4 w-4" />
                </Link>
              </FeatureCard>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}

const FeatureCard = ({
  children,
  className,
}: {
  children?: React.ReactNode;
  className?: string;
}) => {
  return (
    <motion.div 
      className={cn(`relative overflow-hidden p-4 sm:p-8 group hover:bg-light-gray transition-colors duration-300`, className)}
      whileHover={{ scale: 1.02 }}
      transition={{ duration: 0.3 }}
    >
      {children}
    </motion.div>
  );
};

const FeatureTitle = ({ children }: { children?: React.ReactNode }) => {
  return (
    <h3 className="text-left text-xl tracking-tight text-navy font-semibold md:text-2xl">
      {children}
    </h3>
  );
};

const FeatureDescription = ({ children }: { children?: React.ReactNode }) => {
  return (
    <p className="text-left text-sm md:text-base text-muted-foreground font-normal my-2 max-w-sm">
      {children}
    </p>
  );
};

// Service-specific skeleton components
export const SkeletonOne = () => {
  return (
    <div className="relative flex h-40 items-center justify-center">
      <motion.div 
        className="w-32 h-32 border-4 border-gold rounded-full flex items-center justify-center"
        animate={{ rotate: 360 }}
        transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
      >
        <div className="w-16 h-16 bg-navy rounded-full flex items-center justify-center">
          <Target className="h-8 w-8 text-white" />
        </div>
      </motion.div>
    </div>
  );
};

export const SkeletonTwo = () => {
  return (
    <div className="relative flex h-40 items-center justify-center">
      <motion.div 
        className="grid grid-cols-3 gap-2"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 1, repeat: Infinity, repeatType: "reverse" }}
      >
        {Array.from({ length: 9 }).map((_, i) => (
          <motion.div
            key={i}
            className="w-6 h-6 bg-gradient-to-br from-gold to-navy rounded"
            animate={{ scale: [1, 1.2, 1] }}
            transition={{ duration: 2, delay: i * 0.1, repeat: Infinity }}
          />
        ))}
      </motion.div>
    </div>
  );
};

export const SkeletonThree = () => {
  return (
    <div className="relative flex h-40 items-center justify-center">
      <div className="flex space-x-2">
        {Array.from({ length: 3 }).map((_, i) => (
          <motion.div
            key={i}
            className="w-8 h-8 bg-gold rounded-full"
            animate={{ y: [0, -20, 0] }}
            transition={{ duration: 1.5, delay: i * 0.2, repeat: Infinity }}
          />
        ))}
      </div>
    </div>
  );
};

export const SkeletonFour = () => {
  return (
    <div className="relative flex h-40 items-center justify-center">
      <motion.div 
        className="w-24 h-24 border-4 border-navy rounded-lg flex items-center justify-center"
        animate={{ rotateY: [0, 180, 360] }}
        transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
      >
        <Calculator className="h-12 w-12 text-gold" />
      </motion.div>
    </div>
  );
};

export const SkeletonFive = () => {
  return (
    <div className="relative flex h-40 items-center justify-center">
      <motion.div 
        className="relative"
        animate={{ rotate: [0, 360] }}
        transition={{ duration: 4, repeat: Infinity, ease: "linear" }}
      >
        <div className="w-20 h-20 border-4 border-gold rounded-full flex items-center justify-center">
          <Settings className="h-8 w-8 text-navy" />
        </div>
        <div className="absolute -top-2 -right-2 w-4 h-4 bg-navy rounded-full"></div>
        <div className="absolute -bottom-2 -left-2 w-4 h-4 bg-navy rounded-full"></div>
      </motion.div>
    </div>
  );
};

export const SkeletonSix = () => {
  return (
    <div className="relative flex h-40 items-center justify-center">
      <div className="flex items-end space-x-2">
        {Array.from({ length: 5 }).map((_, i) => (
          <motion.div
            key={i}
            className="w-4 bg-gradient-to-t from-navy to-gold rounded-t"
            style={{ height: `${(i + 1) * 8}px` }}
            animate={{ scaleY: [1, 1.5, 1] }}
            transition={{ duration: 2, delay: i * 0.1, repeat: Infinity }}
          />
        ))}
      </div>
    </div>
  );
};