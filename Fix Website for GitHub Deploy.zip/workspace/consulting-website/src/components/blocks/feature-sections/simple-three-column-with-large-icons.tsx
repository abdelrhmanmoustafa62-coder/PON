"use client"

import { Telescope, Target, Heart } from 'lucide-react'

const features = [
  {
    name: 'Our Vision',
    description:
      'To be the global leader in business transformation consulting, empowering organizations to navigate complex challenges and achieve sustainable growth in an ever-evolving marketplace.',
    href: '/about',
    icon: Telescope,
  },
  {
    name: 'Our Mission',
    description:
      'We deliver exceptional strategic consulting services that drive measurable results, combining deep industry expertise with innovative methodologies to unlock our clients\' full potential.',
    href: '/about',
    icon: Target,
  },
  {
    name: 'Our Values',
    description:
      'Built on a foundation of integrity, innovation, and unwavering commitment to client success. We believe in collaborative partnerships that create lasting value and meaningful impact.',
    href: '/about',
    icon: Heart,
  },
]

export default function SimpleThreeColumnWithLargeIcons() {
  return (
    <div className="bg-white py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <div className="mx-auto max-w-2xl lg:mx-0">
          <h2 className="text-4xl font-semibold tracking-tight text-pretty text-[var(--color-navy)] sm:text-5xl">
            About Professional Opinion
          </h2>
          <p className="mt-6 text-lg/8 text-gray-600">
            A licensed financial and management advisory firm delivering professional excellence.
          </p>
        </div>
        <div className="mx-auto mt-16 max-w-2xl sm:mt-20 lg:mt-24 lg:max-w-none">
          <dl className="grid max-w-xl grid-cols-1 gap-x-8 gap-y-16 lg:max-w-none lg:grid-cols-3">
            {features.map((feature) => (
              <div key={feature.name} className="flex flex-col group hover:-translate-y-2 transition-all duration-300 hover:shadow-lg rounded-lg p-4">
                <dt className="text-base/7 font-semibold text-[var(--color-navy)]">
                  <div className="mb-6 flex size-10 items-center justify-center rounded-lg bg-[var(--color-navy)] group-hover:bg-[var(--color-gold)] transition-colors duration-300">
                    <feature.icon aria-hidden="true" className="size-6 text-white group-hover:text-white" />
                  </div>
                  {feature.name}
                </dt>
                <dd className="mt-1 flex flex-auto flex-col text-base/7 text-gray-600">
                  <p className="flex-auto">{feature.description}</p>
                  <p className="mt-6">
                    <a href={feature.href} className="text-sm/6 font-semibold text-[var(--color-gold)] hover:text-[var(--color-navy)] transition-colors duration-200">
                      Learn more <span aria-hidden="true">→</span>
                    </a>
                  </p>
                </dd>
              </div>
            ))}
          </dl>
        </div>
        <div className="mx-auto mt-16 max-w-4xl">
          <div className="bg-[var(--color-light-gray)] rounded-lg p-8">
            <h3 className="text-2xl font-semibold text-[var(--color-navy)] mb-4">Our Story</h3>
            <p className="text-base/7 text-gray-600">
              We are a licensed financial and management advisory firm in Saudi Arabia, delivering professional and high-quality 
              advisory services. As an independent member of the HLB Global Advisory and Accountancy Network, we provide comprehensive 
              solutions in management consulting, business valuation, corporate governance, risk assessment, due diligence, and real 
              estate advisory. Our expertise extends to project structuring and feasibility analysis, allowing us to merge global 
              best practices with local insights for optimal client outcomes.
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}