"use client"

import { cn } from "@/lib/utils";
import Image from "next/image";
import Link from "next/link";
import React, { useState } from "react";
import { ChevronDown, Mail, Phone, MapPin, Facebook, Twitter, Linkedin, Instagram, Globe } from "lucide-react";

export function FooterWithGrid() {
  const [selectedLanguage, setSelectedLanguage] = useState("en");

  const languages = [
    { code: "en", name: "English", flag: "🇺🇸" },
    { code: "ar", name: "العربية", flag: "🇸🇦" },
    { code: "zh", name: "中文", flag: "🇨🇳" }
  ];

  const content = {
    en: {
      companyTitle: "Professional Opinion",
      companyDescription: "We are a licensed financial and management advisory firm delivering professional and high-quality advisory services. As an independent member of the HLB Global Advisory and Accountancy Network, we provide comprehensive solutions worldwide.",
      services: "Services",
      resources: "Resources", 
      connect: "Connect",
      newsletter: "Newsletter",
      newsletterPlaceholder: "Enter your email",
      subscribe: "Subscribe",
      copyright: "2024 Professional Opinion. All Rights Reserved.",
      privacyPolicy: "Privacy Policy",
      termsOfService: "Terms of Service",
      cookiePolicy: "Cookie Policy"
    },
    ar: {
      companyTitle: "الرأي المهني",
      companyDescription: "نحن شركة استشارية مالية وإدارية مرخصة تقدم خدمات استشارية مهنية وعالية الجودة. كعضو مستقل في شبكة HLB العالمية للاستشارة والمحاسبة، نقدم حلولاً شاملة في جميع أنحاء العالم.",
      services: "الخدمات",
      resources: "الموارد",
      connect: "تواصل",
      newsletter: "النشرة الإخبارية",
      newsletterPlaceholder: "أدخل بريدك الإلكتروني",
      subscribe: "اشترك",
      copyright: "2024 الرأي المهني. جميع الحقوق محفوظة.",
      privacyPolicy: "سياسة الخصوصية",
      termsOfService: "شروط الخدمة",
      cookiePolicy: "سياسة ملفات تعريف الارتباط"
    },
    zh: {
      companyTitle: "专业意见",
      companyDescription: "我们是一家持牌的金融和管理咨询公司，提供专业和高质量的咨询服务。作为HLB全球咨询和会计网络的独立成员，我们在全球范围内提供综合解决方案。",
      services: "服务",
      resources: "资源",
      connect: "联系",
      newsletter: "新闻通讯",
      newsletterPlaceholder: "输入您的邮箱",
      subscribe: "订阅",
      copyright: "2024 专业意见。版权所有。",
      privacyPolicy: "隐私政策",
      termsOfService: "服务条款",
      cookiePolicy: "Cookie政策"
    }
  };

  const t = content[selectedLanguage as keyof typeof content];

  return (
    <div className="bg-[#1e293b] text-white">
      <div className="mx-auto max-w-7xl px-4 py-16 md:px-8">
        <div className="grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-4">
          {/* Company Info */}
          <div className="lg:col-span-1">
            <Logo className="justify-start mb-6" />
            <p className="mb-6 text-sm text-gray-300 leading-relaxed">
              {t.companyDescription}
            </p>
            <div className="space-y-3">
              <div className="flex items-center gap-3 text-sm text-gray-300">
                <Phone className="h-4 w-4 text-[#f59e0b]" />
                <span>+966 11 200 2111</span>
              </div>
              <div className="flex items-center gap-3 text-sm text-gray-300">
                <Mail className="h-4 w-4 text-[#f59e0b]" />
                <span>info@po.sa</span>
              </div>
              <div className="flex items-center gap-3 text-sm text-gray-300">
                <MapPin className="h-4 w-4 text-[#f59e0b]" />
                <span>6th Floor - Tulip Tower, Riyadh 11415 – KSA</span>
              </div>
            </div>
          </div>

          {/* Services */}
          <div>
            <h3 className="mb-6 text-sm font-bold text-white">
              {t.services}
            </h3>
            <ul className="space-y-3">
              {SERVICES.map((item, idx) => (
                <li key={idx}>
                  <Link
                    href={item.href}
                    className="text-sm text-gray-300 hover:text-[#f59e0b] transition-colors duration-200"
                  >
                    {item.title[selectedLanguage as keyof typeof item.title]}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Resources */}
          <div>
            <h3 className="mb-6 text-sm font-bold text-white">
              {t.resources}
            </h3>
            <ul className="space-y-3">
              {RESOURCES.map((item, idx) => (
                <li key={idx}>
                  <Link
                    href={item.href}
                    className="text-sm text-gray-300 hover:text-[#f59e0b] transition-colors duration-200"
                  >
                    {item.title[selectedLanguage as keyof typeof item.title]}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Connect */}
          <div>
            <h3 className="mb-6 text-sm font-bold text-white">
              {t.connect}
            </h3>
            <div className="flex gap-4 mb-6">
              <Link
                href="https://www.linkedin.com/company/professional-opinion"
                className="text-gray-300 hover:text-[#f59e0b] transition-colors duration-200"
              >
                <Linkedin className="h-5 w-5" />
              </Link>
              <Link
                href="https://twitter.com/professional_opinion"
                className="text-gray-300 hover:text-[#f59e0b] transition-colors duration-200"
              >
                <Twitter className="h-5 w-5" />
              </Link>
              <Link
                href="https://www.facebook.com/professionalopin"
                className="text-gray-300 hover:text-[#f59e0b] transition-colors duration-200"
              >
                <Facebook className="h-5 w-5" />
              </Link>
              <Link
                href="https://www.instagram.com/professional_opinion"
                className="text-gray-300 hover:text-[#f59e0b] transition-colors duration-200"
              >
                <Instagram className="h-5 w-5" />
              </Link>
            </div>
            
            <div className="mb-6">
              <p className="text-sm font-semibold text-white mb-3">{t.newsletter}</p>
              <div className="flex">
                <input
                  type="email"
                  placeholder={t.newsletterPlaceholder}
                  className="flex-1 px-3 py-2 bg-[#334155] text-white text-sm rounded-l-md border border-[#475569] focus:outline-none focus:ring-2 focus:ring-[#f59e0b] focus:border-transparent"
                />
                <button className="px-4 py-2 bg-[#f59e0b] text-white text-sm font-medium rounded-r-md hover:bg-[#ca8a04] transition-colors duration-200">
                  {t.subscribe}
                </button>
              </div>
            </div>

            {/* Language Selector */}
            <div className="relative">
              <button
                onClick={() => {
                  const dropdown = document.getElementById('language-dropdown');
                  dropdown?.classList.toggle('hidden');
                }}
                className="flex items-center gap-2 px-3 py-2 bg-[#334155] text-white text-sm rounded-md border border-[#475569] hover:bg-[#475569] transition-colors duration-200"
              >
                <Globe className="h-4 w-4" />
                <span>{languages.find(lang => lang.code === selectedLanguage)?.name}</span>
                <ChevronDown className="h-4 w-4" />
              </button>
              <div
                id="language-dropdown"
                className="absolute bottom-full mb-2 w-full bg-[#334155] border border-[#475569] rounded-md shadow-lg hidden"
              >
                {languages.map((lang) => (
                  <button
                    key={lang.code}
                    onClick={() => {
                      setSelectedLanguage(lang.code);
                      document.getElementById('language-dropdown')?.classList.add('hidden');
                    }}
                    className="w-full flex items-center gap-2 px-3 py-2 text-sm text-white hover:bg-[#475569] transition-colors duration-200"
                  >
                    <span>{lang.flag}</span>
                    <span>{lang.name}</span>
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Section */}
        <div className="border-t border-[#334155] mt-12 pt-8 flex flex-col md:flex-row items-center justify-between">
          <p className="text-sm text-gray-300 mb-4 md:mb-0">
            {t.copyright}
          </p>
          <div className="flex gap-6">
            <Link
              href="/privacy"
              className="text-sm text-gray-300 hover:text-[#f59e0b] transition-colors duration-200"
            >
              {t.privacyPolicy}
            </Link>
            <Link
              href="/terms"
              className="text-sm text-gray-300 hover:text-[#f59e0b] transition-colors duration-200"
            >
              {t.termsOfService}
            </Link>
            <Link
              href="/cookies"
              className="text-sm text-gray-300 hover:text-[#f59e0b] transition-colors duration-200"
            >
              {t.cookiePolicy}
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}

const SERVICES = [
  {
    title: {
      en: "Business Valuation",
      ar: "تقييم الأعمال",
      zh: "企业估值"
    },
    href: "/services#valuation"
  },
  {
    title: {
      en: "M&A Advisory",
      ar: "استشارة الاندماج والاستحواذ",
      zh: "并购咨询"
    },
    href: "/services#ma"
  },
  {
    title: {
      en: "Transaction Advisory",
      ar: "استشارة المعاملات",
      zh: "交易咨询"
    },
    href: "/services#transaction"
  },
  {
    title: {
      en: "Bid Advisory",
      ar: "استشارة العطاءات",
      zh: "投标咨询"
    },
    href: "/services#bid"
  },
  {
    title: {
      en: "Fund Raising",
      ar: "جمع التمويل",
      zh: "资金筹集"
    },
    href: "/services#funding"
  }
];

const RESOURCES = [
  {
    title: {
      en: "About Us",
      ar: "من نحن",
      zh: "关于我们"
    },
    href: "/about"
  },
  {
    title: {
      en: "Our Team",
      ar: "فريقنا",
      zh: "我们的团队"
    },
    href: "/team"
  },
  {
    title: {
      en: "Case Studies",
      ar: "دراسات الحالة",
      zh: "案例研究"
    },
    href: "/insights#case-studies"
  },
  {
    title: {
      en: "Industry Insights",
      ar: "رؤى الصناعة",
      zh: "行业洞察"
    },
    href: "/insights"
  },
  {
    title: {
      en: "Contact Us",
      ar: "تواصل معنا",
      zh: "联系我们"
    },
    href: "/contact"
  }
];

const Logo = ({ className }: { className?: string }) => {
  return (
    <Link
      href="/"
      className={cn(
        "flex items-center gap-3 text-white hover:text-[#f59e0b] transition-colors duration-200",
        className
      )}
    >
      <img
        src="https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/project-uploads/7dd660a1-66db-44fd-937b-7d6c24a4dfba/generated_images/professional-opinion-company-logo%3a-mod-0cd63f61-20250714103533.jpg?"
        alt="Professional Opinion Logo"
        className="h-10 w-auto object-contain"
      />
      <div className="hidden sm:block">
        <div className="text-lg font-bold">PROFESSIONAL</div>
        <div className="text-sm font-medium">OPINION</div>
      </div>
    </Link>
  );
};