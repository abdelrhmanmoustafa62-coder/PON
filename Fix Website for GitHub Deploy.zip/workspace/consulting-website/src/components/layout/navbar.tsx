"use client";

import { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Menu, X, Sun, Moon, Globe, Home, Building, Briefcase, Users, BookOpen, Mail, ArrowRight, Award, TrendingUp } from 'lucide-react';
import Link from 'next/link';

interface NavItem {
  name: string;
  href: string;
  icon: React.ReactNode;
}

interface Language {
  code: string;
  name: string;
  flag: string;
}

export const Navbar = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [currentLanguage, setCurrentLanguage] = useState('en');

  const languages: Language[] = [
    { code: 'en', name: 'English', flag: '🇺🇸' },
    { code: 'ar', name: 'العربية', flag: '🇸🇦' },
    { code: 'zh', name: '中文', flag: '🇨🇳' },
  ];

  const navItems: NavItem[] = [
    { name: 'About', href: '/about', icon: <Building className="w-4 h-4" /> },
    { name: 'Services', href: '/services', icon: <Briefcase className="w-4 h-4" /> },
    { name: 'Case Studies', href: '/insights', icon: <Award className="w-4 h-4" /> },
    { name: 'Team', href: '/team', icon: <Users className="w-4 h-4" /> },
    { name: 'Global Outreach', href: '/global', icon: <Globe className="w-4 h-4" /> },
    { name: 'Blog', href: '/blog', icon: <BookOpen className="w-4 h-4" /> },
    { name: 'Contact', href: '/contact', icon: <Mail className="w-4 h-4" /> },
  ];

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDarkMode]);

  const toggleTheme = () => {
    setIsDarkMode(!isDarkMode);
  };

  const handleLanguageChange = (language: string) => {
    setCurrentLanguage(language);
  };

  const currentLang = languages.find(lang => lang.code === currentLanguage) || languages[0];

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled
          ? 'glass-effect shadow-lg border-b border-gray-200/20 dark:border-gray-700/20'
          : 'bg-transparent'
      }`}
    >
      <div className="container mx-auto px-4 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link href="/" className="flex items-center space-x-2 group">
            <div className="w-8 h-8 bg-gradient-to-r from-[#005A77] to-[#FBBA00] rounded-full flex items-center justify-center group-hover:scale-110 transition-transform duration-200">
              <span className="text-white font-bold text-sm">PO</span>
            </div>
            <span className="text-xl font-bold text-[#005A77] dark:text-white group-hover:text-[#FBBA00] transition-colors duration-200">
              Professional Opinion
            </span>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden lg:flex items-center space-x-8">
            {navItems.map((item) => (
              <Link
                key={item.name}
                href={item.href}
                className="flex items-center space-x-2 text-gray-700 dark:text-gray-300 hover:text-[#005A77] dark:hover:text-[#FBBA00] transition-colors duration-200 font-medium group"
              >
                <span className="group-hover:scale-110 transition-transform duration-200">
                  {item.icon}
                </span>
                <span className="relative">
                  {item.name}
                  <span className="absolute -bottom-1 left-0 right-0 h-0.5 bg-[#FBBA00] scale-x-0 group-hover:scale-x-100 transition-transform duration-200 origin-left"></span>
                </span>
              </Link>
            ))}
          </div>

          {/* Desktop Actions */}
          <div className="hidden lg:flex items-center space-x-4">
            {/* Language Selector */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button
                  variant="ghost"
                  size="sm"
                  className="flex items-center space-x-2 text-gray-700 dark:text-gray-300 hover:text-[#005A77] dark:hover:text-[#FBBA00] transition-colors duration-200"
                >
                  <Globe className="w-4 h-4" />
                  <span className="text-sm">{currentLang.flag}</span>
                  <span className="text-sm font-medium">{currentLang.name}</span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-40">
                {languages.map((language) => (
                  <DropdownMenuItem
                    key={language.code}
                    onClick={() => handleLanguageChange(language.code)}
                    className="flex items-center space-x-2 cursor-pointer hover:bg-[#FBBA00]/10"
                  >
                    <span>{language.flag}</span>
                    <span>{language.name}</span>
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>

            {/* Theme Toggle */}
            <Button
              variant="ghost"
              size="sm"
              onClick={toggleTheme}
              className="text-gray-700 dark:text-gray-300 hover:text-[#005A77] dark:hover:text-[#FBBA00] transition-colors duration-200"
              aria-label="Toggle theme"
            >
              {isDarkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </Button>

            {/* CTA Button */}
            <Button
              asChild
              className="bg-[#005A77] hover:bg-[#0093A7] text-white font-semibold px-6 py-2 rounded-full transition-all duration-200 hover:scale-105 shadow-lg hover:shadow-xl"
            >
              <Link href="/contact">
                Get Consultation
                <ArrowRight className="w-4 h-4 ml-2" />
              </Link>
            </Button>
          </div>

          {/* Mobile Menu Button */}
          <div className="lg:hidden flex items-center space-x-2">
            {/* Mobile Theme Toggle */}
            <Button
              variant="ghost"
              size="sm"
              onClick={toggleTheme}
              className="text-gray-700 dark:text-gray-300 hover:text-[#005A77] dark:hover:text-[#FBBA00] transition-colors duration-200"
              aria-label="Toggle theme"
            >
              {isDarkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </Button>

            {/* Mobile Menu */}
            <Sheet open={isMobileMenuOpen} onOpenChange={setIsMobileMenuOpen}>
              <SheetTrigger asChild>
                <Button
                  variant="ghost"
                  size="sm"
                  className="text-gray-700 dark:text-gray-300 hover:text-[#005A77] dark:hover:text-[#FBBA00] transition-colors duration-200"
                  aria-label="Open menu"
                >
                  <Menu className="w-5 h-5" />
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="w-[300px] sm:w-[400px]">
                <SheetHeader>
                  <SheetTitle className="flex items-center space-x-2">
                    <div className="w-6 h-6 bg-gradient-to-r from-[#005A77] to-[#FBBA00] rounded-full flex items-center justify-center">
                      <span className="text-white font-bold text-xs">PO</span>
                    </div>
                    <span className="text-lg font-bold text-[#005A77] dark:text-white">
                      Professional Opinion
                    </span>
                  </SheetTitle>
                </SheetHeader>

                <div className="flex flex-col space-y-4 mt-8">
                  {/* Mobile Navigation Items */}
                  {navItems.map((item) => (
                    <Link
                      key={item.name}
                      href={item.href}
                      onClick={() => setIsMobileMenuOpen(false)}
                      className="flex items-center space-x-3 text-gray-700 dark:text-gray-300 hover:text-[#005A77] dark:hover:text-[#FBBA00] transition-colors duration-200 font-medium py-2 px-3 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800"
                    >
                      {item.icon}
                      <span>{item.name}</span>
                    </Link>
                  ))}

                  {/* Mobile Language Selector */}
                  <div className="border-t pt-4 mt-4">
                    <p className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-2">
                      Language
                    </p>
                    <div className="space-y-2">
                      {languages.map((language) => (
                        <button
                          key={language.code}
                          onClick={() => {
                            handleLanguageChange(language.code);
                            setIsMobileMenuOpen(false);
                          }}
                          className={`flex items-center space-x-2 w-full text-left py-2 px-3 rounded-lg transition-colors duration-200 ${
                            currentLanguage === language.code
                              ? 'bg-[#FBBA00]/10 text-[#FBBA00]'
                              : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800'
                          }`}
                        >
                          <span>{language.flag}</span>
                          <span>{language.name}</span>
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Mobile CTA Button */}
                  <div className="border-t pt-4 mt-4">
                    <Button
                      asChild
                      className="w-full bg-[#005A77] hover:bg-[#0093A7] text-white font-semibold py-3 rounded-full transition-all duration-200 shadow-lg hover:shadow-xl"
                      onClick={() => setIsMobileMenuOpen(false)}
                    >
                      <Link href="/contact">
                        Get Consultation
                        <ArrowRight className="w-4 h-4 ml-2" />
                      </Link>
                    </Button>
                  </div>
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>
    </nav>
  );
};