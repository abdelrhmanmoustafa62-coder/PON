"use client";

import React, { useState } from 'react';
import { useLanguage } from '@/components/providers/language-provider';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card } from '@/components/ui/card';
import { 
  Building2, 
  Phone, 
  Mail, 
  Globe, 
  MapPin, 
  ArrowRight,
  Linkedin,
  Twitter,
  Facebook,
  Send
} from 'lucide-react';

export const Footer = () => {
  const { t } = useLanguage();
  const [email, setEmail] = useState('');
  const [isSubscribed, setIsSubscribed] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (email.trim()) {
      setIsSubscribed(true);
      setEmail('');
      setTimeout(() => setIsSubscribed(false), 3000);
    }
  };

  const socialLinks = [
    { icon: Linkedin, href: "#", label: "LinkedIn" },
    { icon: Twitter, href: "#", label: "Twitter" },
    { icon: Facebook, href: "#", label: "Facebook" }
  ];

  return (
    <footer className="bg-navy text-white">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Company Information */}
          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <Building2 className="h-8 w-8 text-gold" />
              <h3 className="text-xl font-bold text-white">{t('footer.company.title')}</h3>
            </div>
            <p className="text-gray-300 text-sm leading-relaxed">
              {t('footer.company.description')}
            </p>
            
            {/* Newsletter Signup */}
            <Card className="bg-slate-800 border-slate-700 p-4">
              <h4 className="font-semibold text-white mb-2">Newsletter</h4>
              <p className="text-gray-300 text-sm mb-3">Stay updated with our latest insights</p>
              
              {isSubscribed ? (
                <div className="flex items-center space-x-2 text-green-400">
                  <Send className="h-4 w-4" />
                  <span className="text-sm">{t('status.sent')}</span>
                </div>
              ) : (
                <form onSubmit={handleSubscribe} className="flex space-x-2">
                  <Input
                    type="email"
                    placeholder="Enter your email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="bg-slate-700 border-slate-600 text-white placeholder-gray-400"
                    required
                  />
                  <Button
                    type="submit"
                    size="sm"
                    className="bg-gold hover:bg-yellow-600 text-navy"
                  >
                    <ArrowRight className="h-4 w-4" />
                  </Button>
                </form>
              )}
            </Card>
          </div>

          {/* Quick Links */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-gold">{t('footer.quicklinks.title')}</h3>
            <nav className="space-y-2">
              <a href="/" className="block text-gray-300 hover:text-gold transition-colors duration-200 text-sm">
                {t('nav.home')}
              </a>
              <a href="/about" className="block text-gray-300 hover:text-gold transition-colors duration-200 text-sm">
                {t('nav.about')}
              </a>
              <a href="/services" className="block text-gray-300 hover:text-gold transition-colors duration-200 text-sm">
                {t('nav.services')}
              </a>
              <a href="/team" className="block text-gray-300 hover:text-gold transition-colors duration-200 text-sm">
                {t('nav.team')}
              </a>
              <a href="/insights" className="block text-gray-300 hover:text-gold transition-colors duration-200 text-sm">
                Insights
              </a>
              <a href="/contact" className="block text-gray-300 hover:text-gold transition-colors duration-200 text-sm">
                {t('nav.contact')}
              </a>
            </nav>
          </div>

          {/* Services */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-gold">{t('footer.services.title')}</h3>
            <nav className="space-y-2">
              <a href="/services#valuation" className="block text-gray-300 hover:text-gold transition-colors duration-200 text-sm">
                Business Valuation
              </a>
              <a href="/services#ma" className="block text-gray-300 hover:text-gold transition-colors duration-200 text-sm">
                M&A Advisory
              </a>
              <a href="/services#transaction" className="block text-gray-300 hover:text-gold transition-colors duration-200 text-sm">
                Transaction Advisory
              </a>
              <a href="/services#bid" className="block text-gray-300 hover:text-gold transition-colors duration-200 text-sm">
                Bid Advisory
              </a>
              <a href="/services#funding" className="block text-gray-300 hover:text-gold transition-colors duration-200 text-sm">
                Fund Raising
              </a>
              <a href="/services#realestate" className="block text-gray-300 hover:text-gold transition-colors duration-200 text-sm">
                Real Estate Advisory
              </a>
            </nav>
          </div>

          {/* Contact Information */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-gold">{t('footer.contact.title')}</h3>
            <div className="space-y-3">
              <div className="flex items-start space-x-3">
                <MapPin className="h-5 w-5 text-gold mt-0.5 flex-shrink-0" />
                <div className="text-gray-300 text-sm">
                  <p>6th Floor - Tulip Tower</p>
                  <p>PO Box 18025, Riyadh 11415 – KSA</p>
                </div>
              </div>

              <div className="flex items-center space-x-3">
                <Phone className="h-5 w-5 text-gold flex-shrink-0" />
                <div className="text-gray-300 text-sm">
                  <p>920005122</p>
                  <p>+966 11 200 2111</p>
                </div>
              </div>

              <div className="flex items-center space-x-3">
                <Mail className="h-5 w-5 text-gold flex-shrink-0" />
                <a
                  href="mailto:info@po.sa"
                  className="text-gray-300 hover:text-gold transition-colors duration-200 text-sm"
                >
                  info@po.sa
                </a>
              </div>

              <div className="flex items-center space-x-3">
                <Globe className="h-5 w-5 text-gold flex-shrink-0" />
                <a
                  href="https://www.po.sa"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-gray-300 hover:text-gold transition-colors duration-200 text-sm"
                >
                  www.po.sa
                </a>
              </div>
            </div>

            {/* Social Media */}
            <div>
              <h4 className="font-semibold text-gold mb-3">{t('footer.follow.title')}</h4>
              <div className="flex space-x-3">
                {socialLinks.map(({ icon: Icon, href, label }) => (
                  <a
                    key={label}
                    href={href}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="bg-slate-800 hover:bg-gold text-gray-300 hover:text-navy p-2 rounded-lg transition-all duration-200"
                    aria-label={label}
                  >
                    <Icon className="h-5 w-5" />
                  </a>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Section */}
        <div className="border-t border-slate-700 mt-12 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
            <div className="text-gray-400 text-sm">
              © 2024 Professional Opinion. {t('footer.rights')}
            </div>
            
            <div className="flex items-center space-x-6">
              <a href="/legal/privacy" className="text-gray-400 hover:text-gold transition-colors duration-200 text-sm">
                {t('footer.privacy')}
              </a>
              <a href="/legal/terms" className="text-gray-400 hover:text-gold transition-colors duration-200 text-sm">
                {t('footer.terms')}
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};