"use client"

import { useState } from 'react'
import { ChevronDown, Globe } from 'lucide-react'
import { motion, AnimatePresence } from 'motion/react'

interface Language {
  code: string
  name: string
  flag: string
  dir: 'ltr' | 'rtl'
}

interface LanguageSelectorProps {
  currentLanguage?: string
  onLanguageChange?: (languageCode: string) => void
  variant?: 'navbar' | 'footer'
  className?: string
}

const languages: Language[] = [
  { code: 'en', name: 'English', flag: '🇺🇸', dir: 'ltr' },
  { code: 'ar', name: 'العربية', flag: '🇸🇦', dir: 'rtl' },
  { code: 'zh', name: '中文', flag: '🇨🇳', dir: 'ltr' },
]

export default function LanguageSelector({
  currentLanguage = 'en',
  onLanguageChange,
  variant = 'navbar',
  className = ''
}: LanguageSelectorProps) {
  const [isOpen, setIsOpen] = useState(false)
  const [focusedIndex, setFocusedIndex] = useState(-1)

  const currentLang = languages.find(lang => lang.code === currentLanguage) || languages[0]

  const handleLanguageSelect = (languageCode: string) => {
    onLanguageChange?.(languageCode)
    setIsOpen(false)
    setFocusedIndex(-1)
  }

  const handleKeyDown = (event: React.KeyboardEvent) => {
    if (event.key === 'Escape') {
      setIsOpen(false)
      setFocusedIndex(-1)
    } else if (event.key === 'Enter' || event.key === ' ') {
      event.preventDefault()
      setIsOpen(!isOpen)
    } else if (event.key === 'ArrowDown') {
      event.preventDefault()
      if (!isOpen) {
        setIsOpen(true)
        setFocusedIndex(0)
      } else {
        setFocusedIndex(prev => (prev + 1) % languages.length)
      }
    } else if (event.key === 'ArrowUp') {
      event.preventDefault()
      if (!isOpen) {
        setIsOpen(true)
        setFocusedIndex(languages.length - 1)
      } else {
        setFocusedIndex(prev => prev <= 0 ? languages.length - 1 : prev - 1)
      }
    } else if (event.key === 'Enter' && focusedIndex >= 0) {
      event.preventDefault()
      handleLanguageSelect(languages[focusedIndex].code)
    }
  }

  const buttonClasses = variant === 'navbar' 
    ? 'bg-white text-navy hover:bg-light-gray border-border'
    : 'bg-navy text-white hover:bg-slate-700 border-slate-600'

  const dropdownClasses = variant === 'navbar'
    ? 'bg-white border-border shadow-lg'
    : 'bg-navy border-slate-600 shadow-xl'

  return (
    <div className={`relative ${className}`}>
      <button
        onClick={() => setIsOpen(!isOpen)}
        onKeyDown={handleKeyDown}
        className={`
          flex items-center gap-2 px-3 py-2 rounded-md border text-sm font-medium
          transition-all duration-200 ease-in-out
          focus:outline-none focus:ring-2 focus:ring-accent focus:ring-offset-2
          ${buttonClasses}
        `}
        aria-expanded={isOpen}
        aria-haspopup="listbox"
        aria-label="Select language"
      >
        <span className="text-base" aria-hidden="true">
          {currentLang.flag}
        </span>
        <span className="font-medium">
          {currentLang.name}
        </span>
        <motion.div
          animate={{ rotate: isOpen ? 180 : 0 }}
          transition={{ duration: 0.2 }}
        >
          <ChevronDown className="w-4 h-4" />
        </motion.div>
      </button>

      <AnimatePresence>
        {isOpen && (
          <>
            {/* Backdrop */}
            <div
              className="fixed inset-0 z-40"
              onClick={() => setIsOpen(false)}
            />
            
            {/* Dropdown menu */}
            <motion.div
              initial={{ opacity: 0, y: -4, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -4, scale: 0.95 }}
              transition={{ duration: 0.15, ease: 'easeOut' }}
              className={`
                absolute top-full mt-2 w-48 rounded-md border
                ${variant === 'navbar' ? 'left-0' : 'right-0'}
                ${dropdownClasses}
                z-50
              `}
              role="listbox"
              aria-label="Language options"
            >
              <div className="py-1">
                {languages.map((language, index) => (
                  <button
                    key={language.code}
                    onClick={() => handleLanguageSelect(language.code)}
                    className={`
                      w-full flex items-center gap-3 px-4 py-3 text-left text-sm
                      transition-all duration-150 ease-in-out
                      hover:bg-accent hover:text-accent-foreground
                      focus:outline-none focus:bg-accent focus:text-accent-foreground
                      ${currentLanguage === language.code ? 'bg-accent/10' : ''}
                      ${focusedIndex === index ? 'bg-accent text-accent-foreground' : ''}
                      ${variant === 'navbar' ? 'text-navy' : 'text-white'}
                    `}
                    dir={language.dir}
                    role="option"
                    aria-selected={currentLanguage === language.code}
                  >
                    <span className="text-base" aria-hidden="true">
                      {language.flag}
                    </span>
                    <span className="font-medium flex-1">
                      {language.name}
                    </span>
                    {currentLanguage === language.code && (
                      <motion.div
                        initial={{ scale: 0 }}
                        animate={{ scale: 1 }}
                        transition={{ duration: 0.2 }}
                        className="w-2 h-2 rounded-full bg-accent"
                        aria-hidden="true"
                      />
                    )}
                  </button>
                ))}
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  )
}