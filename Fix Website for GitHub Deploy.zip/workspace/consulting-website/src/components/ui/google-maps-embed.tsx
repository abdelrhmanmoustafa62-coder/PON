"use client"

import { useState, useEffect } from 'react'
import { MapPin, AlertCircle, Loader2 } from 'lucide-react'

interface GoogleMapsEmbedProps {
  location: string
  width?: string
  height?: string
  zoom?: number
  className?: string
  apiKey?: string
  onLoad?: () => void
  onError?: (error: Error) => void
}

export default function GoogleMapsEmbed({
  location,
  width = "100%",
  height = "400px",
  zoom = 15,
  className = "",
  apiKey,
  onLoad,
  onError
}: GoogleMapsEmbedProps) {
  const [isLoading, setIsLoading] = useState(true)
  const [hasError, setHasError] = useState(false)
  const [errorMessage, setErrorMessage] = useState("")

  const mapSrc = apiKey 
    ? `https://www.google.com/maps/embed/v1/place?key=${apiKey}&q=${encodeURIComponent(location)}&zoom=${zoom}`
    : `https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3048.0!2d-74.0!3d40.7!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2s${encodeURIComponent(location)}!5e0!3m2!1sen!2sus!4v1234567890!5m2!1sen!2sus`

  const handleLoad = () => {
    setIsLoading(false)
    setHasError(false)
    onLoad?.()
  }

  const handleError = (error: ErrorEvent) => {
    setIsLoading(false)
    setHasError(true)
    setErrorMessage("Failed to load map. Please try again later.")
    onError?.(new Error(error.message))
  }

  useEffect(() => {
    const timer = setTimeout(() => {
      if (isLoading) {
        setIsLoading(false)
        setHasError(true)
        setErrorMessage("Map loading timeout. Please check your connection.")
      }
    }, 10000)

    return () => clearTimeout(timer)
  }, [isLoading])

  return (
    <div 
      className={`relative bg-white rounded-lg border border-slate-200 shadow-lg overflow-hidden ${className}`}
      style={{ width, height }}
    >
      {/* Loading State */}
      {isLoading && (
        <div className="absolute inset-0 bg-light-gray flex items-center justify-center z-10">
          <div className="text-center">
            <Loader2 className="w-8 h-8 text-accent animate-spin mx-auto mb-3" />
            <p className="text-sm text-muted-foreground font-medium">Loading map...</p>
          </div>
        </div>
      )}

      {/* Error State */}
      {hasError && (
        <div className="absolute inset-0 bg-light-gray flex items-center justify-center z-10">
          <div className="text-center p-6 max-w-sm">
            <AlertCircle className="w-12 h-12 text-destructive mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-primary mb-2">Map Unavailable</h3>
            <p className="text-sm text-muted-foreground mb-4">{errorMessage}</p>
            <div className="flex items-center justify-center space-x-2 text-sm text-primary">
              <MapPin className="w-4 h-4" />
              <span>{location}</span>
            </div>
            <button
              onClick={() => {
                setHasError(false)
                setIsLoading(true)
                const iframe = document.querySelector('iframe')
                if (iframe) {
                  iframe.src = iframe.src
                }
              }}
              className="mt-4 px-4 py-2 bg-accent text-white rounded-md hover:bg-accent/90 transition-colors font-medium"
            >
              Try Again
            </button>
          </div>
        </div>
      )}

      {/* Map Iframe */}
      <iframe
        src={mapSrc}
        width="100%"
        height="100%"
        style={{ border: 0 }}
        allowFullScreen
        loading="lazy"
        referrerPolicy="no-referrer-when-downgrade"
        title={`Map showing location: ${location}`}
        aria-label={`Interactive map displaying ${location}`}
        onLoad={handleLoad}
        onError={handleError}
        className="w-full h-full"
      />

      {/* Custom Styled Overlay for Branding */}
      <div className="absolute top-4 left-4 bg-white/95 backdrop-blur-sm rounded-lg px-3 py-2 shadow-sm border border-slate-200">
        <div className="flex items-center space-x-2">
          <div className="w-3 h-3 bg-accent rounded-full shadow-sm"></div>
          <span className="text-sm font-medium text-primary">Office Location</span>
        </div>
      </div>

      {/* Decorative Border Enhancement */}
      <div className="absolute inset-0 rounded-lg ring-1 ring-slate-200 pointer-events-none"></div>
    </div>
  )
}