"use client";

import { useEffect } from 'react';
import AOS from 'aos';
import 'aos/dist/aos.css';

interface AOSConfig {
  duration?: number;
  easing?: string;
  offset?: number;
  delay?: number;
  once?: boolean;
  mirror?: boolean;
  anchorPlacement?: string;
  disable?: boolean | string | (() => boolean);
  startEvent?: string;
  animatedClassName?: string;
  useClassNames?: boolean;
  disableMutationObserver?: boolean;
  debounceDelay?: number;
  throttleDelay?: number;
}

interface AOSInitializerProps {
  config?: AOSConfig;
}

export const AOSInitializer: React.FC<AOSInitializerProps> = ({ 
  config = {} 
}) => {
  useEffect(() => {
    // Mobile detection for performance optimization
    const isMobile = () => {
      if (typeof window === 'undefined') return false;
      return window.innerWidth <= 768 || 
             /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
    };

    // Default configuration with performance optimizations
    const defaultConfig: AOSConfig = {
      duration: 800,
      easing: 'ease-out',
      offset: 80,
      delay: 0,
      once: true,
      mirror: false,
      anchorPlacement: 'top-bottom',
      disable: isMobile() ? true : false,
      startEvent: 'DOMContentLoaded',
      animatedClassName: 'aos-animate',
      useClassNames: false,
      disableMutationObserver: false,
      debounceDelay: 50,
      throttleDelay: 99,
    };

    // Merge user config with defaults
    const finalConfig = { ...defaultConfig, ...config };

    // Initialize AOS
    AOS.init(finalConfig);

    // Refresh AOS on window resize for responsive behavior
    const handleResize = () => {
      AOS.refresh();
    };

    window.addEventListener('resize', handleResize);

    // Cleanup function
    return () => {
      window.removeEventListener('resize', handleResize);
      AOS.refresh();
    };
  }, [config]);

  // Component doesn't render anything
  return null;
};