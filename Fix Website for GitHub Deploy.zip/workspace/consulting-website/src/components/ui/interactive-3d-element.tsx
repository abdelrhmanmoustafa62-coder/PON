"use client"

import { useEffect, useRef, useState } from 'react'
import { motion, useMotionValue, useSpring } from 'motion/react'

interface Shape3DProps {
  type: 'cube' | 'sphere' | 'pyramid'
  initialPosition: { x: number; y: number; z: number }
  size: number
  delay?: number
}

function Shape3D({ type, initialPosition, size, delay = 0 }: Shape3DProps) {
  const [isHovered, setIsHovered] = useState(false)
  const mouseX = useMotionValue(0)
  const mouseY = useMotionValue(0)
  
  const springConfig = { damping: 25, stiffness: 700 }
  const x = useSpring(mouseX, springConfig)
  const y = useSpring(mouseY, springConfig)

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      const rect = document.documentElement.getBoundingClientRect()
      const centerX = rect.width / 2
      const centerY = rect.height / 2
      
      // Calculate mouse position relative to center, scaled down for subtle effect
      const moveX = (e.clientX - centerX) * 0.02
      const moveY = (e.clientY - centerY) * 0.02
      
      mouseX.set(moveX)
      mouseY.set(moveY)
    }

    window.addEventListener('mousemove', handleMouseMove)
    return () => window.removeEventListener('mousemove', handleMouseMove)
  }, [mouseX, mouseY])

  const shapeVariants = {
    initial: {
      scale: 0,
      rotateX: 0,
      rotateY: 0,
      opacity: 0,
    },
    animate: {
      scale: 1,
      rotateX: 25,
      rotateY: -25,
      opacity: 1,
      transition: {
        delay,
        duration: 1.2,
        ease: "easeOut"
      }
    },
    hover: {
      scale: 1.1,
      rotateX: 35,
      rotateY: -35,
      transition: {
        duration: 0.3,
        ease: "easeOut"
      }
    }
  }

  const renderShape = () => {
    const baseClasses = `
      relative transform-gpu
      bg-gradient-to-br from-[#1e293b] to-[#0f172a]
      border border-[#334155]
      shadow-2xl
      backdrop-blur-sm
    `

    switch (type) {
      case 'cube':
        return (
          <div className={`${baseClasses} w-full h-full`}>
            {/* Front Face */}
            <div className="absolute inset-0 bg-gradient-to-br from-[#1e293b]/80 to-[#0f172a]/80 border border-[#334155]/50" />
            
            {/* Top Face */}
            <div 
              className="absolute inset-0 bg-gradient-to-br from-[#f59e0b]/20 to-[#1e293b]/80 border border-[#334155]/50"
              style={{
                transform: `rotateX(90deg) translateZ(${size/2}px)`,
                transformOrigin: 'top center'
              }}
            />
            
            {/* Right Face */}
            <div 
              className="absolute inset-0 bg-gradient-to-br from-[#1e293b]/60 to-[#0f172a]/90 border border-[#334155]/50"
              style={{
                transform: `rotateY(90deg) translateZ(${size/2}px)`,
                transformOrigin: 'right center'
              }}
            />
            
            {/* Accent highlight */}
            <div className="absolute top-2 left-2 w-4 h-4 bg-[#f59e0b]/30 rounded-full blur-sm" />
          </div>
        )
      
      case 'sphere':
        return (
          <div className={`${baseClasses} rounded-full w-full h-full overflow-hidden`}>
            {/* Main sphere body */}
            <div className="absolute inset-0 bg-gradient-to-br from-[#1e293b]/80 to-[#0f172a]/80 rounded-full" />
            
            {/* Highlight */}
            <div className="absolute top-2 left-4 w-6 h-6 bg-gradient-to-br from-[#f59e0b]/40 to-transparent rounded-full blur-sm" />
            
            {/* Subtle inner glow */}
            <div className="absolute inset-2 bg-gradient-to-br from-[#f59e0b]/10 to-transparent rounded-full" />
          </div>
        )
      
      case 'pyramid':
        return (
          <div className={`${baseClasses} w-full h-full relative`}>
            {/* Base */}
            <div className="absolute bottom-0 left-0 right-0 h-2 bg-gradient-to-r from-[#1e293b] to-[#0f172a] transform-gpu" />
            
            {/* Pyramid faces */}
            <div 
              className="absolute inset-0 bg-gradient-to-br from-[#f59e0b]/20 to-[#1e293b]/80 border border-[#334155]/50"
              style={{
                clipPath: 'polygon(50% 0%, 0% 100%, 100% 100%)'
              }}
            />
            
            {/* Side highlight */}
            <div 
              className="absolute inset-0 bg-gradient-to-br from-[#f59e0b]/30 to-transparent"
              style={{
                clipPath: 'polygon(50% 0%, 0% 100%, 50% 80%)'
              }}
            />
          </div>
        )
      
      default:
        return null
    }
  }

  return (
    <motion.div
      className="absolute pointer-events-none"
      style={{
        x,
        y,
        left: initialPosition.x,
        top: initialPosition.y,
        width: size,
        height: size,
        perspective: '1000px',
        transformStyle: 'preserve-3d',
      }}
      variants={shapeVariants}
      initial="initial"
      animate="animate"
      whileHover="hover"
      onHoverStart={() => setIsHovered(true)}
      onHoverEnd={() => setIsHovered(false)}
    >
      <motion.div
        className="w-full h-full"
        style={{
          transformStyle: 'preserve-3d',
        }}
        animate={{
          rotateY: isHovered ? 360 : 0,
        }}
        transition={{
          duration: isHovered ? 2 : 0,
          ease: "linear",
          repeat: isHovered ? Infinity : 0,
        }}
      >
        {renderShape()}
      </motion.div>
    </motion.div>
  )
}

export default function Interactive3DElement() {
  const containerRef = useRef<HTMLDivElement>(null)
  const [dimensions, setDimensions] = useState({ width: 0, height: 0 })

  useEffect(() => {
    const updateDimensions = () => {
      if (containerRef.current) {
        setDimensions({
          width: containerRef.current.offsetWidth,
          height: containerRef.current.offsetHeight
        })
      }
    }

    updateDimensions()
    window.addEventListener('resize', updateDimensions)
    return () => window.removeEventListener('resize', updateDimensions)
  }, [])

  // Generate random positions for shapes
  const shapes = [
    {
      type: 'cube' as const,
      initialPosition: { x: dimensions.width * 0.15, y: dimensions.height * 0.2, z: 0 },
      size: 60,
      delay: 0,
    },
    {
      type: 'sphere' as const,
      initialPosition: { x: dimensions.width * 0.8, y: dimensions.height * 0.15, z: 0 },
      size: 45,
      delay: 0.3,
    },
    {
      type: 'pyramid' as const,
      initialPosition: { x: dimensions.width * 0.7, y: dimensions.height * 0.6, z: 0 },
      size: 50,
      delay: 0.6,
    },
    {
      type: 'cube' as const,
      initialPosition: { x: dimensions.width * 0.1, y: dimensions.height * 0.7, z: 0 },
      size: 35,
      delay: 0.9,
    },
    {
      type: 'sphere' as const,
      initialPosition: { x: dimensions.width * 0.85, y: dimensions.height * 0.8, z: 0 },
      size: 40,
      delay: 1.2,
    },
  ]

  return (
    <div 
      ref={containerRef}
      className="absolute inset-0 overflow-hidden pointer-events-none"
      style={{
        perspective: '1000px',
        transformStyle: 'preserve-3d',
      }}
    >
      {/* Ambient floating animation */}
      <motion.div
        className="absolute inset-0"
        animate={{
          rotateX: [0, 2, 0, -2, 0],
          rotateY: [0, 1, 0, -1, 0],
        }}
        transition={{
          duration: 20,
          repeat: Infinity,
          ease: "linear",
        }}
      >
        {shapes.map((shape, index) => (
          <Shape3D
            key={index}
            type={shape.type}
            initialPosition={shape.initialPosition}
            size={shape.size}
            delay={shape.delay}
          />
        ))}
      </motion.div>

      {/* Subtle background glow effects */}
      <div className="absolute top-1/4 left-1/4 w-32 h-32 bg-[#f59e0b]/5 rounded-full blur-3xl" />
      <div className="absolute bottom-1/3 right-1/4 w-24 h-24 bg-[#1e293b]/10 rounded-full blur-3xl" />
    </div>
  )
}