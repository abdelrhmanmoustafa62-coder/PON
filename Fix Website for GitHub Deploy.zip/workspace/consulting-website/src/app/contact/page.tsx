"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowRight, Phone, Mail, MapPin, Globe, Clock, Printer, Building, MessageCircle, User, Briefcase, Send, CheckCircle } from "lucide-react";
import Link from "next/link";
import { Navbar } from "@/components/layout/navbar";

export default function ContactPage() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    company: '',
    phone: '',
    service: '',
    message: '',
    newsletter: false
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);

  const services = [
    "Market Analysis",
    "Real Estate & Investment", 
    "Financial Modeling",
    "M&A Advisory",
    "Due Diligence",
    "Risk Assessment",
    "Financial Structuring",
    "Bid Advisory",
    "Fund Raising"
  ];

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? (e.target as HTMLInputElement).checked : value
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    // Create mailto link with form data
    const subject = encodeURIComponent(`New Contact Form Submission - ${formData.name}`);
    const body = encodeURIComponent(`
Name: ${formData.name}
Email: ${formData.email}
Company: ${formData.company}
Phone: ${formData.phone}
Service Interest: ${formData.service}
Newsletter Subscription: ${formData.newsletter ? 'Yes' : 'No'}

Message:
${formData.message}

---
This message was sent from the Professional Opinion contact form.
    `);

    const mailtoLink = `mailto:at@iacct.sa?subject=${subject}&body=${body}`;
    
    // Open mail client
    window.location.href = mailtoLink;
    
    // Show success message
    setIsSubmitted(true);
    setIsSubmitting(false);
    
    // Reset form after 3 seconds
    setTimeout(() => {
      setIsSubmitted(false);
      setFormData({
        name: '',
        email: '',
        company: '',
        phone: '',
        service: '',
        message: '',
        newsletter: false
      });
    }, 3000);
  };

  return (
    <div className="min-h-screen bg-white dark:bg-[#1D1D1B]">
      <Navbar />
      
      {/* Hero Section */}
      <section className="pt-32 pb-16 hero-gradient">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-5xl lg:text-6xl font-bold text-white mb-6">
              CONTACT US
            </h1>
            <div className="w-24 h-1 bg-[#FBBA00] mx-auto mb-8"></div>
            <p className="text-xl text-gray-200 leading-relaxed">
              Professional contact form, Google Maps integration, and comprehensive contact details
            </p>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-20 bg-white dark:bg-[#1D1D1B]">
        <div className="container mx-auto px-4">
          <div className="max-w-7xl mx-auto">
            
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
              
              {/* Contact Form */}
              <Card className="border-0 shadow-xl">
                <CardHeader>
                  <CardTitle className="text-[#005A77] text-2xl flex items-center">
                    <MessageCircle className="w-6 h-6 mr-3" />
                    Send us a Message
                  </CardTitle>
                  <CardDescription className="text-lg">
                    Fill out the form below and we'll get back to you within 24 hours
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {isSubmitted ? (
                    <div className="text-center py-8">
                      <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
                      <h3 className="text-xl font-semibold text-[#005A77] mb-2">Message Sent Successfully!</h3>
                      <p className="text-gray-600 mb-4">
                        Your message has been sent to at@iacct.sa. We'll get back to you within 24 hours.
                      </p>
                      <p className="text-sm text-gray-500">
                        Your default email client should have opened. If not, please send an email manually to{' '}
                        <a href="mailto:at@iacct.sa" className="text-[#005A77] hover:text-[#FBBA00] font-medium">
                          at@iacct.sa
                        </a>
                      </p>
                    </div>
                  ) : (
                    <form onSubmit={handleSubmit} className="space-y-6">
                      {/* Name and Email Row */}
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <label className="flex items-center text-sm font-medium text-gray-700 mb-2">
                            <User className="w-4 h-4 mr-2" />
                            Name *
                          </label>
                          <input 
                            type="text" 
                            name="name"
                            value={formData.name}
                            onChange={handleInputChange}
                            required
                            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#FBBA00] focus:border-transparent transition-all duration-200" 
                            placeholder="Your full name" 
                          />
                        </div>
                        <div>
                          <label className="flex items-center text-sm font-medium text-gray-700 mb-2">
                            <Mail className="w-4 h-4 mr-2" />
                            Email *
                          </label>
                          <input 
                            type="email" 
                            name="email"
                            value={formData.email}
                            onChange={handleInputChange}
                            required
                            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#FBBA00] focus:border-transparent transition-all duration-200" 
                            placeholder="your@email.com" 
                          />
                        </div>
                      </div>

                      {/* Company and Phone Row */}
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <label className="flex items-center text-sm font-medium text-gray-700 mb-2">
                            <Building className="w-4 h-4 mr-2" />
                            Company
                          </label>
                          <input 
                            type="text" 
                            name="company"
                            value={formData.company}
                            onChange={handleInputChange}
                            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#FBBA00] focus:border-transparent transition-all duration-200" 
                            placeholder="Your company name" 
                          />
                        </div>
                        <div>
                          <label className="flex items-center text-sm font-medium text-gray-700 mb-2">
                            <Phone className="w-4 h-4 mr-2" />
                            Phone
                          </label>
                          <input 
                            type="tel" 
                            name="phone"
                            value={formData.phone}
                            onChange={handleInputChange}
                            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#FBBA00] focus:border-transparent transition-all duration-200" 
                            placeholder="+966 XX XXX XXXX" 
                          />
                        </div>
                      </div>

                      {/* Service Interest */}
                      <div>
                        <label className="flex items-center text-sm font-medium text-gray-700 mb-2">
                          <Briefcase className="w-4 h-4 mr-2" />
                          Service Interest
                        </label>
                        <select 
                          name="service"
                          value={formData.service}
                          onChange={handleInputChange}
                          className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#FBBA00] focus:border-transparent transition-all duration-200"
                        >
                          <option value="">Select a service</option>
                          {services.map(service => (
                            <option key={service} value={service}>
                              {service}
                            </option>
                          ))}
                        </select>
                      </div>

                      {/* Message */}
                      <div>
                        <label className="flex items-center text-sm font-medium text-gray-700 mb-2">
                          <MessageCircle className="w-4 h-4 mr-2" />
                          Message *
                        </label>
                        <textarea 
                          rows={5}
                          name="message"
                          value={formData.message}
                          onChange={handleInputChange}
                          required
                          className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#FBBA00] focus:border-transparent transition-all duration-200 resize-none" 
                          placeholder="Tell us about your project, objectives, and how we can help you achieve your goals..."
                        />
                      </div>

                      {/* Newsletter Checkbox */}
                      <div className="flex items-start space-x-3">
                        <input 
                          type="checkbox" 
                          id="newsletter" 
                          name="newsletter"
                          checked={formData.newsletter}
                          onChange={handleInputChange}
                          className="w-4 h-4 text-[#FBBA00] rounded focus:ring-[#FBBA00] mt-1" 
                        />
                        <label htmlFor="newsletter" className="text-sm text-gray-600 leading-relaxed">
                          Subscribe to our newsletter for industry insights, market analysis, and thought leadership content. We respect your privacy and send updates monthly.
                        </label>
                      </div>

                      {/* Submit Button */}
                      <Button 
                        type="submit"
                        disabled={isSubmitting}
                        className="w-full bg-[#005A77] hover:bg-[#0093A7] text-white py-4 text-lg font-semibold rounded-lg transition-all duration-300 hover:scale-105 shadow-lg hover:shadow-xl disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:scale-100"
                      >
                        {isSubmitting ? (
                          <>
                            <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
                            Sending...
                          </>
                        ) : (
                          <>
                            <Send className="w-5 h-5 mr-2" />
                            Send Message
                          </>
                        )}
                      </Button>
                    </form>
                  )}
                </CardContent>
              </Card>

              {/* Contact Information & Map */}
              <div className="space-y-8">
                
                {/* Contact Details */}
                <Card className="border-0 shadow-xl">
                  <CardHeader>
                    <CardTitle className="text-[#005A77] text-2xl flex items-center">
                      <Phone className="w-6 h-6 mr-3" />
                      Contact Information
                    </CardTitle>
                    <CardDescription className="text-lg">
                      Reach out to us through any of these channels
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    
                    {/* Address */}
                    <div className="flex items-start space-x-4 p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                      <MapPin className="w-6 h-6 text-[#FBBA00] mt-1 flex-shrink-0" />
                      <div>
                        <p className="font-semibold text-[#005A77] mb-1">Address</p>
                        <p className="text-gray-600">6th Floor, Tulip Tower</p>
                        <p className="text-gray-600">PO Box 18025, Riyadh 11415, KSA</p>
                      </div>
                    </div>

                    {/* Phone Numbers */}
                    <div className="flex items-start space-x-4 p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                      <Phone className="w-6 h-6 text-[#FBBA00] mt-1 flex-shrink-0" />
                      <div>
                        <p className="font-semibold text-[#005A77] mb-1">Phone</p>
                        <a href="tel:920005122" className="text-gray-600 hover:text-[#FBBA00] transition-colors block font-medium">
                          920005122 (Main)
                        </a>
                        <a href="tel:+966112002111" className="text-gray-600 hover:text-[#FBBA00] transition-colors block">
                          +966 11 200 2111 (Direct)
                        </a>
                      </div>
                    </div>

                    {/* Fax */}
                    <div className="flex items-start space-x-4 p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                      <Printer className="w-6 h-6 text-[#FBBA00] mt-1 flex-shrink-0" />
                      <div>
                        <p className="font-semibold text-[#005A77] mb-1">Fax</p>
                        <p className="text-gray-600">+966 11 205 1215</p>
                      </div>
                    </div>

                    {/* Email */}
                    <div className="flex items-start space-x-4 p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                      <Mail className="w-6 h-6 text-[#FBBA00] mt-1 flex-shrink-0" />
                      <div>
                        <p className="font-semibold text-[#005A77] mb-1">Email</p>
                        <a href="mailto:at@iacct.sa" className="text-gray-600 hover:text-[#FBBA00] transition-colors font-medium">
                          at@iacct.sa
                        </a>
                      </div>
                    </div>

                    {/* Website */}
                    <div className="flex items-start space-x-4 p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                      <Globe className="w-6 h-6 text-[#FBBA00] mt-1 flex-shrink-0" />
                      <div>
                        <p className="font-semibold text-[#005A77] mb-1">Website</p>
                        <a href="https://www.po.sa" target="_blank" rel="noopener noreferrer" className="text-gray-600 hover:text-[#FBBA00] transition-colors font-medium">
                          www.po.sa
                        </a>
                      </div>
                    </div>

                    {/* Business Hours */}
                    <div className="flex items-start space-x-4 p-4 bg-gray-50 rounded-lg">
                      <Clock className="w-6 h-6 text-[#FBBA00] mt-1 flex-shrink-0" />
                      <div>
                        <p className="font-semibold text-[#005A77] mb-1">Business Hours</p>
                        <p className="text-gray-600">Sunday - Thursday: 8:00 AM - 6:00 PM</p>
                        <p className="text-gray-600">Friday - Saturday: Closed</p>
                        <p className="text-gray-600 text-sm mt-1 italic">GMT+3 (Riyadh Time)</p>
                      </div>
                    </div>

                  </CardContent>
                </Card>

                {/* Direct Email Contact */}
                <Card className="border-2 border-[#FBBA00] bg-[#FBBA00]/5">
                  <CardContent className="p-6 text-center">
                    <Mail className="w-12 h-12 text-[#005A77] mx-auto mb-4" />
                    <h4 className="text-lg font-bold text-[#005A77] mb-2">Direct Email Contact</h4>
                    <p className="text-gray-600 mb-4">
                      Send us a message directly to our dedicated contact email
                    </p>
                    <Button 
                      onClick={() => window.location.href = 'mailto:at@iacct.sa'}
                      className="bg-[#005A77] hover:bg-[#0093A7] text-white"
                    >
                      <Mail className="w-4 h-4 mr-2" />
                      Send Email to at@iacct.sa
                    </Button>
                  </CardContent>
                </Card>

                {/* Google Map Embed */}
                <Card className="border-0 shadow-xl">
                  <CardHeader>
                    <CardTitle className="text-[#005A77] text-xl flex items-center">
                      <MapPin className="w-5 h-5 mr-2" />
                      Our Location
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="p-0">
                    <div className="w-full h-80 bg-gray-200 rounded-b-lg overflow-hidden">
                      <iframe
                        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3624.0157892534545!2d46.686172075741896!3d24.71284797787937!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3e2f03890d489399%3A0xba974d1c98e79fd5!2sTulip%20Tower%2C%20King%20Fahd%20Road%2C%20Riyadh%20Saudi%20Arabia!5e0!3m2!1sen!2s!4v1635000000000!5m2!1sen!2s"
                        width="100%"
                        height="100%"
                        style={{ border: 0 }}
                        allowFullScreen={true}
                        loading="lazy"
                        referrerPolicy="no-referrer-when-downgrade"
                        title="Professional Opinion Office Location - Tulip Tower, Riyadh"
                      />
                    </div>
                  </CardContent>
                </Card>

              </div>
            </div>

            {/* Multi-Language Support Notice */}
            <div className="mt-16">
              <Card className="bg-[#005A77] text-white border-0">
                <CardContent className="p-8 text-center">
                  <h3 className="text-2xl font-bold mb-4">Multi-Language Communication</h3>
                  <p className="text-gray-200 mb-6">
                    Our team is ready to assist you in your preferred language:
                  </p>
                  <div className="flex justify-center space-x-6">
                    <Badge className="bg-[#FBBA00] text-[#005A77] text-lg px-6 py-3">
                      🇺🇸 English
                    </Badge>
                    <Badge className="bg-[#FBBA00] text-[#005A77] text-lg px-6 py-3">
                      🇸🇦 العربية
                    </Badge>
                    <Badge className="bg-[#FBBA00] text-[#005A77] text-lg px-6 py-3">
                      🇨🇳 中文
                    </Badge>
                  </div>
                  <p className="text-gray-300 mt-4 text-sm">
                    All forms, consultations, and documentation are available in these languages
                  </p>
                </CardContent>
              </Card>
            </div>

            {/* Social Media Links */}
            <div className="mt-12">
              <div className="text-center">
                <h3 className="text-2xl font-bold text-[#005A77] dark:text-white mb-6">Connect With Us</h3>
                <div className="flex justify-center space-x-6">
                  <a href="#" className="bg-[#005A77] hover:bg-[#FBBA00] p-4 rounded-full transition-colors group">
                    <svg className="w-6 h-6 text-white group-hover:text-[#005A77]" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M16.338 16.338H13.67V12.16c0-.995-.017-2.277-1.387-2.277-1.39 0-1.601 1.086-1.601 2.207v4.248H8.014v-8.59h2.559v1.174h.037c.356-.675 1.227-1.387 2.526-1.387 2.703 0 3.203 1.778 3.203 4.092v4.711zM5.005 6.575a1.548 1.548 0 11-.003-3.096 1.548 1.548 0 01.003 3.096zm-1.337 9.763H6.34v-8.59H3.667v8.59zM17.668 1H2.328C1.595 1 1 1.581 1 2.298v15.403C1 18.418 1.595 19 2.328 19h15.34c.734 0 1.332-.582 1.332-1.299V2.298C19 1.581 18.402 1 17.668 1z" />
                    </svg>
                  </a>
                  <a href="#" className="bg-[#005A77] hover:bg-[#FBBA00] p-4 rounded-full transition-colors group">
                    <svg className="w-6 h-6 text-white group-hover:text-[#005A77]" fill="currentColor" viewBox="0 0 20 20">
                      <path d="M6.29 18.251c7.547 0 11.675-6.253 11.675-11.675 0-.178 0-.355-.012-.53A8.348 8.348 0 0020 3.92a8.19 8.19 0 01-2.357.646 4.118 4.118 0 001.804-2.27 8.224 8.224 0 01-2.605.996 4.107 4.107 0 00-6.993 3.743 11.65 11.65 0 01-8.457-4.287 4.106 4.106 0 001.27 5.477A4.073 4.073 0 01.8 7.713v.052a4.105 4.105 0 003.292 4.022 4.095 4.095 0 01-1.853.07 4.108 4.108 0 003.834 2.85A8.233 8.233 0 010 16.407a11.616 11.616 0 006.29 1.84" />
                    </svg>
                  </a>
                </div>
              </div>
            </div>

            {/* Emergency Contact */}
            <div className="mt-12">
              <Card className="border-2 border-[#FBBA00] bg-[#FBBA00]/5">
                <CardContent className="p-6 text-center">
                  <h4 className="text-lg font-bold text-[#005A77] mb-2">Urgent Matters</h4>
                  <p className="text-gray-600 mb-4">
                    For time-sensitive matters requiring immediate attention, please call our main line and specify the urgency.
                  </p>
                  <Button variant="outline" className="border-[#005A77] text-[#005A77] hover:bg-[#005A77] hover:text-white">
                    <Phone className="w-4 h-4 mr-2" />
                    Call Now: 920005122
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-[#1D1D1B] text-white py-16">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="lg:col-span-2">
              <div className="flex items-center space-x-3 mb-6">
                <div className="w-10 h-10 bg-gradient-to-r from-[#005A77] to-[#FBBA00] rounded-full flex items-center justify-center">
                  <span className="text-white font-bold">PO</span>
                </div>
                <span className="text-2xl font-bold">Professional Opinion</span>
              </div>
              <p className="text-gray-300 mb-6 text-lg leading-relaxed max-w-md">
                Licensed financial and management advisory firm delivering strategic solutions across the Middle East and beyond.
              </p>
            </div>
            <div>
              <h3 className="text-xl font-semibold text-[#FBBA00] mb-6">Quick Links</h3>
              <ul className="space-y-3">
                <li><Link href="/about" className="text-gray-300 hover:text-[#FBBA00] transition-colors">About</Link></li>
                <li><Link href="/services" className="text-gray-300 hover:text-[#FBBA00] transition-colors">Services</Link></li>
                <li><Link href="/team" className="text-gray-300 hover:text-[#FBBA00] transition-colors">Team</Link></li>
                <li><Link href="/insights" className="text-gray-300 hover:text-[#FBBA00] transition-colors">Insights</Link></li>
                <li><Link href="/contact" className="text-gray-300 hover:text-[#FBBA00] transition-colors">Contact</Link></li>
              </ul>
            </div>
            <div>
              <h3 className="text-xl font-semibold text-[#FBBA00] mb-6">Legal</h3>
              <ul className="space-y-3">
                <li><Link href="/terms" className="text-gray-300 hover:text-[#FBBA00] transition-colors">Terms & Conditions</Link></li>
                <li><Link href="/privacy" className="text-gray-300 hover:text-[#FBBA00] transition-colors">Privacy Policy</Link></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-700 mt-12 pt-8 text-center">
            <p className="text-gray-400">© 2025 Professional Opinion. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}