import { Suspense } from "react";
import { Hero3D } from "@/components/3d/hero-3d";
import { AOSInitializer } from "@/components/ui/aos-init";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowRight, Building, Globe, TrendingUp, Shield, Users, Award, Star, CheckCircle, Phone, Mail, MapPin, Target, Heart, Eye, Lightbulb, Handshake, BarChart3, PieChart, FileText, Search, DollarSign, Home, Briefcase, BookOpen, Clock, Calendar, Zap, Filter, Image, User, MessageCircle } from "lucide-react";
import Link from "next/link";
import { Navbar } from "@/components/layout/navbar";

// Loading fallback component
const LoadingFallback = () => (
  <div className="flex items-center justify-center min-h-screen bg-[#005A77]">
    <div className="text-center">
      <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-[#FBBA00] mx-auto mb-4"></div>
      <p className="text-white text-lg">Loading Professional Opinion...</p>
    </div>
  </div>
);

export default function HomePage() {
  return (
    <div className="min-h-screen bg-white dark:bg-[#1D1D1B]">
      <Suspense fallback={<LoadingFallback />}>
        {/* Initialize AOS */}
        <AOSInitializer />
        
        {/* Navigation */}
        <Navbar />

        {/* Hero Section with 3D Torus Knot */}
        <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
          {/* 3D Background with Torus Knot */}
          <div className="absolute inset-0 z-0">
            <div className="w-full h-full hero-gradient">
              <Hero3D />
            </div>
          </div>

          {/* Hero Content */}
          <div className="relative z-10 text-center px-4 sm:px-6 lg:px-8 max-w-6xl mx-auto">
            <div data-aos="fade-up" data-aos-duration="1000">
              <h1 className="text-5xl sm:text-6xl lg:text-8xl font-bold text-white mb-6 leading-tight font-serif">
                PROFESSIONAL OPINION
              </h1>
            </div>
            <div data-aos="fade-up" data-aos-delay="200" data-aos-duration="1000">
              <p className="text-2xl sm:text-3xl lg:text-4xl text-[#FBBA00] mb-8 font-bold font-serif">
                Empowering Business with Strategic Solutions
              </p>
              <div className="flex justify-center space-x-4 mb-8">
                <Badge className="bg-[#FBBA00] text-[#005A77] text-sm px-4 py-2">🇺🇸 English</Badge>
                <Badge className="bg-[#FBBA00] text-[#005A77] text-sm px-4 py-2">🇸🇦 العربية</Badge>
                <Badge className="bg-[#FBBA00] text-[#005A77] text-sm px-4 py-2">🇨🇳 中文</Badge>
              </div>
            </div>
            <div data-aos="fade-up" data-aos-delay="400" data-aos-duration="1000">
              <p className="text-lg sm:text-xl text-gray-200 mb-12 max-w-4xl mx-auto leading-relaxed">
                Licensed financial and management advisory firm in Saudi Arabia, delivering professional and high-quality advisory services as an independent member of the HLB Global Advisory Network.
              </p>
            </div>
            <div data-aos="fade-up" data-aos-delay="600" data-aos-duration="1000" className="flex flex-col sm:flex-row gap-6 justify-center">
              <Link href="/contact">
                <Button size="lg" className="bg-[#005A77] hover:bg-[#0093A7] text-white px-12 py-4 text-lg font-semibold rounded-full transition-all duration-300 hover:scale-105 hover:shadow-2xl">
                  Get Consultation
                  <ArrowRight className="ml-3 h-5 w-5" />
                </Button>
              </Link>
              <Link href="/contact">
                <Button size="lg" variant="outline" className="border-2 border-[#C8D3D9] text-white hover:bg-[#C8D3D9] hover:text-[#005A77] px-12 py-4 text-lg font-semibold rounded-full transition-all duration-300 hover:scale-105 hover:shadow-2xl">
                  Contact Us
                </Button>
              </Link>
            </div>
          </div>

          {/* Scroll indicator */}
          <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 z-10" data-aos="fade-in" data-aos-delay="1000">
            <div className="scroll-indicator"></div>
          </div>
        </section>

        {/* Mission, Vision, Values Section */}
        <section className="py-20 section-bg">
          <div className="container mx-auto px-4">
            <div className="max-w-6xl mx-auto">
              <div className="text-center mb-16" data-aos="fade-up">
                <h2 className="text-4xl lg:text-5xl font-bold text-[#005A77] mb-6">MISSION, VISION & VALUES</h2>
                <div className="w-24 h-1 bg-[#FBBA00] mx-auto mb-8"></div>
                <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                  Our foundation built on excellence, integrity, and innovation
                </p>
              </div>
              
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-16">
                {/* Mission */}
                <Card className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 group hover:-translate-y-2" data-aos="fade-up" data-aos-delay="0">
                  <CardHeader className="text-center pb-4">
                    <div className="w-16 h-16 bg-[#005A77] rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-[#FBBA00] group-hover:scale-110 transition-all duration-300">
                      <Target className="w-8 h-8 text-white" />
                    </div>
                    <CardTitle className="text-xl text-[#005A77] group-hover:text-[#FBBA00] transition-colors">Mission</CardTitle>
                  </CardHeader>
                  <CardContent className="text-center">
                    <p className="text-gray-600 text-sm leading-relaxed">
                      Empower clients with high-quality, insightful advisory solutions that drive sustainable growth, reduce risks, and maximize value through excellence, integrity, and innovation.
                    </p>
                  </CardContent>
                </Card>

                {/* Vision */}
                <Card className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 group hover:-translate-y-2" data-aos="fade-up" data-aos-delay="100">
                  <CardHeader className="text-center pb-4">
                    <div className="w-16 h-16 bg-[#005A77] rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-[#FBBA00] group-hover:scale-110 transition-all duration-300">
                      <Eye className="w-8 h-8 text-white" />
                    </div>
                    <CardTitle className="text-xl text-[#005A77] group-hover:text-[#FBBA00] transition-colors">Vision</CardTitle>
                  </CardHeader>
                  <CardContent className="text-center">
                    <p className="text-gray-600 text-sm leading-relaxed">
                      Lead in strategic business solutions, merging global best practices with local insights for transformative impact.
                    </p>
                  </CardContent>
                </Card>

                {/* Values */}
                <Card className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 group hover:-translate-y-2" data-aos="fade-up" data-aos-delay="200">
                  <CardHeader className="text-center pb-4">
                    <div className="w-16 h-16 bg-[#005A77] rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-[#FBBA00] group-hover:scale-110 transition-all duration-300">
                      <Heart className="w-8 h-8 text-white" />
                    </div>
                    <CardTitle className="text-xl text-[#005A77] group-hover:text-[#FBBA00] transition-colors">Values</CardTitle>
                  </CardHeader>
                  <CardContent className="text-center">
                    <p className="text-gray-600 text-sm leading-relaxed">
                      Excellence, integrity, innovation, and client-centricity guide every engagement and decision we make.
                    </p>
                  </CardContent>
                </Card>
              </div>

              {/* Four Core Values */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                <Card className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 group hover:-translate-y-2" data-aos="fade-up" data-aos-delay="0">
                  <CardHeader className="text-center pb-4">
                    <div className="w-16 h-16 bg-[#005A77] rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-[#FBBA00] group-hover:scale-110 transition-all duration-300">
                      <Globe className="w-8 h-8 text-white" />
                    </div>
                    <CardTitle className="text-lg text-[#005A77] group-hover:text-[#FBBA00] transition-colors">Global Expertise with Local Insight</CardTitle>
                  </CardHeader>
                  <CardContent className="text-center">
                    <p className="text-gray-600 text-sm">
                      Combining HLB standards with Saudi market knowledge.
                    </p>
                  </CardContent>
                </Card>

                <Card className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 group hover:-translate-y-2" data-aos="fade-up" data-aos-delay="100">
                  <CardHeader className="text-center pb-4">
                    <div className="w-16 h-16 bg-[#005A77] rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-[#FBBA00] group-hover:scale-110 transition-all duration-300">
                      <Users className="w-8 h-8 text-white" />
                    </div>
                    <CardTitle className="text-lg text-[#005A77] group-hover:text-[#FBBA00] transition-colors">Tailored Client Solutions</CardTitle>
                  </CardHeader>
                  <CardContent className="text-center">
                    <p className="text-gray-600 text-sm">
                      Custom strategies for unique client needs.
                    </p>
                  </CardContent>
                </Card>

                <Card className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 group hover:-translate-y-2" data-aos="fade-up" data-aos-delay="200">
                  <CardHeader className="text-center pb-4">
                    <div className="w-16 h-16 bg-[#005A77] rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-[#FBBA00] group-hover:scale-110 transition-all duration-300">
                      <Shield className="w-8 h-8 text-white" />
                    </div>
                    <CardTitle className="text-lg text-[#005A77] group-hover:text-[#FBBA00] transition-colors">Commitment to Excellence and Integrity</CardTitle>
                  </CardHeader>
                  <CardContent className="text-center">
                    <p className="text-gray-600 text-sm">
                      Ethical, high-quality results.
                    </p>
                  </CardContent>
                </Card>

                <Card className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 group hover:-translate-y-2" data-aos="fade-up" data-aos-delay="300">
                  <CardHeader className="text-center pb-4">
                    <div className="w-16 h-16 bg-[#005A77] rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-[#FBBA00] group-hover:scale-110 transition-all duration-300">
                      <Handshake className="w-8 h-8 text-white" />
                    </div>
                    <CardTitle className="text-lg text-[#005A77] group-hover:text-[#FBBA00] transition-colors">Long-Term Partnerships</CardTitle>
                  </CardHeader>
                  <CardContent className="text-center">
                    <p className="text-gray-600 text-sm">
                      Building trust through measurable value.
                    </p>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </section>

        {/* Company Timeline */}
        <section className="py-20 bg-white dark:bg-[#1D1D1B]">
          <div className="container mx-auto px-4">
            <div className="max-w-6xl mx-auto">
              <div className="text-center mb-16" data-aos="fade-up">
                <h2 className="text-4xl lg:text-5xl font-bold text-[#005A77] dark:text-white mb-6">COMPANY TIMELINE</h2>
                <div className="w-24 h-1 bg-[#FBBA00] mx-auto mb-8"></div>
                <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
                  Key milestones in our journey to excellence
                </p>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                <Card className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 group hover:-translate-y-2 cursor-pointer" data-aos="fade-up" data-aos-delay="0">
                  <CardHeader className="text-center pb-4">
                    <div className="w-16 h-16 bg-[#005A77] rounded-lg flex items-center justify-center mx-auto mb-4 group-hover:bg-[#FBBA00] group-hover:scale-110 transition-all duration-300">
                      <Building className="w-8 h-8 text-white" />
                    </div>
                    <CardTitle className="text-lg text-[#005A77] group-hover:text-[#FBBA00] transition-colors">Company Founding</CardTitle>
                  </CardHeader>
                  <CardContent className="text-center">
                    <p className="text-gray-600 text-sm">
                      Established as a licensed financial and management advisory firm in Saudi Arabia.
                    </p>
                  </CardContent>
                </Card>

                <Card className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 group hover:-translate-y-2 cursor-pointer" data-aos="fade-up" data-aos-delay="100">
                  <CardHeader className="text-center pb-4">
                    <div className="w-16 h-16 bg-[#005A77] rounded-lg flex items-center justify-center mx-auto mb-4 group-hover:bg-[#FBBA00] group-hover:scale-110 transition-all duration-300">
                      <Globe className="w-8 h-8 text-white" />
                    </div>
                    <CardTitle className="text-lg text-[#005A77] group-hover:text-[#FBBA00] transition-colors">HLB Affiliation</CardTitle>
                  </CardHeader>
                  <CardContent className="text-center">
                    <p className="text-gray-600 text-sm">
                      Became independent member of HLB Global Advisory Network, ranked 8th globally.
                    </p>
                  </CardContent>
                </Card>

                <Card className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 group hover:-translate-y-2 cursor-pointer" data-aos="fade-up" data-aos-delay="200">
                  <CardHeader className="text-center pb-4">
                    <div className="w-16 h-16 bg-[#005A77] rounded-lg flex items-center justify-center mx-auto mb-4 group-hover:bg-[#FBBA00] group-hover:scale-110 transition-all duration-300">
                      <TrendingUp className="w-8 h-8 text-white" />
                    </div>
                    <CardTitle className="text-lg text-[#005A77] group-hover:text-[#FBBA00] transition-colors">First Major M&A Deal</CardTitle>
                  </CardHeader>
                  <CardContent className="text-center">
                    <p className="text-gray-600 text-sm">
                      Successfully completed landmark merger and acquisition advisory project.
                    </p>
                  </CardContent>
                </Card>

                <Card className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 group hover:-translate-y-2 cursor-pointer" data-aos="fade-up" data-aos-delay="300">
                  <CardHeader className="text-center pb-4">
                    <div className="w-16 h-16 bg-[#005A77] rounded-lg flex items-center justify-center mx-auto mb-4 group-hover:bg-[#FBBA00] group-hover:scale-110 transition-all duration-300">
                      <Award className="w-8 h-8 text-white" />
                    </div>
                    <CardTitle className="text-lg text-[#005A77] group-hover:text-[#FBBA00] transition-colors">Regional Expansion</CardTitle>
                  </CardHeader>
                  <CardContent className="text-center">
                    <p className="text-gray-600 text-sm">
                      Expanded operations across the Middle East and established global partnerships.
                    </p>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </section>

        {/* Goals & Objectives */}
        <section className="py-20 section-bg">
          <div className="container mx-auto px-4">
            <div className="max-w-6xl mx-auto">
              <div className="text-center mb-16" data-aos="fade-up">
                <h2 className="text-4xl lg:text-5xl font-bold text-[#005A77] mb-6">GOALS & OBJECTIVES</h2>
                <div className="w-24 h-1 bg-[#FBBA00] mx-auto mb-8"></div>
                <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                  Our strategic objectives driving sustainable growth and client success
                </p>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                <Card className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 group hover:-translate-y-2 hover:scale-105" data-aos="fade-up" data-aos-delay="0">
                  <CardHeader className="text-center pb-4">
                    <div className="w-16 h-16 bg-[#005A77] rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-[#FBBA00] group-hover:scale-110 transition-all duration-300">
                      <Shield className="w-8 h-8 text-white" />
                    </div>
                    <CardTitle className="text-lg text-[#005A77] group-hover:text-[#FBBA00] transition-colors">Integrity and Transparency</CardTitle>
                  </CardHeader>
                  <CardContent className="text-center">
                    <p className="text-gray-600 text-sm">
                      Trust and openness in all interactions.
                    </p>
                  </CardContent>
                </Card>

                <Card className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 group hover:-translate-y-2 hover:scale-105" data-aos="fade-up" data-aos-delay="100">
                  <CardHeader className="text-center pb-4">
                    <div className="w-16 h-16 bg-[#005A77] rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-[#FBBA00] group-hover:scale-110 transition-all duration-300">
                      <Briefcase className="w-8 h-8 text-white" />
                    </div>
                    <CardTitle className="text-lg text-[#005A77] group-hover:text-[#FBBA00] transition-colors">Tailored Consulting</CardTitle>
                  </CardHeader>
                  <CardContent className="text-center">
                    <p className="text-gray-600 text-sm">
                      Customized, high-quality advisory services.
                    </p>
                  </CardContent>
                </Card>

                <Card className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 group hover:-translate-y-2 hover:scale-105" data-aos="fade-up" data-aos-delay="200">
                  <CardHeader className="text-center pb-4">
                    <div className="w-16 h-16 bg-[#005A77] rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-[#FBBA00] group-hover:scale-110 transition-all duration-300">
                      <TrendingUp className="w-8 h-8 text-white" />
                    </div>
                    <CardTitle className="text-lg text-[#005A77] group-hover:text-[#FBBA00] transition-colors">Sustainable Growth</CardTitle>
                  </CardHeader>
                  <CardContent className="text-center">
                    <p className="text-gray-600 text-sm">
                      Innovation-driven, long-term client growth.
                    </p>
                  </CardContent>
                </Card>

                <Card className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 group hover:-translate-y-2 hover:scale-105" data-aos="fade-up" data-aos-delay="300">
                  <CardHeader className="text-center pb-4">
                    <div className="w-16 h-16 bg-[#005A77] rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-[#FBBA00] group-hover:scale-110 transition-all duration-300">
                      <Handshake className="w-8 h-8 text-white" />
                    </div>
                    <CardTitle className="text-lg text-[#005A77] group-hover:text-[#FBBA00] transition-colors">Lasting Partnerships</CardTitle>
                  </CardHeader>
                  <CardContent className="text-center">
                    <p className="text-gray-600 text-sm">
                      Enduring relationships via meaningful outcomes.
                    </p>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </section>

        {/* Services Preview */}
        <section className="py-20 bg-white dark:bg-[#1D1D1B]">
          <div className="container mx-auto px-4">
            <div className="max-w-6xl mx-auto">
              <div className="text-center mb-16" data-aos="fade-up">
                <h2 className="text-4xl lg:text-5xl font-bold text-[#005A77] dark:text-white mb-6">OUR SERVICES</h2>
                <div className="w-24 h-1 bg-[#FBBA00] mx-auto mb-8"></div>
                <p className="text-xl text-gray-600 dark:text-gray-300 max-w-4xl mx-auto">
                  Comprehensive professional services for your business success
                </p>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {/* Business Valuation */}
                <Card className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 group hover:-translate-y-2 cursor-pointer" data-aos="fade-up" data-aos-delay="0">
                  <CardHeader>
                    <div className="w-12 h-12 bg-[#FBBA00] rounded-lg flex items-center justify-center mb-4 group-hover:bg-[#005A77] group-hover:scale-110 transition-all duration-300">
                      <BarChart3 className="w-6 h-6 text-white" />
                    </div>
                    <CardTitle className="text-[#005A77] group-hover:text-[#FBBA00] transition-colors">Business Valuation</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-600 mb-4">
                      Comprehensive valuation services for mergers, acquisitions, and strategic decisions.
                    </p>
                    <Button variant="outline" className="text-[#FBBA00] border-[#FBBA00] hover:bg-[#FBBA00] hover:text-white transition-all duration-300">
                      Learn More
                    </Button>
                  </CardContent>
                </Card>

                {/* M&A Advisory */}
                <Card className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 group hover:-translate-y-2 cursor-pointer" data-aos="fade-up" data-aos-delay="100">
                  <CardHeader>
                    <div className="w-12 h-12 bg-[#FBBA00] rounded-lg flex items-center justify-center mb-4 group-hover:bg-[#005A77] group-hover:scale-110 transition-all duration-300">
                      <TrendingUp className="w-6 h-6 text-white" />
                    </div>
                    <CardTitle className="text-[#005A77] group-hover:text-[#FBBA00] transition-colors">M&A Advisory</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-600 mb-4">
                      Strategic advisory services for mergers, acquisitions, and corporate restructuring.
                    </p>
                    <Button variant="outline" className="text-[#FBBA00] border-[#FBBA00] hover:bg-[#FBBA00] hover:text-white transition-all duration-300">
                      Learn More
                    </Button>
                  </CardContent>
                </Card>

                {/* Financial Advisory */}
                <Card className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 group hover:-translate-y-2 cursor-pointer" data-aos="fade-up" data-aos-delay="200">
                  <CardHeader>
                    <div className="w-12 h-12 bg-[#FBBA00] rounded-lg flex items-center justify-center mb-4 group-hover:bg-[#005A77] group-hover:scale-110 transition-all duration-300">
                      <PieChart className="w-6 h-6 text-white" />
                    </div>
                    <CardTitle className="text-[#005A77] group-hover:text-[#FBBA00] transition-colors">Financial Advisory</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-600 mb-4">
                      Expert financial guidance for strategic business decisions and growth planning.
                    </p>
                    <Button variant="outline" className="text-[#FBBA00] border-[#FBBA00] hover:bg-[#FBBA00] hover:text-white transition-all duration-300">
                      Learn More
                    </Button>
                  </CardContent>
                </Card>

                {/* Transaction Advisory */}
                <Card className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 group hover:-translate-y-2 cursor-pointer" data-aos="fade-up" data-aos-delay="300">
                  <CardHeader>
                    <div className="w-12 h-12 bg-[#FBBA00] rounded-lg flex items-center justify-center mb-4 group-hover:bg-[#005A77] group-hover:scale-110 transition-all duration-300">
                      <FileText className="w-6 h-6 text-white" />
                    </div>
                    <CardTitle className="text-[#005A77] group-hover:text-[#FBBA00] transition-colors">Transaction Advisory</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-600 mb-4">
                      Due diligence and transaction support services for successful deal completion.
                    </p>
                    <Button variant="outline" className="text-[#FBBA00] border-[#FBBA00] hover:bg-[#FBBA00] hover:text-white transition-all duration-300">
                      Learn More
                    </Button>
                  </CardContent>
                </Card>

                {/* Risk Management */}
                <Card className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 group hover:-translate-y-2 cursor-pointer" data-aos="fade-up" data-aos-delay="400">
                  <CardHeader>
                    <div className="w-12 h-12 bg-[#FBBA00] rounded-lg flex items-center justify-center mb-4 group-hover:bg-[#005A77] group-hover:scale-110 transition-all duration-300">
                      <Shield className="w-6 h-6 text-white" />
                    </div>
                    <CardTitle className="text-[#005A77] group-hover:text-[#FBBA00] transition-colors">Risk Management</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-600 mb-4">
                      Comprehensive risk assessment and mitigation strategies for your business.
                    </p>
                    <Button variant="outline" className="text-[#FBBA00] border-[#FBBA00] hover:bg-[#FBBA00] hover:text-white transition-all duration-300">
                      Learn More
                    </Button>
                  </CardContent>
                </Card>

                {/* Corporate Finance */}
                <Card className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 group hover:-translate-y-2 cursor-pointer" data-aos="fade-up" data-aos-delay="500">
                  <CardHeader>
                    <div className="w-12 h-12 bg-[#FBBA00] rounded-lg flex items-center justify-center mb-4 group-hover:bg-[#005A77] group-hover:scale-110 transition-all duration-300">
                      <DollarSign className="w-6 h-6 text-white" />
                    </div>
                    <CardTitle className="text-[#005A77] group-hover:text-[#FBBA00] transition-colors">Corporate Finance</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-600 mb-4">
                      Capital structure optimization and financing solutions for business growth.
                    </p>
                    <Button variant="outline" className="text-[#FBBA00] border-[#FBBA00] hover:bg-[#FBBA00] hover:text-white transition-all duration-300">
                      Learn More
                    </Button>
                  </CardContent>
                </Card>
              </div>

              <div className="text-center mt-12" data-aos="fade-up" data-aos-delay="600">
                <Link href="/services">
                  <Button className="bg-[#005A77] hover:bg-[#0093A7] text-white px-8 py-3 text-lg font-semibold rounded-full transition-all duration-300 hover:scale-105 shadow-lg hover:shadow-xl">
                    View All Services
                    <ArrowRight className="ml-2 h-5 w-5" />
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </section>

        {/* Global Outreach - Network and Expertise */}
        <section className="py-20 bg-[#005A77] text-white">
          <div className="container mx-auto px-4">
            <div className="max-w-6xl mx-auto">
              <div className="text-center mb-16" data-aos="fade-up">
                <h2 className="text-4xl lg:text-5xl font-bold mb-6">GLOBAL OUTREACH</h2>
                <div className="w-24 h-1 bg-[#FBBA00] mx-auto mb-8"></div>
                <p className="text-xl text-gray-200 max-w-3xl mx-auto">
                  Network and expertise spanning across continents
                </p>
              </div>
              
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-16">
                {/* Left Column - Network Info */}
                <div className="space-y-8" data-aos="fade-right">
                  <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6">
                    <h3 className="text-2xl font-bold text-[#FBBA00] mb-4">HLB Affiliation</h3>
                    <p className="text-gray-200 text-lg leading-relaxed">
                      Independent member of HLB Global Advisory Network, ranked 8th globally, providing access to extensive resources.
                    </p>
                  </div>
                  <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6">
                    <h3 className="text-2xl font-bold text-[#FBBA00] mb-4">Regional Presence</h3>
                    <p className="text-gray-200 text-lg leading-relaxed">
                      Offices and partnerships across multiple continents, collaborating with top global consulting firms.
                    </p>
                  </div>
                </div>
                
                {/* Right Column - Stats */}
                <div className="space-y-8" data-aos="fade-left">
                  <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6">
                    <h3 className="text-2xl font-bold text-[#FBBA00] mb-4">Client Statistics</h3>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="text-center">
                        <div className="text-4xl font-bold text-[#FBBA00] mb-2">155</div>
                        <div className="text-gray-300">Countries</div>
                      </div>
                      <div className="text-center">
                        <div className="text-4xl font-bold text-[#FBBA00] mb-2">1,139</div>
                        <div className="text-gray-300">Offices</div>
                      </div>
                      <div className="text-center">
                        <div className="text-4xl font-bold text-[#FBBA00] mb-2">51,948</div>
                        <div className="text-gray-300">People</div>
                      </div>
                      <div className="text-center">
                        <div className="text-4xl font-bold text-[#FBBA00] mb-2">8</div>
                        <div className="text-gray-300">Global Ranking</div>
                      </div>
                    </div>
                  </div>
                  <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6">
                    <h3 className="text-2xl font-bold text-[#FBBA00] mb-4">Global-Local Integration</h3>
                    <p className="text-gray-200 text-lg leading-relaxed">
                      Combines international standards with Saudi market insights for tailored project delivery.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Contact Section */}
        <section className="py-20 bg-[#f1f5f9]">
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto">
              <div className="text-center mb-16" data-aos="fade-up">
                <h2 className="text-4xl lg:text-5xl font-bold text-[#005A77] mb-6">GET IN TOUCH</h2>
                <div className="w-24 h-1 bg-[#FBBA00] mx-auto mb-8"></div>
                <p className="text-xl text-gray-600 max-w-2xl mx-auto">Ready to transform your business? Let's discuss your strategic objectives.</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
                <Card className="border-0 shadow-lg text-center" data-aos="fade-up" data-aos-delay="0">
                  <CardContent className="p-6">
                    <div className="w-12 h-12 bg-[#FBBA00] rounded-lg flex items-center justify-center mx-auto mb-4">
                      <Phone className="w-6 h-6 text-white" />
                    </div>
                    <h3 className="text-xl font-semibold text-[#005A77] mb-2">Phone</h3>
                    <p className="text-gray-600">+966 11 200 2111</p>
                  </CardContent>
                </Card>

                <Card className="border-0 shadow-lg text-center" data-aos="fade-up" data-aos-delay="100">
                  <CardContent className="p-6">
                    <div className="w-12 h-12 bg-[#FBBA00] rounded-lg flex items-center justify-center mx-auto mb-4">
                      <Mail className="w-6 h-6 text-white" />
                    </div>
                    <h3 className="text-xl font-semibold text-[#005A77] mb-2">Email</h3>
                    <p className="text-gray-600">info@po.sa</p>
                  </CardContent>
                </Card>

                <Card className="border-0 shadow-lg text-center" data-aos="fade-up" data-aos-delay="200">
                  <CardContent className="p-6">
                    <div className="w-12 h-12 bg-[#FBBA00] rounded-lg flex items-center justify-center mx-auto mb-4">
                      <MapPin className="w-6 h-6 text-white" />
                    </div>
                    <h3 className="text-xl font-semibold text-[#005A77] mb-2">Address</h3>
                    <p className="text-gray-600">Riyadh, Saudi Arabia</p>
                  </CardContent>
                </Card>
              </div>

              <div className="text-center" data-aos="fade-up" data-aos-delay="300">
                <Link href="/contact">
                  <Button className="bg-[#005A77] hover:bg-[#0093A7] text-white px-8 py-3 text-lg font-semibold rounded-full transition-all duration-300 hover:scale-105 shadow-lg hover:shadow-xl">
                    Contact Us Today
                    <ArrowRight className="ml-2 h-5 w-5" />
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </section>

        {/* Footer */}
        <footer className="bg-[#1D1D1B] text-white py-16">
          <div className="container mx-auto px-4">
            <div className="text-center">
              <div className="flex items-center justify-center space-x-3 mb-6">
                <div className="w-10 h-10 bg-gradient-to-r from-[#005A77] to-[#FBBA00] rounded-full flex items-center justify-center">
                  <span className="text-white font-bold">PO</span>
                </div>
                <span className="text-2xl font-bold">Professional Opinion</span>
              </div>
              <p className="text-gray-400 text-lg">
                © 2025 Professional Opinion. All rights reserved.
              </p>
            </div>
          </div>
        </footer>
      </Suspense>
    </div>
  );
}