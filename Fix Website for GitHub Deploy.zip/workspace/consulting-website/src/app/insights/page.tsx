"use client";

import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { 
  TrendingUp, 
  Building2, 
  Target, 
  CheckCircle, 
  Home, 
  Factory, 
  Award,
  ArrowRight,
  Star,
  Building,
  DollarSign,
  Users,
  Globe,
  BookOpen,
  FileText,
  Image,
  BarChart3,
  Filter,
  Calendar,
  ChevronLeft,
  ChevronRight,
  X,
  ExternalLink,
  Clock,
  MapPin,
  Briefcase,
  TrendingDown
} from "lucide-react";
import Link from "next/link";
import { Navbar } from "@/components/layout/navbar";

export default function InsightsPage() {
  const [selectedCaseStudy, setSelectedCaseStudy] = useState<any>(null);
  const [selectedBlogPost, setSelectedBlogPost] = useState<any>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  const caseStudies = [
    {
      id: 1,
      title: "Maximizing Returns on Mixed-Use Real Estate Development",
      category: "Real Estate",
      year: "2023",
      service: "Valuation",
      image: "/api/placeholder/400/250",
      objective: "Optimize returns and compliance on a mixed-use real estate project.",
      approach: "Conducted feasibility study, best-use assessment, and REIT structuring.",
      outcome: "Optimized asset utilization with regulatory compliance, enhancing profitability.",
      stats: "15% profitability increase",
      industry: "Real Estate",
      insights: "Strategic REIT structuring enabled optimal capital allocation while maintaining regulatory compliance across multiple jurisdictions.",
      icon: <Building className="w-6 h-6" />,
      // Detailed content for modal
      client: "Major Regional Developer",
      duration: "8 months",
      location: "Riyadh, Saudi Arabia",
      projectValue: "$120M",
      teamSize: "12 professionals",
      challenges: [
        "Complex regulatory environment spanning multiple jurisdictions",
        "Mixed-use development requiring diverse valuation approaches",
        "REIT structuring compliance with local and international standards",
        "Optimization of asset allocation across commercial and residential units"
      ],
      detailedApproach: [
        "Comprehensive market analysis and feasibility study",
        "Best-use assessment for mixed commercial and residential components",
        "REIT structuring analysis with regulatory compliance review",
        "Financial modeling for optimized asset allocation",
        "Risk assessment and mitigation strategies"
      ],
      detailedOutcome: [
        "15% increase in overall project profitability",
        "Successful REIT structure implementation",
        "Full regulatory compliance achieved",
        "Enhanced asset utilization across all property types",
        "Improved investor confidence and market positioning"
      ],
      keyMetrics: [
        { label: "ROI Improvement", value: "15%" },
        { label: "Asset Utilization", value: "92%" },
        { label: "Regulatory Compliance", value: "100%" },
        { label: "Timeline Efficiency", value: "98%" }
      ]
    },
    {
      id: 2,
      title: "Strategic Merger Valuation for Manufacturing Sector",
      category: "M&A",
      year: "2024",
      service: "M&A",
      image: "/api/placeholder/400/250",
      objective: "Accurate valuation and support for a strategic merger in manufacturing.",
      approach: "Applied multiple valuation methods, supported M&A activities from partner identification to final negotiation.",
      outcome: "Delivered optimal valuation and secured successful merger.",
      stats: "20% value increase",
      industry: "Manufacturing",
      insights: "Comprehensive valuation methodology combining multiple approaches delivered precise merger terms and successful integration.",
      icon: <Factory className="w-6 h-6" />,
      // Detailed content for modal
      client: "Industrial Manufacturing Group",
      duration: "12 months",
      location: "Dammam, Saudi Arabia",
      projectValue: "$250M",
      teamSize: "15 professionals",
      challenges: [
        "Complex manufacturing asset valuation",
        "Multiple stakeholder alignment",
        "Integration planning and execution",
        "Market volatility during negotiation period"
      ],
      detailedApproach: [
        "Multi-methodology valuation approach (DCF, Market, Asset-based)",
        "Comprehensive due diligence and risk assessment",
        "Strategic partner identification and evaluation",
        "Negotiation support and deal structuring",
        "Post-merger integration planning"
      ],
      detailedOutcome: [
        "20% increase in combined entity value",
        "Successful merger completion within timeline",
        "Seamless integration of operations",
        "Enhanced market position and competitiveness",
        "Synergy realization exceeding projections"
      ],
      keyMetrics: [
        { label: "Value Creation", value: "20%" },
        { label: "Integration Success", value: "95%" },
        { label: "Synergy Realization", value: "112%" },
        { label: "Timeline Adherence", value: "100%" }
      ]
    },
    {
      id: 3,
      title: "Winning a High-Profile Public Infrastructure Bid",
      category: "Infrastructure",
      year: "2023",
      service: "Bid Advisory",
      image: "/api/placeholder/400/250",
      objective: "Guide client to win a competitive infrastructure project bid.",
      approach: "Provided bid structuring, risk assessment, and post-bid analysis.",
      outcome: "Client won the bid, reinforcing market leadership in public infrastructure.",
      stats: "Market leadership reinforced",
      industry: "Infrastructure",
      insights: "Strategic bid structure and comprehensive risk assessment enabled successful capture of high-value infrastructure project.",
      icon: <Award className="w-6 h-6" />,
      // Detailed content for modal
      client: "Leading Construction Consortium",
      duration: "6 months",
      location: "Jeddah, Saudi Arabia",
      projectValue: "$500M",
      teamSize: "20 professionals",
      challenges: [
        "Highly competitive bidding environment",
        "Complex technical and financial requirements",
        "Stringent regulatory compliance",
        "Risk management for large-scale infrastructure"
      ],
      detailedApproach: [
        "Comprehensive bid strategy development",
        "Financial modeling and pricing optimization",
        "Risk assessment and mitigation planning",
        "Technical proposal enhancement",
        "Post-bid analysis and presentation support"
      ],
      detailedOutcome: [
        "Successful bid win against 12 competitors",
        "Reinforced market leadership position",
        "Enhanced reputation in public sector",
        "Secured long-term partnership opportunities",
        "Established framework for future bids"
      ],
      keyMetrics: [
        { label: "Bid Success Rate", value: "100%" },
        { label: "Competitive Advantage", value: "85%" },
        { label: "Client Satisfaction", value: "98%" },
        { label: "Market Position", value: "Leader" }
      ]
    },
    {
      id: 4,
      title: "Successful IPO Launch on Regional Stock Exchange",
      category: "Finance",
      year: "2024",
      service: "Fund Raising",
      image: "/api/placeholder/400/250",
      objective: "Prepare and execute a successful IPO for client on a regional exchange.",
      approach: "Conducted IPO readiness assessment, investor engagement, and compliance management.",
      outcome: "Client raised substantial capital and expanded market presence.",
      stats: "$50M+ raised",
      industry: "Finance",
      insights: "Comprehensive IPO readiness program and strategic investor engagement resulted in successful public listing and capital raise.",
      icon: <DollarSign className="w-6 h-6" />,
      // Detailed content for modal
      client: "Emerging Technology Company",
      duration: "14 months",
      location: "Dubai, UAE",
      projectValue: "$75M",
      teamSize: "18 professionals",
      challenges: [
        "Market volatility during IPO timeline",
        "Regulatory compliance across jurisdictions",
        "Investor confidence building",
        "Complex financial restructuring"
      ],
      detailedApproach: [
        "IPO readiness assessment and gap analysis",
        "Financial restructuring and compliance preparation",
        "Investor roadshow planning and execution",
        "Regulatory filing and approval management",
        "Post-IPO support and market making"
      ],
      detailedOutcome: [
        "$52M successfully raised (104% of target)",
        "Oversubscribed IPO with strong institutional interest",
        "Successful market debut with 15% first-day gain",
        "Enhanced corporate governance and transparency",
        "Expanded market presence and growth opportunities"
      ],
      keyMetrics: [
        { label: "Capital Raised", value: "$52M" },
        { label: "Oversubscription", value: "180%" },
        { label: "First-day Performance", value: "+15%" },
        { label: "Institutional Interest", value: "92%" }
      ]
    },
    {
      id: 5,
      title: "Financial Modeling for Large-Scale Industrial Project Planning",
      category: "Manufacturing",
      year: "2025",
      service: "Financial Modeling",
      image: "/api/placeholder/400/250",
      objective: "Develop a financial model for planning a large-scale industrial project.",
      approach: "Created detailed financial projections and scenario analysis for effective planning.",
      outcome: "Provided a dynamic planning tool, improving financial oversight and strategy.",
      stats: "30% oversight improvement",
      industry: "Manufacturing",
      insights: "Dynamic financial modeling with scenario analysis enhanced strategic planning capabilities and risk management oversight.",
      icon: <BarChart3 className="w-6 h-6" />,
      // Detailed content for modal
      client: "Major Industrial Developer",
      duration: "10 months",
      location: "Jubail, Saudi Arabia",
      projectValue: "$300M",
      teamSize: "14 professionals",
      challenges: [
        "Complex multi-phase project structure",
        "Volatile commodity pricing environment",
        "Multiple financing sources coordination",
        "Regulatory approval dependencies"
      ],
      detailedApproach: [
        "Multi-phase financial model development",
        "Scenario analysis and sensitivity testing",
        "Cash flow optimization and funding planning",
        "Risk modeling and mitigation strategies",
        "Dynamic reporting and dashboard creation"
      ],
      detailedOutcome: [
        "30% improvement in financial oversight capabilities",
        "Enhanced strategic planning and decision-making",
        "Optimized funding structure and timeline",
        "Improved risk management and contingency planning",
        "Real-time performance monitoring system"
      ],
      keyMetrics: [
        { label: "Planning Efficiency", value: "30%" },
        { label: "Model Accuracy", value: "96%" },
        { label: "Decision Speed", value: "40%" },
        { label: "Risk Mitigation", value: "85%" }
      ]
    }
  ];

  const blogPosts = [
    {
      id: 1,
      title: "Navigating Saudi Arabia's M&A Landscape",
      category: "M&A",
      excerpt: "In-depth analysis of merger and acquisition trends in the Saudi Arabian market, including regulatory changes, sector opportunities, and strategic considerations for both local and international investors looking to capitalize on Vision 2030 initiatives.",
      image: "/api/placeholder/400/250",
      date: "2024-12-15",
      readTime: "8 min read",
      featured: true,
      author: "Dr. Ahmed Al-Rashid",
      authorTitle: "Senior Partner, M&A Advisory",
      // Detailed content for modal
      fullContent: {
        introduction: "Saudi Arabia's M&A landscape is experiencing unprecedented growth, driven by Vision 2030 initiatives and economic diversification efforts. This comprehensive analysis explores the key trends, opportunities, and challenges shaping the market.",
        sections: [
          {
            title: "Market Overview",
            content: "The Saudi M&A market has seen a 45% increase in transaction volume over the past two years, with total deal value reaching $28.5 billion in 2024. This surge is primarily attributed to the Kingdom's strategic economic transformation and privatization programs."
          },
          {
            title: "Key Sectors",
            content: "Energy transition, healthcare, technology, and real estate sectors are leading M&A activity. The NEOM project and other giga-projects are creating substantial opportunities for strategic acquisitions and partnerships."
          },
          {
            title: "Regulatory Environment",
            content: "Recent regulatory reforms have streamlined the M&A process, with the Saudi Arabian General Investment Authority (SAGIA) implementing new guidelines that reduce transaction timelines by an average of 30%."
          },
          {
            title: "Strategic Considerations",
            content: "Successful M&A transactions in Saudi Arabia require deep understanding of local market dynamics, cultural considerations, and regulatory requirements. Due diligence processes must account for Sharia compliance and ESG factors."
          }
        ],
        conclusion: "The Saudi M&A landscape presents significant opportunities for both local and international investors. Success requires strategic planning, local expertise, and comprehensive understanding of the evolving regulatory environment."
      }
    },
    {
      id: 2,
      title: "REIT Investment Strategies for 2025",
      category: "Real Estate",
      excerpt: "Comprehensive guide to Real Estate Investment Trust opportunities in the Kingdom, covering regulatory framework, market dynamics, and portfolio optimization strategies.",
      image: "/api/placeholder/400/250",
      date: "2024-12-10",
      readTime: "6 min read",
      author: "Sarah Al-Mahmoud",
      authorTitle: "Director, Real Estate Advisory",
      fullContent: {
        introduction: "Real Estate Investment Trusts (REITs) in Saudi Arabia are poised for significant growth in 2025, offering investors diversified exposure to the Kingdom's expanding real estate market.",
        sections: [
          {
            title: "Market Landscape",
            content: "The Saudi REIT market has grown to over SAR 15 billion in assets under management, with new listings expected to double this figure by 2025. Government initiatives are driving institutional and retail investor participation."
          },
          {
            title: "Investment Opportunities",
            content: "Commercial real estate, logistics, and healthcare REITs present the most compelling opportunities, with projected returns of 8-12% annually. The retail sector recovery is also creating value opportunities."
          },
          {
            title: "Regulatory Framework",
            content: "The Capital Market Authority has introduced new regulations enhancing REIT governance and transparency, making the sector more attractive to international investors."
          }
        ],
        conclusion: "2025 represents a pivotal year for Saudi REITs, with strong fundamentals supporting continued growth and attractive investment opportunities across multiple sectors."
      }
    },
    {
      id: 3,
      title: "Risk Management in Middle East Markets",
      category: "Risk Management",
      excerpt: "Essential risk assessment frameworks for businesses operating in volatile Middle Eastern markets, including geopolitical, currency, and operational considerations.",
      image: "/api/placeholder/400/250",
      date: "2024-12-05",
      readTime: "7 min read",
      author: "Mohammed Al-Fahad",
      authorTitle: "Head of Risk Advisory",
      fullContent: {
        introduction: "Operating in Middle East markets requires sophisticated risk management approaches that account for unique regional dynamics, geopolitical factors, and economic volatility.",
        sections: [
          {
            title: "Geopolitical Risk Assessment",
            content: "Regional tensions and policy changes can significantly impact business operations. Our framework provides early warning systems and scenario planning tools for effective risk mitigation."
          },
          {
            title: "Currency and Financial Risk",
            content: "Oil price volatility and currency fluctuations create complex financial risks. Hedging strategies and diversification approaches help minimize exposure while maintaining growth opportunities."
          },
          {
            title: "Operational Risk Management",
            content: "Supply chain disruptions, regulatory changes, and workforce challenges require comprehensive operational risk frameworks tailored to regional conditions."
          }
        ],
        conclusion: "Effective risk management in Middle East markets requires local expertise, comprehensive frameworks, and adaptive strategies that evolve with changing conditions."
      }
    },
    {
      id: 4,
      title: "IPO Strategies for Emerging Markets",
      category: "Finance",
      excerpt: "Strategic approaches to public listings in emerging markets, with focus on regulatory compliance, investor relations, and market timing considerations.",
      image: "/api/placeholder/400/250",
      date: "2024-11-28",
      readTime: "9 min read",
      author: "Fatima Al-Zahra",
      authorTitle: "Partner, Capital Markets",
      fullContent: {
        introduction: "Emerging markets offer attractive IPO opportunities, but success requires careful planning, strategic timing, and comprehensive understanding of local market dynamics.",
        sections: [
          {
            title: "Market Timing and Conditions",
            content: "Successful IPOs in emerging markets require optimal timing aligned with market conditions, economic cycles, and investor sentiment. Our analysis identifies windows of opportunity for maximum impact."
          },
          {
            title: "Regulatory Compliance",
            content: "Each market has unique regulatory requirements. Our comprehensive approach ensures full compliance while optimizing the listing process for efficiency and cost-effectiveness."
          },
          {
            title: "Investor Relations Strategy",
            content: "Building investor confidence requires transparent communication, strong governance, and compelling value propositions. Our investor relations framework drives successful capital raising."
          }
        ],
        conclusion: "Emerging market IPOs present significant opportunities for growth-oriented companies with the right strategic approach and local expertise."
      }
    },
    {
      id: 5,
      title: "Digital Transformation in Financial Services",
      category: "Finance",
      excerpt: "How fintech innovations are reshaping traditional advisory services and what it means for client engagement and service delivery in the digital age.",
      image: "/api/placeholder/400/250",
      date: "2024-11-20",
      readTime: "5 min read",
      author: "Dr. Khalid Al-Subhi",
      authorTitle: "Technology Advisory Lead",
      fullContent: {
        introduction: "Digital transformation is revolutionizing financial services, creating new opportunities for enhanced client engagement and service delivery while maintaining the human touch that defines professional advisory.",
        sections: [
          {
            title: "Technology Integration",
            content: "AI-powered analytics, blockchain technologies, and cloud-based platforms are transforming traditional advisory services, enabling real-time insights and enhanced decision-making capabilities."
          },
          {
            title: "Client Experience Evolution",
            content: "Digital channels are creating new touchpoints for client interaction, from virtual consultations to mobile-first reporting, while maintaining the personalized service that clients expect."
          },
          {
            title: "Operational Efficiency",
            content: "Automation and digital workflows are streamlining operations, reducing costs, and improving accuracy while freeing professionals to focus on high-value advisory activities."
          }
        ],
        conclusion: "Digital transformation enhances rather than replaces human expertise, creating opportunities for more effective client service and business growth."
      }
    },
    {
      id: 6,
      title: "Sustainable Finance Trends in GCC",
      category: "ESG",
      excerpt: "Environmental, Social, and Governance considerations driving investment decisions across Gulf Cooperation Council countries and their impact on capital markets.",
      image: "/api/placeholder/400/250",
      date: "2024-11-15",
      readTime: "6 min read",
      author: "Layla Al-Mansouri",
      authorTitle: "ESG Advisory Director",
      fullContent: {
        introduction: "Sustainable finance is gaining momentum across GCC markets, driven by regulatory requirements, investor demands, and strategic economic diversification goals.",
        sections: [
          {
            title: "Regional ESG Landscape",
            content: "GCC countries are implementing comprehensive ESG frameworks, with Saudi Arabia leading through Vision 2030 and the UAE advancing through the Dubai 2071 plan. These initiatives are reshaping investment criteria."
          },
          {
            title: "Investment Impact",
            content: "ESG-compliant investments are outperforming traditional investments by 12-15% annually, with green bonds and sustainable funds attracting significant institutional capital."
          },
          {
            title: "Regulatory Development",
            content: "New regulations require enhanced ESG reporting and compliance, creating opportunities for advisory services and sustainable finance products."
          }
        ],
        conclusion: "Sustainable finance represents a fundamental shift in GCC markets, offering significant opportunities for investors and businesses aligned with ESG principles."
      }
    }
  ];

  const openCaseStudyModal = (caseStudy: any) => {
    setSelectedCaseStudy(caseStudy);
    setSelectedBlogPost(null);
    setIsModalOpen(true);
  };

  const openBlogModal = (blogPost: any) => {
    setSelectedBlogPost(blogPost);
    setSelectedCaseStudy(null);
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setSelectedCaseStudy(null);
    setSelectedBlogPost(null);
  };

  const categories = ["All", "M&A", "Real Estate", "Finance", "Manufacturing", "Infrastructure", "ESG"];
  const years = ["2023", "2024", "2025"];
  const services = ["M&A", "Valuation", "Bid Advisory", "Fund Raising", "Financial Modeling"];

  return (
    <div className="min-h-screen bg-white dark:bg-[#1D1D1B]">
      <Navbar />
      
      {/* Hero Section */}
      <section className="pt-32 pb-16 hero-gradient">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-5xl lg:text-6xl font-bold text-white mb-6">
              INSIGHTS & CASE STUDIES
            </h1>
            <div className="w-24 h-1 bg-[#FBBA00] mx-auto mb-8"></div>
            <p className="text-xl text-gray-200 leading-relaxed">
              Explore our successful projects and industry insights with detailed case studies and thought leadership
            </p>
          </div>
        </div>
      </section>

      {/* Case Studies Infographic Section */}
      <section className="py-20 bg-white dark:bg-[#1D1D1B]">
        <div className="container mx-auto px-4">
          <div className="max-w-7xl mx-auto">
            <div className="text-center mb-16">
              <h2 className="text-4xl lg:text-5xl font-bold text-[#005A77] dark:text-white mb-6">CASE STUDIES</h2>
              <div className="w-24 h-1 bg-[#FBBA00] mx-auto mb-8"></div>
              <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
                Detailed case studies showcasing our expertise across industries
              </p>
            </div>

            {/* Case Studies Table/Infographic */}
            <div className="bg-gradient-to-br from-[#005A77] to-[#0093A7] rounded-3xl p-8 mb-16 shadow-2xl">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-white/20">
                      <th className="text-left py-6 px-4 text-white font-bold text-lg">Case Study</th>
                      <th className="text-left py-6 px-4 text-white font-bold text-lg">Objective</th>
                      <th className="text-left py-6 px-4 text-white font-bold text-lg">Approach</th>
                      <th className="text-left py-6 px-4 text-white font-bold text-lg">Outcome</th>
                    </tr>
                  </thead>
                  <tbody>
                    {caseStudies.map((study, index) => (
                      <tr key={study.id} className="border-b border-white/10 hover:bg-white/5 transition-colors">
                        <td className="py-6 px-4">
                          <div className="flex items-start space-x-3">
                            <div className="w-12 h-12 bg-[#FBBA00] rounded-full flex items-center justify-center flex-shrink-0">
                              {study.icon}
                            </div>
                            <div>
                              <h3 className="text-white font-semibold text-lg leading-tight mb-2">
                                {study.title}
                              </h3>
                              <div className="flex flex-wrap gap-2">
                                <Badge className="bg-[#FBBA00] text-[#005A77] text-xs">
                                  {study.category}
                                </Badge>
                                <Badge variant="outline" className="border-white/30 text-white text-xs">
                                  {study.year}
                                </Badge>
                              </div>
                            </div>
                          </div>
                        </td>
                        <td className="py-6 px-4">
                          <p className="text-gray-200 text-sm leading-relaxed">
                            {study.objective}
                          </p>
                        </td>
                        <td className="py-6 px-4">
                          <p className="text-gray-200 text-sm leading-relaxed">
                            {study.approach}
                          </p>
                        </td>
                        <td className="py-6 px-4">
                          <div className="space-y-2">
                            <p className="text-gray-200 text-sm leading-relaxed">
                              {study.outcome}
                            </p>
                            <div className="bg-[#FBBA00]/20 rounded-lg p-2 border border-[#FBBA00]/30">
                              <span className="text-[#FBBA00] font-bold text-sm">
                                {study.stats}
                              </span>
                            </div>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Individual Case Study Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {caseStudies.map((caseStudy, index) => (
                <Card key={caseStudy.id} className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 group hover:-translate-y-2 overflow-hidden">
                  {/* Thumbnail */}
                  <div className="relative h-48 bg-gradient-to-br from-[#005A77] to-[#0093A7] flex items-center justify-center">
                    <div className="text-white text-6xl opacity-20">
                      {caseStudy.icon}
                    </div>
                    <div className="absolute top-4 left-4">
                      <Badge className="bg-[#FBBA00] text-[#005A77]">{caseStudy.category}</Badge>
                    </div>
                    <div className="absolute top-4 right-4">
                      <Badge variant="outline" className="bg-white/90 text-[#005A77]">{caseStudy.year}</Badge>
                    </div>
                  </div>
                  
                  <CardHeader>
                    <CardTitle className="text-[#005A77] group-hover:text-[#FBBA00] transition-colors line-clamp-2">
                      {caseStudy.title}
                    </CardTitle>
                    <CardDescription className="text-gray-600">
                      <span className="font-semibold">Industry:</span> {caseStudy.industry}
                    </CardDescription>
                  </CardHeader>
                  
                  <CardContent>
                    <div className="space-y-4 mb-6">
                      <div>
                        <span className="text-sm font-semibold text-[#005A77]">Objective:</span>
                        <p className="text-sm text-gray-600 mt-1">{caseStudy.objective}</p>
                      </div>
                      <div>
                        <span className="text-sm font-semibold text-[#005A77]">Approach:</span>
                        <p className="text-sm text-gray-600 mt-1">{caseStudy.approach}</p>
                      </div>
                      <div>
                        <span className="text-sm font-semibold text-[#005A77]">Outcome:</span>
                        <p className="text-sm text-gray-600 mt-1">{caseStudy.outcome}</p>
                      </div>
                      <div className="bg-[#FBBA00]/10 rounded-lg p-3">
                        <span className="text-sm font-semibold text-[#005A77]">Key Result:</span>
                        <p className="text-sm text-[#005A77] font-bold mt-1">{caseStudy.stats}</p>
                      </div>
                    </div>
                    
                    <Button 
                      variant="outline" 
                      className="w-full text-[#FBBA00] border-[#FBBA00] hover:bg-[#FBBA00] hover:text-white transition-all duration-300"
                      onClick={() => openCaseStudyModal(caseStudy)}
                    >
                      Read More
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Blog / Insights Section */}
      <section className="py-20 section-bg">
        <div className="container mx-auto px-4">
          <div className="max-w-7xl mx-auto">
            <div className="text-center mb-16">
              <h2 className="text-4xl lg:text-5xl font-bold text-[#005A77] mb-6">BLOG & INSIGHTS</h2>
              <div className="w-24 h-1 bg-[#FBBA00] mx-auto mb-8"></div>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                Industry expertise and strategic thinking from our professional team
              </p>
            </div>

            {/* Featured Article */}
            <div className="mb-16">
              <Card className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 overflow-hidden">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-0">
                  <div className="relative h-64 lg:h-auto bg-gradient-to-br from-[#005A77] to-[#0093A7] flex items-center justify-center">
                    <div className="text-white text-8xl opacity-20">
                      <BookOpen />
                    </div>
                    <div className="absolute top-4 left-4">
                      <Badge className="bg-[#FBBA00] text-[#005A77]">Featured</Badge>
                    </div>
                  </div>
                  <div className="p-8">
                    <div className="flex items-center space-x-4 mb-4">
                      <Badge variant="outline" className="text-[#005A77] border-[#005A77]">{blogPosts[0].category}</Badge>
                      <span className="text-sm text-gray-500">{blogPosts[0].date}</span>
                      <span className="text-sm text-gray-500">{blogPosts[0].readTime}</span>
                    </div>
                    <h3 className="text-3xl font-bold text-[#005A77] mb-4">{blogPosts[0].title}</h3>
                    <p className="text-gray-600 text-lg leading-relaxed mb-6">{blogPosts[0].excerpt}</p>
                    <Button 
                      className="bg-[#005A77] hover:bg-[#0093A7] text-white"
                      onClick={() => openBlogModal(blogPosts[0])}
                    >
                      Read Article
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </Card>
            </div>

            {/* Blog Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {blogPosts.slice(1).map((post, index) => (
                <Card key={post.id} className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 group hover:-translate-y-2 overflow-hidden">
                  <div className="relative h-48 bg-gradient-to-br from-[#005A77] to-[#0093A7] flex items-center justify-center">
                    <div className="text-white text-6xl opacity-20">
                      <FileText />
                    </div>
                    <div className="absolute top-4 left-4">
                      <Badge className="bg-[#FBBA00] text-[#005A77]">{post.category}</Badge>
                    </div>
                  </div>
                  
                  <CardHeader>
                    <div className="flex items-center space-x-2 text-sm text-gray-500 mb-2">
                      <Calendar className="w-4 h-4" />
                      <span>{post.date}</span>
                      <span>•</span>
                      <span>{post.readTime}</span>
                    </div>
                    <CardTitle className="text-[#005A77] group-hover:text-[#FBBA00] transition-colors line-clamp-2">
                      {post.title}
                    </CardTitle>
                  </CardHeader>
                  
                  <CardContent>
                    <p className="text-gray-600 text-sm mb-6 line-clamp-3">{post.excerpt}</p>
                    <Button 
                      variant="outline" 
                      className="w-full text-[#FBBA00] border-[#FBBA00] hover:bg-[#FBBA00] hover:text-white transition-all duration-300"
                      onClick={() => openBlogModal(post)}
                    >
                      Read More
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* View All Button */}
            <div className="text-center mt-12">
              <Button size="lg" className="bg-[#005A77] hover:bg-[#0093A7] text-white px-8 py-3 text-lg font-semibold rounded-full">
                View All Articles
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Modal for Case Studies and Blog Posts */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50">
          <div className="relative bg-white dark:bg-[#1D1D1B] rounded-lg shadow-xl max-w-4xl w-full mx-4 max-h-[90vh] overflow-y-auto">
            {/* Close Button */}
            <button
              onClick={closeModal}
              className="absolute top-4 right-4 z-10 p-2 bg-white/10 hover:bg-white/20 rounded-full transition-colors"
            >
              <X className="w-6 h-6 text-gray-600" />
            </button>

            {/* Case Study Modal Content */}
            {selectedCaseStudy && (
              <div className="p-8">
                {/* Header */}
                <div className="mb-8">
                  <div className="flex items-center space-x-4 mb-4">
                    <div className="w-16 h-16 bg-gradient-to-br from-[#005A77] to-[#0093A7] rounded-full flex items-center justify-center">
                      <div className="text-white text-2xl">
                        {selectedCaseStudy.icon}
                      </div>
                    </div>
                    <div>
                      <h1 className="text-3xl font-bold text-[#005A77] mb-2">{selectedCaseStudy.title}</h1>
                      <div className="flex flex-wrap gap-2">
                        <Badge className="bg-[#FBBA00] text-[#005A77]">{selectedCaseStudy.category}</Badge>
                        <Badge variant="outline" className="text-[#005A77] border-[#005A77]">{selectedCaseStudy.year}</Badge>
                        <Badge variant="outline" className="text-[#005A77] border-[#005A77]">{selectedCaseStudy.service}</Badge>
                      </div>
                    </div>
                  </div>
                  
                  {/* Project Details */}
                  <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4 mb-8">
                    <div className="bg-gray-50 p-4 rounded-lg">
                      <div className="flex items-center space-x-2 mb-2">
                        <Briefcase className="w-4 h-4 text-[#005A77]" />
                        <span className="text-sm font-semibold text-[#005A77]">Client</span>
                      </div>
                      <p className="text-sm text-gray-600">{selectedCaseStudy.client}</p>
                    </div>
                    <div className="bg-gray-50 p-4 rounded-lg">
                      <div className="flex items-center space-x-2 mb-2">
                        <Clock className="w-4 h-4 text-[#005A77]" />
                        <span className="text-sm font-semibold text-[#005A77]">Duration</span>
                      </div>
                      <p className="text-sm text-gray-600">{selectedCaseStudy.duration}</p>
                    </div>
                    <div className="bg-gray-50 p-4 rounded-lg">
                      <div className="flex items-center space-x-2 mb-2">
                        <MapPin className="w-4 h-4 text-[#005A77]" />
                        <span className="text-sm font-semibold text-[#005A77]">Location</span>
                      </div>
                      <p className="text-sm text-gray-600">{selectedCaseStudy.location}</p>
                    </div>
                    <div className="bg-gray-50 p-4 rounded-lg">
                      <div className="flex items-center space-x-2 mb-2">
                        <DollarSign className="w-4 h-4 text-[#005A77]" />
                        <span className="text-sm font-semibold text-[#005A77]">Value</span>
                      </div>
                      <p className="text-sm text-gray-600">{selectedCaseStudy.projectValue}</p>
                    </div>
                    <div className="bg-gray-50 p-4 rounded-lg">
                      <div className="flex items-center space-x-2 mb-2">
                        <Users className="w-4 h-4 text-[#005A77]" />
                        <span className="text-sm font-semibold text-[#005A77]">Team Size</span>
                      </div>
                      <p className="text-sm text-gray-600">{selectedCaseStudy.teamSize}</p>
                    </div>
                  </div>
                </div>

                {/* Content Sections */}
                <div className="space-y-8">
                  {/* Challenges */}
                  <div>
                    <h3 className="text-xl font-bold text-[#005A77] mb-4">Challenges</h3>
                    <ul className="space-y-2">
                      {selectedCaseStudy.challenges.map((challenge: string, index: number) => (
                        <li key={index} className="flex items-start space-x-2">
                          <div className="w-2 h-2 bg-[#FBBA00] rounded-full mt-2"></div>
                          <span className="text-gray-600">{challenge}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Detailed Approach */}
                  <div>
                    <h3 className="text-xl font-bold text-[#005A77] mb-4">Our Approach</h3>
                    <ul className="space-y-2">
                      {selectedCaseStudy.detailedApproach.map((approach: string, index: number) => (
                        <li key={index} className="flex items-start space-x-2">
                          <div className="w-2 h-2 bg-[#005A77] rounded-full mt-2"></div>
                          <span className="text-gray-600">{approach}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Results */}
                  <div>
                    <h3 className="text-xl font-bold text-[#005A77] mb-4">Results Achieved</h3>
                    <ul className="space-y-2">
                      {selectedCaseStudy.detailedOutcome.map((outcome: string, index: number) => (
                        <li key={index} className="flex items-start space-x-2">
                          <CheckCircle className="w-5 h-5 text-green-500 mt-0.5" />
                          <span className="text-gray-600">{outcome}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Key Metrics */}
                  <div>
                    <h3 className="text-xl font-bold text-[#005A77] mb-4">Key Metrics</h3>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      {selectedCaseStudy.keyMetrics.map((metric: any, index: number) => (
                        <div key={index} className="bg-gradient-to-br from-[#005A77] to-[#0093A7] p-4 rounded-lg text-center">
                          <div className="text-2xl font-bold text-white mb-1">{metric.value}</div>
                          <div className="text-sm text-gray-200">{metric.label}</div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Insights */}
                  <div className="bg-[#FBBA00]/10 p-6 rounded-lg border border-[#FBBA00]/20">
                    <h3 className="text-xl font-bold text-[#005A77] mb-4">Key Insights</h3>
                    <p className="text-gray-600 leading-relaxed">{selectedCaseStudy.insights}</p>
                  </div>
                </div>
              </div>
            )}

            {/* Blog Post Modal Content */}
            {selectedBlogPost && (
              <div className="p-8">
                {/* Header */}
                <div className="mb-8">
                  <div className="flex items-center space-x-4 mb-4">
                    <Badge className="bg-[#FBBA00] text-[#005A77]">{selectedBlogPost.category}</Badge>
                    <span className="text-sm text-gray-500">{selectedBlogPost.date}</span>
                    <span className="text-sm text-gray-500">{selectedBlogPost.readTime}</span>
                  </div>
                  <h1 className="text-3xl font-bold text-[#005A77] mb-4">{selectedBlogPost.title}</h1>
                  <div className="flex items-center space-x-4">
                    <div className="w-12 h-12 bg-gradient-to-br from-[#005A77] to-[#0093A7] rounded-full flex items-center justify-center">
                      <span className="text-white font-bold text-sm">{selectedBlogPost.author.split(' ').map((n: string) => n[0]).join('')}</span>
                    </div>
                    <div>
                      <div className="font-semibold text-[#005A77]">{selectedBlogPost.author}</div>
                      <div className="text-sm text-gray-600">{selectedBlogPost.authorTitle}</div>
                    </div>
                  </div>
                </div>

                {/* Content */}
                <div className="space-y-6">
                  <div className="text-lg text-gray-700 leading-relaxed">
                    {selectedBlogPost.fullContent.introduction}
                  </div>

                  {selectedBlogPost.fullContent.sections.map((section: any, index: number) => (
                    <div key={index}>
                      <h3 className="text-xl font-bold text-[#005A77] mb-3">{section.title}</h3>
                      <p className="text-gray-600 leading-relaxed">{section.content}</p>
                    </div>
                  ))}

                  <div className="bg-[#005A77]/10 p-6 rounded-lg border border-[#005A77]/20">
                    <h3 className="text-xl font-bold text-[#005A77] mb-3">Conclusion</h3>
                    <p className="text-gray-600 leading-relaxed">{selectedBlogPost.fullContent.conclusion}</p>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Multi-Language Support */}
      <section className="py-16 bg-[#005A77] text-white">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h3 className="text-2xl font-bold mb-4">Available in Multiple Languages</h3>
            <p className="text-gray-200 mb-6">
              All case studies and insights are translated and available in:
            </p>
            <div className="flex justify-center space-x-6">
              <Badge className="bg-[#FBBA00] text-[#005A77] text-lg px-6 py-3">🇺🇸 English</Badge>
              <Badge className="bg-[#FBBA00] text-[#005A77] text-lg px-6 py-3">🇸🇦 العربية</Badge>
              <Badge className="bg-[#FBBA00] text-[#005A77] text-lg px-6 py-3">🇨🇳 中文</Badge>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-[#1D1D1B] text-white py-16">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="lg:col-span-2">
              <div className="flex items-center space-x-3 mb-6">
                <div className="w-10 h-10 bg-gradient-to-r from-[#005A77] to-[#FBBA00] rounded-full flex items-center justify-center">
                  <span className="text-white font-bold">PO</span>
                </div>
                <span className="text-2xl font-bold">Professional Opinion</span>
              </div>
              <p className="text-gray-300 mb-6 text-lg leading-relaxed max-w-md">
                Licensed financial and management advisory firm delivering strategic solutions across the Middle East and beyond.
              </p>
            </div>
            <div>
              <h3 className="text-xl font-semibold text-[#FBBA00] mb-6">Quick Links</h3>
              <ul className="space-y-3">
                <li><Link href="/about" className="text-gray-300 hover:text-[#FBBA00] transition-colors">About</Link></li>
                <li><Link href="/services" className="text-gray-300 hover:text-[#FBBA00] transition-colors">Services</Link></li>
                <li><Link href="/team" className="text-gray-300 hover:text-[#FBBA00] transition-colors">Team</Link></li>
                <li><Link href="/insights" className="text-gray-300 hover:text-[#FBBA00] transition-colors">Insights</Link></li>
                <li><Link href="/contact" className="text-gray-300 hover:text-[#FBBA00] transition-colors">Contact</Link></li>
              </ul>
            </div>
            <div>
              <h3 className="text-xl font-semibold text-[#FBBA00] mb-6">Legal</h3>
              <ul className="space-y-3">
                <li><Link href="/terms" className="text-gray-300 hover:text-[#FBBA00] transition-colors">Terms & Conditions</Link></li>
                <li><Link href="/privacy" className="text-gray-300 hover:text-[#FBBA00] transition-colors">Privacy Policy</Link></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-700 mt-12 pt-8 text-center">
            <p className="text-gray-400">© 2025 Professional Opinion. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}