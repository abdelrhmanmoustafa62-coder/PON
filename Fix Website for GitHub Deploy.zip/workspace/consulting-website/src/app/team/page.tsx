import React from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowRight, Linkedin, Twitter, Mail, User, Award, Globe, Building, TrendingUp, Shield, Users, Target, BookOpen, CheckCircle } from "lucide-react";
import Link from "next/link";
import { Navbar } from "@/components/layout/navbar";

export default function TeamPage() {
  const teamMembers = [
    {
      id: 1,
      name: "Mr. Khalid Otain",
      title: "Managing Partner",
      qualifications: "CPA, CMA, CFE",
      experience: "29 years",
      image: "/api/placeholder/300/300",
      bio: "Managing Partner with CPA, CMA, and CFE certifications and 29 years of experience. Provides strategic leadership and serves as financial dispute arbitrator. Former Big 4 Senior Partner with extensive client portfolio.",
      specialties: ["Strategic Leadership", "Financial Disputes", "Client Relations", "Business Development"],
      linkedin: "#",
      twitter: "#",
      email: "khalid.otain@po.sa"
    },
    {
      id: 2,
      name: "Dr. Aamir Tahir",
      title: "Partner - Transaction Advisory & Governance",
      qualifications: "FCCA, CIA",
      experience: "25+ years",
      image: "/api/placeholder/300/300",
      bio: "Chartered Certified Accountant and Certified Internal Auditor with 25+ years of experience. Expertise in due diligence, valuation, governance, and strategic planning. Led numerous Big 4 consulting projects across multiple industries.",
      specialties: ["Due Diligence", "Valuation", "Corporate Governance", "Strategic Planning"],
      linkedin: "#",
      twitter: "#",
      email: "aamir.tahir@po.sa"
    },
    {
      id: 3,
      name: "Mr. Naveed Haider",
      title: "Tax Specialist & Cross-Border Transactions",
      qualifications: "FCA",
      experience: "29+ years",
      image: "/api/placeholder/300/300",
      bio: "Fellow Chartered Accountant with 29+ years of experience in taxation, zakat, and VAT for EPC, banking, and manufacturing sectors. Specializes in managing complex cross-border transactions and regulatory compliance.",
      specialties: ["Taxation", "Zakat & VAT", "Cross-Border Transactions", "Regulatory Compliance"],
      linkedin: "#",
      twitter: "#",
      email: "naveed.haider@po.sa"
    },
    {
      id: 4,
      name: "Mr. Saad Athar",
      title: "Financial Modeling & Governance Expert",
      qualifications: "CMA (PwC-trained)",
      experience: "25+ years",
      image: "/api/placeholder/300/300",
      bio: "PwC-trained CMA with 25+ years of experience in Sarbanes-Oxley implementation and financial modeling. Notable work with Saudi Downtown Company across 13 provinces, delivering comprehensive financial solutions.",
      specialties: ["Financial Modeling", "Sarbanes-Oxley", "Risk Management", "Regional Operations"],
      linkedin: "#",
      twitter: "#",
      email: "saad.athar@po.sa"
    },
    {
      id: 5,
      name: "Mr. Nadeem M Butt",
      title: "Corporate Governance & M&A Specialist",
      qualifications: "CA (PwC-trained)",
      experience: "30+ years",
      image: "/api/placeholder/300/300",
      bio: "PwC-trained CA with 30+ years of experience in governance, valuations, and M&A across finance, healthcare, and energy sectors. Led numerous high-profile restructuring projects and complex transactions.",
      specialties: ["Corporate Governance", "M&A Advisory", "Valuations", "Business Restructuring"],
      linkedin: "#",
      twitter: "#",
      email: "nadeem.butt@po.sa"
    },
    {
      id: 6,
      name: "Mr. Arslan Shahid",
      title: "Financial Analysis & Valuations Lead",
      qualifications: "CFA, FCCA",
      experience: "15+ years",
      image: "/api/placeholder/300/300",
      bio: "CFA and FCCA with 15+ years of experience in valuations, due diligence, and M&A advisory. PwC-trained professional ensuring compliant, value-adding transactions across diverse industry sectors.",
      specialties: ["Valuations", "Due Diligence", "M&A Advisory", "Financial Analysis"],
      linkedin: "#",
      twitter: "#",
      email: "arslan.shahid@po.sa"
    },
    {
      id: 7,
      name: "Mr. Salman Ahson",
      title: "Management Consulting & Process Engineering",
      qualifications: "PwC/EY-trained",
      experience: "19+ years",
      image: "/api/placeholder/300/300",
      bio: "19+ years of experience with PwC and EY training in finance, audit, tax, and process re-engineering across retail, oil & gas, and technology sectors. Manages complex multi-disciplinary projects.",
      specialties: ["Management Consulting", "Process Re-engineering", "Multi-sector Experience", "Project Management"],
      linkedin: "#",
      twitter: "#",
      email: "salman.ahson@po.sa"
    },
    {
      id: 8,
      name: "Mr. Muhammad Kamran",
      title: "Risk Management & Financial Institutions",
      qualifications: "CFA",
      experience: "12+ years",
      image: "/api/placeholder/300/300",
      bio: "CFA with 12+ years of experience in risk management and valuations for financial institutions and energy sector. Develops comprehensive internal control systems and risk mitigation strategies.",
      specialties: ["Risk Management", "Valuations", "Financial Institutions", "Internal Controls"],
      linkedin: "#",
      twitter: "#",
      email: "muhammad.kamran@po.sa"
    },
    {
      id: 9,
      name: "Mr. Sharan Arshad",
      title: "Risk & Performance Consultant",
      qualifications: "Risk Management Specialist",
      experience: "10+ years",
      image: "/api/placeholder/300/300",
      bio: "10+ years as a risk and performance consultant, optimizing processes and strengthening governance frameworks across multiple industries. Specializes in performance improvement and risk mitigation.",
      specialties: ["Risk Consulting", "Performance Optimization", "Process Improvement", "Governance"],
      linkedin: "#",
      twitter: "#",
      email: "sharan.arshad@po.sa"
    },
    {
      id: 10,
      name: "Mr. Wasif Ali Rana",
      title: "Governance & Ethics Consulting",
      qualifications: "FCCA, CPA (PwC-trained)",
      experience: "14+ years",
      image: "/api/placeholder/300/300",
      bio: "PwC-trained FCCA and CPA with 14+ years of experience in governance and ethics consulting. Develops comprehensive conflict of interest policies and ethical compliance frameworks.",
      specialties: ["Governance", "Ethics Consulting", "Compliance", "Policy Development"],
      linkedin: "#",
      twitter: "#",
      email: "wasif.rana@po.sa"
    },
    {
      id: 11,
      name: "Mr. Istafa Baqar Zaidi",
      title: "Financial Advisory & Valuations",
      qualifications: "FCCA",
      experience: "10+ years",
      image: "/api/placeholder/300/300",
      bio: "FCCA with 10+ years of experience in valuations and due diligence across technology, healthcare, and real estate sectors. Identifies key value drivers and mitigates investment risks.",
      specialties: ["Valuations", "Due Diligence", "Value Engineering", "Risk Mitigation"],
      linkedin: "#",
      twitter: "#",
      email: "istafa.zaidi@po.sa"
    }
  ];

  return (
    <div className="min-h-screen bg-white dark:bg-[#1D1D1B]">
      <Navbar />
      
      {/* Hero Section */}
      <section className="pt-32 pb-16 hero-gradient">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-5xl lg:text-6xl font-bold text-white mb-6">
              OUR EXPERT TEAM
            </h1>
            <div className="w-24 h-1 bg-[#FBBA00] mx-auto mb-8"></div>
            <p className="text-xl text-gray-200 leading-relaxed">
              11 key team members with expanded bios, 3D hover effects, and professional expertise
            </p>
          </div>
        </div>
      </section>

      {/* Team Members Section */}
      <section className="py-20 bg-white dark:bg-[#1D1D1B]">
        <div className="container mx-auto px-4">
          <div className="max-w-7xl mx-auto">
            
            {/* Team Introduction */}
            <div className="text-center mb-16">
              <h2 className="text-4xl lg:text-5xl font-bold text-[#005A77] dark:text-white mb-6">LEADERSHIP TEAM</h2>
              <div className="w-24 h-1 bg-[#FBBA00] mx-auto mb-8"></div>
              <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
                Industry leaders dedicated to your success with decades of combined experience
              </p>
            </div>

            {/* Team Grid - 3 columns desktop, 1 column mobile */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {teamMembers.map((member, index) => (
                <Card key={member.id} className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 group hover:-translate-y-2 overflow-hidden">
                  {/* Professional Photo with 3D Hover Effect */}
                  <div className="relative h-64 bg-gradient-to-br from-[#005A77] to-[#0093A7] flex items-center justify-center group-hover:scale-105 transition-transform duration-300">
                    <div className="w-32 h-32 bg-white/20 rounded-full flex items-center justify-center group-hover:bg-white/30 transition-colors duration-300">
                      <User className="w-16 h-16 text-white" />
                    </div>
                    <div className="absolute top-4 right-4">
                      <Badge className="bg-[#FBBA00] text-[#005A77] px-3 py-1">
                        {member.experience}
                      </Badge>
                    </div>
                  </div>

                  <CardHeader>
                    <CardTitle className="text-[#005A77] group-hover:text-[#FBBA00] transition-colors text-lg">
                      {member.name}
                    </CardTitle>
                    <CardDescription className="text-gray-600 font-medium">
                      {member.title}
                    </CardDescription>
                    <div className="flex items-center space-x-2 mt-2">
                      <Badge variant="outline" className="text-xs">{member.qualifications}</Badge>
                      <Badge variant="outline" className="text-xs">{member.experience}</Badge>
                    </div>
                  </CardHeader>

                  <CardContent>
                    {/* Bio */}
                    <div className="mb-4">
                      <p className="text-gray-600 text-sm leading-relaxed line-clamp-4">
                        {member.bio}
                      </p>
                    </div>

                    {/* Specialties */}
                    <div className="mb-6">
                      <h4 className="text-sm font-semibold text-[#005A77] mb-2">Specialties:</h4>
                      <div className="flex flex-wrap gap-1">
                        {member.specialties.map((specialty, idx) => (
                          <Badge key={idx} variant="secondary" className="text-xs bg-[#FBBA00]/10 text-[#005A77]">
                            {specialty}
                          </Badge>
                        ))}
                      </div>
                    </div>

                    {/* Social Links */}
                    <div className="flex items-center space-x-3 pt-4 border-t">
                      <a href={member.linkedin} className="text-gray-400 hover:text-[#005A77] transition-colors">
                        <Linkedin className="w-5 h-5" />
                      </a>
                      <a href={member.twitter} className="text-gray-400 hover:text-[#005A77] transition-colors">
                        <Twitter className="w-5 h-5" />
                      </a>
                      <a href={`mailto:${member.email}`} className="text-gray-400 hover:text-[#005A77] transition-colors">
                        <Mail className="w-5 h-5" />
                      </a>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Team Strengths */}
            <div className="mt-20">
              <div className="text-center mb-12">
                <h3 className="text-3xl font-bold text-[#005A77] dark:text-white mb-6">OUR COLLECTIVE STRENGTH</h3>
                <div className="w-24 h-1 bg-[#FBBA00] mx-auto mb-8"></div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                <Card className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 group hover:-translate-y-2 text-center">
                  <CardHeader>
                    <div className="w-16 h-16 bg-[#005A77] rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-[#FBBA00] group-hover:scale-110 transition-all duration-300">
                      <Award className="w-8 h-8 text-white" />
                    </div>
                    <CardTitle className="text-[#005A77] group-hover:text-[#FBBA00] transition-colors">Diverse Expertise</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-600 text-sm">
                      Combined experience across finance, governance, risk management, and strategic advisory.
                    </p>
                  </CardContent>
                </Card>

                <Card className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 group hover:-translate-y-2 text-center">
                  <CardHeader>
                    <div className="w-16 h-16 bg-[#005A77] rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-[#FBBA00] group-hover:scale-110 transition-all duration-300">
                      <Globe className="w-8 h-8 text-white" />
                    </div>
                    <CardTitle className="text-[#005A77] group-hover:text-[#FBBA00] transition-colors">Global Standards</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-600 text-sm">
                      Big 4 trained professionals with international certifications and local market expertise.
                    </p>
                  </CardContent>
                </Card>

                <Card className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 group hover:-translate-y-2 text-center">
                  <CardHeader>
                    <div className="w-16 h-16 bg-[#005A77] rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-[#FBBA00] group-hover:scale-110 transition-all duration-300">
                      <TrendingUp className="w-8 h-8 text-white" />
                    </div>
                    <CardTitle className="text-[#005A77] group-hover:text-[#FBBA00] transition-colors">Proven Track Record</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-600 text-sm">
                      Successful delivery of complex projects across multiple industries and geographic regions.
                    </p>
                  </CardContent>
                </Card>

                <Card className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 group hover:-translate-y-2 text-center">
                  <CardHeader>
                    <div className="w-16 h-16 bg-[#005A77] rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-[#FBBA00] group-hover:scale-110 transition-all duration-300">
                      <Users className="w-8 h-8 text-white" />
                    </div>
                    <CardTitle className="text-[#005A77] group-hover:text-[#FBBA00] transition-colors">Client-Centric Approach</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-600 text-sm">
                      Collaborative team approach ensuring tailored solutions and exceptional client service.
                    </p>
                  </CardContent>
                </Card>
              </div>
            </div>

            {/* Multi-Language Support */}
            <div className="mt-16">
              <div className="bg-[#005A77] text-white rounded-lg p-8 text-center">
                <h3 className="text-2xl font-bold mb-4">Multi-Language Communication</h3>
                <p className="text-gray-200 mb-6">
                  Our team provides professional services and communications in multiple languages:
                </p>
                <div className="flex justify-center space-x-4">
                  <Badge className="bg-[#FBBA00] text-[#005A77] text-lg px-6 py-3">🇺🇸 English</Badge>
                  <Badge className="bg-[#FBBA00] text-[#005A77] text-lg px-6 py-3">🇸🇦 العربية</Badge>
                  <Badge className="bg-[#FBBA00] text-[#005A77] text-lg px-6 py-3">🇨🇳 中文</Badge>
                </div>
              </div>
            </div>

            {/* CTA Section */}
            <div className="text-center mt-16">
              <h3 className="text-3xl font-bold text-[#005A77] dark:text-white mb-6">
                Ready to Work with Our Expert Team?
              </h3>
              <p className="text-xl text-gray-600 dark:text-gray-300 mb-8 max-w-2xl mx-auto">
                Connect with our professionals to discuss your specific needs and discover how our expertise can drive your success.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button asChild size="lg" className="bg-[#005A77] hover:bg-[#0093A7] text-white px-8 py-3 text-lg font-semibold rounded-full">
                  <Link href="/contact">
                    Schedule Meeting
                    <ArrowRight className="ml-2 h-5 w-5" />
                  </Link>
                </Button>
                <Button asChild size="lg" variant="outline" className="border-[#005A77] text-[#005A77] hover:bg-[#005A77] hover:text-white px-8 py-3 text-lg font-semibold rounded-full">
                  <Link href="/services">
                    Our Services
                  </Link>
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-[#1D1D1B] text-white py-16">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="lg:col-span-2">
              <div className="flex items-center space-x-3 mb-6">
                <div className="w-10 h-10 bg-gradient-to-r from-[#005A77] to-[#FBBA00] rounded-full flex items-center justify-center">
                  <span className="text-white font-bold">PO</span>
                </div>
                <span className="text-2xl font-bold">Professional Opinion</span>
              </div>
              <p className="text-gray-300 mb-6 text-lg leading-relaxed max-w-md">
                Licensed financial and management advisory firm delivering strategic solutions across the Middle East and beyond.
              </p>
            </div>
            <div>
              <h3 className="text-xl font-semibold text-[#FBBA00] mb-6">Quick Links</h3>
              <ul className="space-y-3">
                <li><Link href="/about" className="text-gray-300 hover:text-[#FBBA00] transition-colors">About</Link></li>
                <li><Link href="/services" className="text-gray-300 hover:text-[#FBBA00] transition-colors">Services</Link></li>
                <li><Link href="/team" className="text-gray-300 hover:text-[#FBBA00] transition-colors">Team</Link></li>
                <li><Link href="/insights" className="text-gray-300 hover:text-[#FBBA00] transition-colors">Insights</Link></li>
                <li><Link href="/contact" className="text-gray-300 hover:text-[#FBBA00] transition-colors">Contact</Link></li>
              </ul>
            </div>
            <div>
              <h3 className="text-xl font-semibold text-[#FBBA00] mb-6">Legal</h3>
              <ul className="space-y-3">
                <li><Link href="/terms" className="text-gray-300 hover:text-[#FBBA00] transition-colors">Terms & Conditions</Link></li>
                <li><Link href="/privacy" className="text-gray-300 hover:text-[#FBBA00] transition-colors">Privacy Policy</Link></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-700 mt-12 pt-8 text-center">
            <p className="text-gray-400">© 2025 Professional Opinion. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}