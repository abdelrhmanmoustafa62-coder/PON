import React from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { AOSInitializer } from "@/components/ui/aos-init";
import { ArrowRight, Building, Globe, TrendingUp, Shield, Users, Award, Star, CheckCircle, Target, Eye, Heart } from "lucide-react";
import Link from "next/link";

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-white">
      <AOSInitializer />

      {/* Navigation - Same as homepage */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-white/95 backdrop-blur-md shadow-lg border-b border-gray-200/20">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-gradient-to-r from-[#1e293b] to-[#f59e0b] rounded-full flex items-center justify-center">
                <span className="text-white font-bold text-sm">PO</span>
              </div>
              <span className="text-xl font-bold text-[#1e293b]">Professional Opinion</span>
            </div>

            <div className="hidden lg:flex items-center space-x-8">
              <Link href="/" className="text-gray-700 hover:text-[#1e293b] transition-colors font-medium">Home</Link>
              <Link href="/about" className="text-[#f59e0b] font-semibold">About</Link>
              <Link href="/services" className="text-gray-700 hover:text-[#1e293b] transition-colors font-medium">Services</Link>
              <Link href="/team" className="text-gray-700 hover:text-[#1e293b] transition-colors font-medium">Team</Link>
              <Link href="/insights" className="text-gray-700 hover:text-[#1e293b] transition-colors font-medium">Insights</Link>
              <Link href="/contact" className="text-gray-700 hover:text-[#1e293b] transition-colors font-medium">Contact</Link>
            </div>

            <div className="hidden lg:flex items-center space-x-4">
              <select className="text-sm border border-gray-300 rounded-md px-3 py-2">
                <option value="en">🇺🇸 English</option>
                <option value="ar">🇸🇦 العربية</option>
                <option value="zh">🇨🇳 中文</option>
              </select>
              <Button className="bg-[#f59e0b] hover:bg-[#d97706] text-white">
                Get Consultation
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="pt-24 pb-16 bg-gradient-to-br from-[#1e293b] via-[#334155] to-[#1e293b] text-white relative overflow-hidden">
        <div className="absolute inset-0 bg-black/20"></div>
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-4xl mx-auto text-center" data-aos="fade-up">
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold mb-6">About Professional Opinion</h1>
            <p className="text-xl sm:text-2xl text-gray-200 mb-8">
              Excellence in Strategic Consulting Since Establishment
            </p>
            <p className="text-lg text-gray-300 max-w-3xl mx-auto">
              Licensed financial and management advisory firm in Saudi Arabia, delivering professional and high-quality advisory services as an independent member of the HLB Global Advisory and Accountancy Network.
            </p>
          </div>
        </div>
        <div className="absolute bottom-0 left-0 right-0 h-24 bg-gradient-to-t from-[#f1f5f9] to-transparent"></div>
      </section>

      {/* Company Introduction */}
      <section className="py-20 bg-[#f1f5f9]">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center" data-aos="fade-up">
            <h2 className="text-4xl font-bold text-[#1e293b] mb-8">WHO WE ARE</h2>
            <div className="w-24 h-1 bg-[#f59e0b] mx-auto mb-8"></div>
            <p className="text-xl text-gray-600 leading-relaxed mb-8">
              We are a licensed financial and management advisory firm in Saudi Arabia, delivering professional and high-quality advisory services. As an independent member of the HLB Global Advisory and Accountancy Network, we provide comprehensive solutions in management consulting, business valuation, corporate governance, risk assessment, due diligence, and real estate advisory.
            </p>
            <p className="text-lg text-gray-600 leading-relaxed">
              Our expertise extends to project structuring and feasibility analysis, allowing us to merge global best practices with local insights for optimal client outcomes. Operating through a network of offices and strategic partnerships with leading global consulting firms, we offer tailored services that meet the unique requirements of each market, providing the highest standards in advisory and project management.
            </p>
          </div>
        </div>
      </section>

      {/* Mission, Vision, Values */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
              {/* Mission */}
              <Card className="border-0 shadow-xl text-center group hover:-translate-y-2 transition-all duration-300" data-aos="fade-up">
                <CardHeader>
                  <div className="w-16 h-16 bg-[#1e293b] rounded-full flex items-center justify-center mx-auto mb-6 group-hover:bg-[#f59e0b] transition-colors">
                    <Target className="w-8 h-8 text-white" />
                  </div>
                  <CardTitle className="text-2xl text-[#1e293b] mb-4">OUR MISSION</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 leading-relaxed">
                    Our mission is to empower clients with high-quality, insightful advisory solutions that drive sustainable growth, reduce risks, and maximize value. Through a commitment to excellence, integrity, and innovation, we aim to deliver tailored support that meets both local and global standards, fostering long-lasting relationships and creating a positive impact in every engagement.
                  </p>
                </CardContent>
              </Card>

              {/* Vision */}
              <Card className="border-0 shadow-xl text-center group hover:-translate-y-2 transition-all duration-300" data-aos="fade-up" data-aos-delay="200">
                <CardHeader>
                  <div className="w-16 h-16 bg-[#1e293b] rounded-full flex items-center justify-center mx-auto mb-6 group-hover:bg-[#f59e0b] transition-colors">
                    <Eye className="w-8 h-8 text-white" />
                  </div>
                  <CardTitle className="text-2xl text-[#1e293b] mb-4">OUR VISION</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 leading-relaxed">
                    To be the globally recognized leader in strategic consultancy, setting new standards for excellence and innovation in professional advisory services while maintaining our commitment to ethical practices and sustainable business solutions that create lasting value for our clients and communities.
                  </p>
                </CardContent>
              </Card>

              {/* Values */}
              <Card className="border-0 shadow-xl text-center group hover:-translate-y-2 transition-all duration-300" data-aos="fade-up" data-aos-delay="400">
                <CardHeader>
                  <div className="w-16 h-16 bg-[#1e293b] rounded-full flex items-center justify-center mx-auto mb-6 group-hover:bg-[#f59e0b] transition-colors">
                    <Heart className="w-8 h-8 text-white" />
                  </div>
                  <CardTitle className="text-2xl text-[#1e293b] mb-4">OUR VALUES</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 text-left">
                    <div className="flex items-center space-x-2">
                      <CheckCircle className="w-5 h-5 text-[#f59e0b]" />
                      <span className="text-gray-600">Global Expertise with Local Insight</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <CheckCircle className="w-5 h-5 text-[#f59e0b]" />
                      <span className="text-gray-600">Tailored Client Solutions</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <CheckCircle className="w-5 h-5 text-[#f59e0b]" />
                      <span className="text-gray-600">Excellence and Integrity</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <CheckCircle className="w-5 h-5 text-[#f59e0b]" />
                      <span className="text-gray-600">Long-Term Partnerships</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Goals & Objectives */}
      <section className="py-20 bg-[#1e293b] text-white">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-16" data-aos="fade-up">
              <h2 className="text-4xl font-bold mb-6">GOALS & OBJECTIVES</h2>
              <div className="w-24 h-1 bg-[#f59e0b] mx-auto mb-8"></div>
              <p className="text-xl text-gray-200">Core objectives that drive our strategic direction</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              <div className="text-center group" data-aos="fade-up">
                <div className="w-16 h-16 bg-[#f59e0b] rounded-lg flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform">
                  <Shield className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-xl font-semibold mb-4">Integrity and Transparency</h3>
                <p className="text-gray-300">Ensures trust and openness in all business interactions.</p>
              </div>

              <div className="text-center group" data-aos="fade-up" data-aos-delay="100">
                <div className="w-16 h-16 bg-[#f59e0b] rounded-lg flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform">
                  <Users className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-xl font-semibold mb-4">Tailored Consulting</h3>
                <p className="text-gray-300">Provides customized, high-quality consulting services.</p>
              </div>

              <div className="text-center group" data-aos="fade-up" data-aos-delay="200">
                <div className="w-16 h-16 bg-[#f59e0b] rounded-lg flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform">
                  <TrendingUp className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-xl font-semibold mb-4">Sustainable Growth</h3>
                <p className="text-gray-300">Focuses on innovation-driven, long-term growth.</p>
              </div>

              <div className="text-center group" data-aos="fade-up" data-aos-delay="300">
                <div className="w-16 h-16 bg-[#f59e0b] rounded-lg flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform">
                  <Award className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-xl font-semibold mb-4">Lasting Partnerships</h3>
                <p className="text-gray-300">Builds enduring relationships through meaningful outcomes.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* HLB Global Network */}
      <section className="py-20 bg-[#f1f5f9]">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-16" data-aos="fade-up">
              <h2 className="text-4xl font-bold text-[#1e293b] mb-6">GLOBAL OUTREACH</h2>
              <div className="w-24 h-1 bg-[#f59e0b] mx-auto mb-8"></div>
              <p className="text-xl text-gray-600">Leveraging the power of global networks for local excellence</p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <Card className="border-0 shadow-lg text-center group hover:-translate-y-2 transition-all duration-300" data-aos="fade-up">
                <CardHeader>
                  <div className="w-16 h-16 bg-[#1e293b] rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-[#f59e0b] transition-colors">
                    <Building className="w-8 h-8 text-white" />
                  </div>
                  <CardTitle className="text-[#1e293b]">Extensive Network</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600">
                    Leveraging the HLB Global Advisory and Accountancy Network, ranked 8th globally, to access wide-ranging resources and expertise.
                  </p>
                </CardContent>
              </Card>
              
              <Card className="border-0 shadow-lg text-center group hover:-translate-y-2 transition-all duration-300" data-aos="fade-up" data-aos-delay="200">
                <CardHeader>
                  <div className="w-16 h-16 bg-[#1e293b] rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-[#f59e0b] transition-colors">
                    <Globe className="w-8 h-8 text-white" />
                  </div>
                  <CardTitle className="text-[#1e293b]">Regional Presence</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600">
                    Operating through regional offices and partnerships with global consulting firms to deliver locally-tailored projects worldwide.
                  </p>
                </CardContent>
              </Card>
              
              <Card className="border-0 shadow-lg text-center group hover:-translate-y-2 transition-all duration-300" data-aos="fade-up" data-aos-delay="400">
                <CardHeader>
                  <div className="w-16 h-16 bg-[#1e293b] rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-[#f59e0b] transition-colors">
                    <Award className="w-8 h-8 text-white" />
                  </div>
                  <CardTitle className="text-[#1e293b]">Global Best Practices</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600">
                    Combining international standards with local market insights to offer high-quality, customized solutions for effective project management and delivery.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Advisory Team Strength */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-16" data-aos="fade-up">
              <h2 className="text-4xl font-bold text-[#1e293b] mb-6">ADVISORY TEAM STRENGTH</h2>
              <div className="w-24 h-1 bg-[#f59e0b] mx-auto mb-8"></div>
              <p className="text-xl text-gray-600">The expertise and experience behind our success</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              <Card className="border-0 shadow-lg group hover:shadow-xl transition-all duration-300" data-aos="fade-up">
                <CardHeader>
                  <CardTitle className="text-[#1e293b] text-lg">Extensive Years of Experience</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600">
                    The team's extensive industry experience enriches their advisory capabilities across diverse sectors and markets.
                  </p>
                </CardContent>
              </Card>

              <Card className="border-0 shadow-lg group hover:shadow-xl transition-all duration-300" data-aos="fade-up" data-aos-delay="100">
                <CardHeader>
                  <CardTitle className="text-[#1e293b] text-lg">Global and Local Expertise</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600">
                    Combining global practices with local insights for innovative solutions that address unique market challenges.
                  </p>
                </CardContent>
              </Card>

              <Card className="border-0 shadow-lg group hover:shadow-xl transition-all duration-300" data-aos="fade-up" data-aos-delay="200">
                <CardHeader>
                  <CardTitle className="text-[#1e293b] text-lg">Client-Centered Approach</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600">
                    Commitment to client success through measurable results and long-term strategic partnerships.
                  </p>
                </CardContent>
              </Card>

              <Card className="border-0 shadow-lg group hover:shadow-xl transition-all duration-300" data-aos="fade-up" data-aos-delay="300">
                <CardHeader>
                  <CardTitle className="text-[#1e293b] text-lg">Specialized Skill Sets</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600">
                    Unique skills like financial modeling and valuation enhance tailored services for complex business challenges.
                  </p>
                </CardContent>
              </Card>

              <Card className="border-0 shadow-lg group hover:shadow-xl transition-all duration-300" data-aos="fade-up" data-aos-delay="400">
                <CardHeader>
                  <CardTitle className="text-[#1e293b] text-lg">Deep Industry Insight</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600">
                    Team members' deep knowledge across sectors enables effective project handling and strategic solutions.
                  </p>
                </CardContent>
              </Card>

              <Card className="border-0 shadow-lg group hover:shadow-xl transition-all duration-300" data-aos="fade-up" data-aos-delay="500">
                <CardHeader>
                  <CardTitle className="text-[#1e293b] text-lg">Innovation Focus</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600">
                    Continuous innovation in methodologies and approaches to deliver cutting-edge advisory solutions.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-[#1e293b] text-white">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center" data-aos="fade-up">
            <h2 className="text-4xl font-bold mb-6">Ready to Work with Us?</h2>
            <p className="text-xl text-gray-200 mb-8">
              Experience the Professional Opinion difference - where global expertise meets local excellence
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/contact">
                <Button size="lg" className="bg-[#f59e0b] hover:bg-[#d97706] text-white px-8 py-3">
                  Get Started Today
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>
              <Link href="/services">
                <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-[#1e293b] px-8 py-3">
                  Explore Our Services
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-[#1e293b] text-white py-12 border-t border-gray-700">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <div className="w-8 h-8 bg-gradient-to-r from-[#1e293b] to-[#f59e0b] rounded-full flex items-center justify-center">
                  <span className="text-white font-bold text-sm">PO</span>
                </div>
                <span className="text-xl font-bold">Professional Opinion</span>
              </div>
              <p className="text-gray-300 text-sm">
                Licensed financial and management advisory firm delivering strategic solutions.
              </p>
            </div>
            <div>
              <h3 className="text-lg font-semibold text-[#f59e0b] mb-4">Quick Links</h3>
              <ul className="space-y-2">
                <li><Link href="/" className="text-gray-300 hover:text-[#f59e0b] text-sm">Home</Link></li>
                <li><Link href="/services" className="text-gray-300 hover:text-[#f59e0b] text-sm">Services</Link></li>
                <li><Link href="/team" className="text-gray-300 hover:text-[#f59e0b] text-sm">Team</Link></li>
                <li><Link href="/contact" className="text-gray-300 hover:text-[#f59e0b] text-sm">Contact</Link></li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-semibold text-[#f59e0b] mb-4">Services</h3>
              <ul className="space-y-2">
                <li><Link href="/services#valuation" className="text-gray-300 hover:text-[#f59e0b] text-sm">Business Valuation</Link></li>
                <li><Link href="/services#ma" className="text-gray-300 hover:text-[#f59e0b] text-sm">M&A Advisory</Link></li>
                <li><Link href="/services#transaction" className="text-gray-300 hover:text-[#f59e0b] text-sm">Transaction Advisory</Link></li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-semibold text-[#f59e0b] mb-4">Contact</h3>
              <div className="space-y-2 text-gray-300 text-sm">
                <p>6th Floor - Tulip Tower</p>
                <p>Riyadh 11415 – KSA</p>
                <p>Phone: 920005122</p>
                <p>Email: info@po.sa</p>
              </div>
            </div>
          </div>
          <div className="border-t border-gray-700 mt-8 pt-8 text-center text-gray-400 text-sm">
            <p>&copy; 2024 Professional Opinion. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}