"use client";

import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Navbar } from "@/components/layout/navbar";
import { ArrowRight, Search, Building, BarChart3, TrendingUp, FileText, Shield, PieChart, Award, DollarSign, ChevronDown, ChevronUp } from "lucide-react";
import Link from "next/link";

export default function ServicesPage() {
  return (
    <div className="min-h-screen bg-white dark:bg-[#1D1D1B]">
      <Navbar />
      
      {/* Hero Section */}
      <section className="pt-32 pb-16 hero-gradient">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-5xl lg:text-6xl font-bold text-white mb-6">
              OUR SERVICES
            </h1>
            <div className="w-24 h-1 bg-[#FBBA00] mx-auto mb-8"></div>
            <p className="text-xl text-gray-200 leading-relaxed">
              Comprehensive grid of 9 professional services with detailed sub-services and 3D hover effects
            </p>
          </div>
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-20 bg-white dark:bg-[#1D1D1B]">
        <div className="container mx-auto px-4">
          <div className="max-w-7xl mx-auto">
            
            {/* 3-Column Grid (Desktop), 1-2 Columns (Mobile) */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              
              {/* Market Analysis */}
              <Card className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 group hover:-translate-y-2">
                <CardHeader>
                  <div className="w-12 h-12 bg-[#FBBA00] rounded-lg flex items-center justify-center mb-4 group-hover:bg-[#005A77] group-hover:scale-110 transition-all duration-300">
                    <Search className="w-6 h-6 text-white" />
                  </div>
                  <CardTitle className="text-[#005A77] group-hover:text-[#FBBA00] transition-colors">Market Analysis</CardTitle>
                  <CardDescription className="text-gray-600">
                    Comprehensive market intelligence for strategic decision-making and competitive positioning.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 mb-6">
                    <div className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-[#FBBA00] rounded-full"></div>
                      <p className="text-sm text-gray-600">Data-driven market entry strategies</p>
                    </div>
                    <div className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-[#FBBA00] rounded-full"></div>
                      <p className="text-sm text-gray-600">Competitor and trend analysis for growth</p>
                    </div>
                  </div>
                  <Button asChild variant="outline" className="text-[#FBBA00] border-[#FBBA00] hover:bg-[#FBBA00] hover:text-white transition-all duration-300">
                    <Link href="/contact">
                      Learn More
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Link>
                  </Button>
                </CardContent>
              </Card>

              {/* Real Estate & Investment */}
              <Card className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 group hover:-translate-y-2">
                <CardHeader>
                  <div className="w-12 h-12 bg-[#FBBA00] rounded-lg flex items-center justify-center mb-4 group-hover:bg-[#005A77] group-hover:scale-110 transition-all duration-300">
                    <Building className="w-6 h-6 text-white" />
                  </div>
                  <CardTitle className="text-[#005A77] group-hover:text-[#FBBA00] transition-colors">Real Estate & Investment</CardTitle>
                  <CardDescription className="text-gray-600">
                    Complete real estate investment solutions from analysis to financing.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 mb-6">
                    <div className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-[#FBBA00] rounded-full"></div>
                      <p className="text-sm text-gray-600">REITs: Portfolio analysis, compliance, trustee selection</p>
                    </div>
                    <div className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-[#FBBA00] rounded-full"></div>
                      <p className="text-sm text-gray-600">Best Use Assessment: Zoning, feasibility studies</p>
                    </div>
                    <div className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-[#FBBA00] rounded-full"></div>
                      <p className="text-sm text-gray-600">Financing Solutions: Debt, equity, mezzanine funding</p>
                    </div>
                  </div>
                  <Button asChild variant="outline" className="text-[#FBBA00] border-[#FBBA00] hover:bg-[#FBBA00] hover:text-white transition-all duration-300">
                    <Link href="/contact">
                      Learn More
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Link>
                  </Button>
                </CardContent>
              </Card>

              {/* Financial Modeling */}
              <Card className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 group hover:-translate-y-2">
                <CardHeader>
                  <div className="w-12 h-12 bg-[#FBBA00] rounded-lg flex items-center justify-center mb-4 group-hover:bg-[#005A77] group-hover:scale-110 transition-all duration-300">
                    <BarChart3 className="w-6 h-6 text-white" />
                  </div>
                  <CardTitle className="text-[#005A77] group-hover:text-[#FBBA00] transition-colors">Financial Modeling</CardTitle>
                  <CardDescription className="text-gray-600">
                    Advanced financial projections and scenario-based analysis for strategic planning.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 mb-6">
                    <div className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-[#FBBA00] rounded-full"></div>
                      <p className="text-sm text-gray-600">Cash flow, income, balance sheet projections</p>
                    </div>
                    <div className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-[#FBBA00] rounded-full"></div>
                      <p className="text-sm text-gray-600">Scenario-based sensitivity analysis</p>
                    </div>
                  </div>
                  <Button asChild variant="outline" className="text-[#FBBA00] border-[#FBBA00] hover:bg-[#FBBA00] hover:text-white transition-all duration-300">
                    <Link href="/contact">
                      Learn More
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Link>
                  </Button>
                </CardContent>
              </Card>

              {/* M&A Advisory */}
              <Card className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 group hover:-translate-y-2">
                <CardHeader>
                  <div className="w-12 h-12 bg-[#FBBA00] rounded-lg flex items-center justify-center mb-4 group-hover:bg-[#005A77] group-hover:scale-110 transition-all duration-300">
                    <TrendingUp className="w-6 h-6 text-white" />
                  </div>
                  <CardTitle className="text-[#005A77] group-hover:text-[#FBBA00] transition-colors">M&A Advisory</CardTitle>
                  <CardDescription className="text-gray-600">
                    Comprehensive merger and acquisition advisory from strategy to execution.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 mb-6">
                    <div className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-[#FBBA00] rounded-full"></div>
                      <p className="text-sm text-gray-600">360° M&A: Deal flow, valuation, pre/post-acquisition</p>
                    </div>
                    <div className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-[#FBBA00] rounded-full"></div>
                      <p className="text-sm text-gray-600">Deal Structuring: Buy/sell-side, term sheets, SPAs</p>
                    </div>
                    <div className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-[#FBBA00] rounded-full"></div>
                      <p className="text-sm text-gray-600">Negotiation: EOI, SPA, tax/legal due diligence</p>
                    </div>
                  </div>
                  <Button asChild variant="outline" className="text-[#FBBA00] border-[#FBBA00] hover:bg-[#FBBA00] hover:text-white transition-all duration-300">
                    <Link href="/contact">
                      Learn More
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Link>
                  </Button>
                </CardContent>
              </Card>

              {/* Due Diligence */}
              <Card className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 group hover:-translate-y-2">
                <CardHeader>
                  <div className="w-12 h-12 bg-[#FBBA00] rounded-lg flex items-center justify-center mb-4 group-hover:bg-[#005A77] group-hover:scale-110 transition-all duration-300">
                    <FileText className="w-6 h-6 text-white" />
                  </div>
                  <CardTitle className="text-[#005A77] group-hover:text-[#FBBA00] transition-colors">Due Diligence</CardTitle>
                  <CardDescription className="text-gray-600">
                    Thorough analysis and risk assessment for informed investment decisions.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 mb-6">
                    <div className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-[#FBBA00] rounded-full"></div>
                      <p className="text-sm text-gray-600">Financial, operational, strategic analysis</p>
                    </div>
                    <div className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-[#FBBA00] rounded-full"></div>
                      <p className="text-sm text-gray-600">Risk identification and mitigation</p>
                    </div>
                  </div>
                  <Button asChild variant="outline" className="text-[#FBBA00] border-[#FBBA00] hover:bg-[#FBBA00] hover:text-white transition-all duration-300">
                    <Link href="/contact">
                      Learn More
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Link>
                  </Button>
                </CardContent>
              </Card>

              {/* Risk Assessment */}
              <Card className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 group hover:-translate-y-2">
                <CardHeader>
                  <div className="w-12 h-12 bg-[#FBBA00] rounded-lg flex items-center justify-center mb-4 group-hover:bg-[#005A77] group-hover:scale-110 transition-all duration-300">
                    <Shield className="w-6 h-6 text-white" />
                  </div>
                  <CardTitle className="text-[#005A77] group-hover:text-[#FBBA00] transition-colors">Risk Assessment</CardTitle>
                  <CardDescription className="text-gray-600">
                    Comprehensive risk evaluation and mitigation strategies for business protection.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 mb-6">
                    <div className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-[#FBBA00] rounded-full"></div>
                      <p className="text-sm text-gray-600">Risk evaluation and mitigation strategies</p>
                    </div>
                    <div className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-[#FBBA00] rounded-full"></div>
                      <p className="text-sm text-gray-600">Internal control system development</p>
                    </div>
                  </div>
                  <Button asChild variant="outline" className="text-[#FBBA00] border-[#FBBA00] hover:bg-[#FBBA00] hover:text-white transition-all duration-300">
                    <Link href="/contact">
                      Learn More
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Link>
                  </Button>
                </CardContent>
              </Card>

              {/* Financial Structuring */}
              <Card className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 group hover:-translate-y-2">
                <CardHeader>
                  <div className="w-12 h-12 bg-[#FBBA00] rounded-lg flex items-center justify-center mb-4 group-hover:bg-[#005A77] group-hover:scale-110 transition-all duration-300">
                    <PieChart className="w-6 h-6 text-white" />
                  </div>
                  <CardTitle className="text-[#005A77] group-hover:text-[#FBBA00] transition-colors">Financial Structuring</CardTitle>
                  <CardDescription className="text-gray-600">
                    Optimal capital structure design for enhanced investment appeal and performance.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 mb-6">
                    <div className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-[#FBBA00] rounded-full"></div>
                      <p className="text-sm text-gray-600">Capital allocation optimization</p>
                    </div>
                    <div className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-[#FBBA00] rounded-full"></div>
                      <p className="text-sm text-gray-600">Debt-equity balance for investment appeal</p>
                    </div>
                  </div>
                  <Button asChild variant="outline" className="text-[#FBBA00] border-[#FBBA00] hover:bg-[#FBBA00] hover:text-white transition-all duration-300">
                    <Link href="/contact">
                      Learn More
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Link>
                  </Button>
                </CardContent>
              </Card>

              {/* Bid Advisory */}
              <Card className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 group hover:-translate-y-2">
                <CardHeader>
                  <div className="w-12 h-12 bg-[#FBBA00] rounded-lg flex items-center justify-center mb-4 group-hover:bg-[#005A77] group-hover:scale-110 transition-all duration-300">
                    <Award className="w-6 h-6 text-white" />
                  </div>
                  <CardTitle className="text-[#005A77] group-hover:text-[#FBBA00] transition-colors">Bid Advisory</CardTitle>
                  <CardDescription className="text-gray-600">
                    Strategic bid preparation and advisory for competitive advantage in tenders.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 mb-6">
                    <div className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-[#FBBA00] rounded-full"></div>
                      <p className="text-sm text-gray-600">RFP/RFQ/ITB analysis, risk assessment</p>
                    </div>
                    <div className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-[#FBBA00] rounded-full"></div>
                      <p className="text-sm text-gray-600">Technical/financial bid prep, advisor coordination</p>
                    </div>
                  </div>
                  <Button asChild variant="outline" className="text-[#FBBA00] border-[#FBBA00] hover:bg-[#FBBA00] hover:text-white transition-all duration-300">
                    <Link href="/contact">
                      Learn More
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Link>
                  </Button>
                </CardContent>
              </Card>

              {/* Fund Raising */}
              <Card className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 group hover:-translate-y-2">
                <CardHeader>
                  <div className="w-12 h-12 bg-[#FBBA00] rounded-lg flex items-center justify-center mb-4 group-hover:bg-[#005A77] group-hover:scale-110 transition-all duration-300">
                    <DollarSign className="w-6 h-6 text-white" />
                  </div>
                  <CardTitle className="text-[#005A77] group-hover:text-[#FBBA00] transition-colors">Fund Raising</CardTitle>
                  <CardDescription className="text-gray-600">
                    Comprehensive capital raising solutions across public and private markets.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 mb-6">
                    <div className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-[#FBBA00] rounded-full"></div>
                      <p className="text-sm text-gray-600">IPO/Listing: Readiness, compliance, investor engagement</p>
                    </div>
                    <div className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-[#FBBA00] rounded-full"></div>
                      <p className="text-sm text-gray-600">Private Equity: Investor ID, due diligence</p>
                    </div>
                    <div className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-[#FBBA00] rounded-full"></div>
                      <p className="text-sm text-gray-600">Debt Financing: Sukuks, TFCs, syndicated facilities</p>
                    </div>
                  </div>
                  <Button asChild variant="outline" className="text-[#FBBA00] border-[#FBBA00] hover:bg-[#FBBA00] hover:text-white transition-all duration-300">
                    <Link href="/contact">
                      Learn More
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Link>
                  </Button>
                </CardContent>
              </Card>

            </div>

            {/* Language Translation Notice */}
            <div className="text-center mt-16">
              <div className="bg-[#005A77] text-white rounded-lg p-6 max-w-2xl mx-auto">
                <h3 className="text-xl font-bold mb-4">Multi-Language Support</h3>
                <p className="text-gray-200 mb-4">
                  All service descriptions and sub-services are available in:
                </p>
                <div className="flex justify-center space-x-4">
                  <Badge className="bg-[#FBBA00] text-[#005A77]">🇺🇸 English</Badge>
                  <Badge className="bg-[#FBBA00] text-[#005A77]">🇸🇦 العربية</Badge>
                  <Badge className="bg-[#FBBA00] text-[#005A77]">🇨🇳 中文</Badge>
                </div>
              </div>
            </div>

            {/* CTA Section */}
            <div className="text-center mt-16">
              <h3 className="text-3xl font-bold text-[#005A77] dark:text-white mb-6">
                Ready to Transform Your Business?
              </h3>
              <p className="text-xl text-gray-600 dark:text-gray-300 mb-8 max-w-2xl mx-auto">
                Get in touch with our expert team to discuss your specific needs and learn how we can help you achieve your strategic objectives.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button asChild size="lg" className="bg-[#005A77] hover:bg-[#0093A7] text-white px-8 py-3 text-lg font-semibold rounded-full">
                  <Link href="/contact">
                    Schedule Consultation
                    <ArrowRight className="ml-2 h-5 w-5" />
                  </Link>
                </Button>
                <Button asChild size="lg" variant="outline" className="border-[#005A77] text-[#005A77] hover:bg-[#005A77] hover:text-white px-8 py-3 text-lg font-semibold rounded-full">
                  <Link href="/insights">
                    View Case Studies
                  </Link>
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-[#1D1D1B] text-white py-16">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="lg:col-span-2">
              <div className="flex items-center space-x-3 mb-6">
                <div className="w-10 h-10 bg-gradient-to-r from-[#005A77] to-[#FBBA00] rounded-full flex items-center justify-center">
                  <span className="text-white font-bold">PO</span>
                </div>
                <span className="text-2xl font-bold">Professional Opinion</span>
              </div>
              <p className="text-gray-300 mb-6 text-lg leading-relaxed max-w-md">
                Licensed financial and management advisory firm delivering strategic solutions across the Middle East and beyond.
              </p>
            </div>
            <div>
              <h3 className="text-xl font-semibold text-[#FBBA00] mb-6">Quick Links</h3>
              <ul className="space-y-3">
                <li><Link href="/about" className="text-gray-300 hover:text-[#FBBA00] transition-colors">About</Link></li>
                <li><Link href="/services" className="text-gray-300 hover:text-[#FBBA00] transition-colors">Services</Link></li>
                <li><Link href="/team" className="text-gray-300 hover:text-[#FBBA00] transition-colors">Team</Link></li>
                <li><Link href="/insights" className="text-gray-300 hover:text-[#FBBA00] transition-colors">Case Studies</Link></li>
                <li><Link href="/contact" className="text-gray-300 hover:text-[#FBBA00] transition-colors">Contact</Link></li>
              </ul>
            </div>
            <div>
              <h3 className="text-xl font-semibold text-[#FBBA00] mb-6">Legal</h3>
              <ul className="space-y-3">
                <li><Link href="/terms" className="text-gray-300 hover:text-[#FBBA00] transition-colors">Terms & Conditions</Link></li>
                <li><Link href="/privacy" className="text-gray-300 hover:text-[#FBBA00] transition-colors">Privacy Policy</Link></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-700 mt-12 pt-8 text-center">
            <p className="text-gray-400">© 2025 Professional Opinion. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}