import NextLink, { LinkProps as NextLinkProps } from 'next/link';
import { withBasePath } from '@/lib/utils';
import React from 'react';

export interface LinkWithBaseProps extends NextLinkProps {
  children?: React.ReactNode;
  className?: string;
}

/**
 * Link component that automatically adds the base path for GitHub Pages deployment
 */
export function LinkWithBase({ href, children, ...props }: LinkWithBaseProps) {
  // Convert href to string and apply base path if it's an internal link
  const hrefString = typeof href === 'string' ? href : href.toString();
  const processedHref = withBasePath(hrefString);
  
  return (
    <NextLink href={processedHref} {...props}>
      {children}
    </NextLink>
  );
}