import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// Utility function to prefix paths with base path when in production
export function getBaseUrl() {
  // This should match the base path in next.config.ts
  return process.env.NODE_ENV === 'production' ? '/consulting-website' : '';
}

export function withBasePath(path: string) {
  // Don't modify external URLs
  if (path.startsWith('http') || path.startsWith('//')) {
    return path;
  }
  
  // Handle paths that already have the base path
  const basePath = getBaseUrl();
  if (path.startsWith(basePath)) {
    return path;
  }
  
  // Add base path to internal links
  return `${basePath}${path}`;
}